#!/bin/sh
docker build -f Dockerfile --build-arg WORKSPACE=${WORKSPACE} -t ${IMAGE} .
docker tag ${IMAGE} 50hertz/energy:${IMAGE}-${RELEASE_NAME}
docker push 50hertz/energy:${IMAGE}-${RELEASE_NAME}
a=`docker service ps -q -f desired-state=running ${IMAGE}-${RELEASE_NAME}`
if [[ "${a}" == "" ]]; then
 echo "service not running..."
else
 echo "Removing service..."
 docker service rm ${IMAGE}-${RELEASE_NAME}
 echo "Service removed..."
fi
b=`docker config ls | grep ${IMAGE}-${RELEASE_NAME}`
if [[ "${b}" == "" ]]; then
 echo "Nginx config not found. Creating new..."
 echo "server { \
                server_name ${IMAGE}-${RELEASE_NAME}.50hz.co.in; \
                listen 80 ; \
                return 301 https://${IMAGE}-${RELEASE_NAME}.50hz.co.in$request_uri; \
                } \
server { \
                server_name ${IMAGE}-${RELEASE_NAME}.50hz.co.in; \
                listen 443 ssl; \
                ssl_certificate /run/secrets/fullchain2.cer; \
                ssl_certificate_key /run/secrets/50hz.co.in.key; \
                location / { \
                            proxy_pass http://${IMAGE}-${RELEASE_NAME}:8080; \
                } \
         }"| docker config create ${IMAGE}-${RELEASE_NAME} -
else
 echo "Config already exists..."
 docker service update --config-rm ${IMAGE}-${RELEASE_NAME} nginx
fi

