/**
 * 
 */
package in.hertz.samast.dao;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.web.context.WebApplicationContext;

import in.hertz.samast.entity.TimeInterval;

/**
 * @author Bibhuti Parida
 *
 */
@ExtendWith(MockitoExtension.class)
@AutoConfigureMockMvc
@WebAppConfiguration
@ContextConfiguration(classes = {TimeIntervalRepository.class, WebApplicationContext.class})
@WebMvcTest(controllers = TimeIntervalRepository.class)
public class TimeIntervalRepositoryTest {
	
	@MockBean
	private TimeIntervalRepository timeIntervalRepository;
	
	@Test
	public void findAllTest() {
		List<TimeInterval> timeIntList = timeIntervalRepository.findAll();
		assertNotNull(timeIntList);
	}
	
	@Test
	public void findByIdTest() {
		Optional<TimeInterval> tm = timeIntervalRepository.findById(1);
		assertNotNull(tm);
	}

	@Test
	public void findByBlockTest() throws Exception {
		TimeInterval tm = timeIntervalRepository.findByBlock(2);
		assertNull(tm);
	}
	
	@Test
	public void findMaxBlockTest() throws Exception {
		Integer tm = timeIntervalRepository.findMaxBlock();
		assertEquals(0, tm.intValue());
	}
}
