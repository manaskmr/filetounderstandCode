/**
 * 
 */
package in.hertz.samast.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.context.WebApplicationContext;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import in.hertz.samast.domain.ForecastSubscriptionBO;
import in.hertz.samast.domain.ForecastSubscriptionUsagesBO;
import in.hertz.samast.domain.PSSDetailsDTO;
import in.hertz.samast.domain.exception.BusinessException;

/**
 * @author Bibhuti Parida
 *
 */
@ExtendWith(MockitoExtension.class)
@AutoConfigureMockMvc
@WebAppConfiguration
@ContextConfiguration(classes = {ForecastSubscriptionServiceImpl.class, WebApplicationContext.class})
@WebMvcTest(controllers = ForecastSubscriptionServiceImpl.class)
public class ForecastSubscriptionServiceTest {
	
	@MockBean
	private ForecastSubscriptionServiceImpl forecastSubscriptionService;

	@Autowired
    protected MockMvc mockMvc;
	
	private String jsonschfsadd =
	    	"{" +
	    	"	    \"pssUtgId\": 240, "+
	    	"	    \"qcaUtgId\": null, "+
	    	"	    \"registrationNo\": \"ABCTest\", "+
	    	"	    \"noOfDays\": 10, "+
	    	"	    \"forecastServiceCostDay\": 3000, "+
	    	"	    \"forecastServiceCost\": 30000, "+
	    	"	    \"gstValue\": 5400, "+
	    	"	    \"totalAmt\": 35400, "+
	    	"	    \"rtgsNo\": \"TEstTest\" "+
	    	"}";
	
	private String jsonschfsupdate =
	    	"{" +
    		"	  \"forDate\": \"2022-07-11\", "+
    		"	  \"pssUtgid\": 240,			"+
    		"	  \"qcaUtgId\": null,			"+
    		"	  \"viewerUtgId\": 240			"+
	    	"}";
	
	@Test
	public void getPSSListByQCAIdTest()  throws Exception, BusinessException {
		List<PSSDetailsDTO> pssList = new ArrayList<PSSDetailsDTO>();
		Mockito.when(forecastSubscriptionService.getPSSListByQCAId(1)).thenReturn(pssList);
	}

	@Test
	public void getForecastSubscriptionListByPSSIdTest()  throws Exception, BusinessException {
		List<ForecastSubscriptionBO> forecastSubscriptionList = new ArrayList<ForecastSubscriptionBO>();
		Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").create();
		ForecastSubscriptionBO schDto = gson.fromJson(jsonschfsadd, ForecastSubscriptionBO.class);
		forecastSubscriptionList.add(schDto);
		Mockito.when(forecastSubscriptionService.getForecastSubscriptionListByPSSId(1)).thenReturn(forecastSubscriptionList);
	}

	@Test
	public void getForecastSubscriptionByPSSIdTest()  throws Exception, BusinessException {
		List<ForecastSubscriptionBO> forecastSubscriptionList = new ArrayList<ForecastSubscriptionBO>();
		Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").create();
		ForecastSubscriptionBO schDto = gson.fromJson(jsonschfsadd, ForecastSubscriptionBO.class);
		forecastSubscriptionList.add(schDto);
		Mockito.when(forecastSubscriptionService.getForecastSubscriptionByPSSId(1)).thenReturn(forecastSubscriptionList);
	}
	
	@Test
	public void getForecastSubscriptionDetailByPSSIdTest()  throws Exception, BusinessException {
		Mockito.when(forecastSubscriptionService.getForecastSubscriptionDetailByPSSId(1, new Date())).thenReturn(new ArrayList<ForecastSubscriptionUsagesBO>());
	}

	@Test
	public void newFSTest()  throws Exception, BusinessException {
		Mockito.when(forecastSubscriptionService.newFS(1, 10)).thenReturn(new ForecastSubscriptionBO());
	}
	
	@Test
	public void saveForecastSubscriptionTest()  throws Exception, BusinessException {
		Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").create();
		ForecastSubscriptionBO schDto = gson.fromJson(jsonschfsadd, ForecastSubscriptionBO.class);
		Mockito.when(forecastSubscriptionService.saveForecastSubscription(schDto)).thenReturn(schDto);
	}

	@Test
	public void updateForecastSubscriptionTest()  throws Exception, BusinessException {
		Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").create();
		ForecastSubscriptionUsagesBO schDto = gson.fromJson(jsonschfsupdate, ForecastSubscriptionUsagesBO.class);
		Mockito.when(forecastSubscriptionService.updateForecastSubscription(schDto)).thenReturn(schDto);
	}

}
