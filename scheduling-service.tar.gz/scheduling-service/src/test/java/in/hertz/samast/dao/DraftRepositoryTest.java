/**
 * 
 */
package in.hertz.samast.dao;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.web.context.WebApplicationContext;

import in.hertz.samast.domain.CoalPositionBO;
import in.hertz.samast.domain.InjectionScheduleBO;
import in.hertz.samast.domain.ScheduleQuantumBaseDTO;
import in.hertz.samast.entity.Draft;

/**
 * @author Bibhuti Parida
 *
 */
@ExtendWith(MockitoExtension.class)
@AutoConfigureMockMvc
@WebAppConfiguration
@ContextConfiguration(classes = {DraftRepository.class, WebApplicationContext.class})
@WebMvcTest(controllers = DraftRepository.class)
public class DraftRepositoryTest {
	
	@MockBean
	private DraftRepository<ScheduleQuantumBaseDTO> draftRepository;
	
	
	@Test
	public void findAllTest() {
		List<Draft<ScheduleQuantumBaseDTO>> draftList = draftRepository.findAll();
		assertNotNull(draftList);
	}
	
	@Test
	public void findByIdTest() {
		Optional<Draft<ScheduleQuantumBaseDTO>> draft = draftRepository.findById(1);
		assertNotNull(draft);
	}

	@Test
	public void findDraftByNameTest() {
		List<Draft<ScheduleQuantumBaseDTO>> draftList = draftRepository.findDraftByName(1, "2022-06-30");
		assertNotNull(draftList);
	}

	@Test
	public void findDraftByDateTest() {
		List<Draft<CoalPositionBO>> draftList = draftRepository.findDraftByDate(1, "2022-06-30");
		assertNotNull(draftList);
	}
	
	@Test
	public void findDraftForInjectionScheduleTest() {
		List<Draft<InjectionScheduleBO>> draftList = draftRepository.findDraftForInjectionSchedule(1, "2022-06-30");
		assertNotNull(draftList);
	}
}
