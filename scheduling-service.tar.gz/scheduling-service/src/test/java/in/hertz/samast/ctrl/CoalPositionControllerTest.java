package in.hertz.samast.ctrl;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import in.hertz.samast.domain.CoalPositionBO;
import in.hertz.samast.domain.DraftDTO;
import in.hertz.samast.domain.WSResp;
import in.hertz.samast.domain.exception.BusinessException;
import in.hertz.samast.entity.Draft;
import in.hertz.samast.entity.TimeInterval;
import in.hertz.samast.service.CoalPositionService;

@ExtendWith(MockitoExtension.class)
@AutoConfigureMockMvc
@WebAppConfiguration
@ContextConfiguration(classes = {CoalPositionController.class, WebApplicationContext.class})
@WebMvcTest(controllers = CoalPositionController.class)
public class CoalPositionControllerTest {
			
	@Autowired
    protected MockMvc mockMvc;
    
    @MockBean
	protected CoalPositionController coalPositionController;
    
    @Autowired
    private ObjectMapper objectMapper;
    
    @MockBean
	private CoalPositionService coalPositionService;
	
	private String jsonschcoaal =
	"	{						"+
	"	  \"closingBalance\": 10, "+
	"	  \"coalConsumed\": 10, "+
	"	  \"coalPositionId\": 0, "+
	"	  \"coalReceived\": 20, "+
	"	  \"createdBy\": \"string\", "+
	"	  \"forDate\": \"2022-07-04\", "+
	"	  \"generatorName\": \"string\", "+
	"	  \"openingBalance\": 30, "+
	"	  \"utgId\": 61 "+
	"	} ";
	
	private String jsonschDraft = 
    		"	{ "+
    		"	  \"createdBy\": \"Bibhuti Test\", "+
    		"	  \"createdDate\": null, "+
    		"	  \"currentStage\": \"\", "+
    		"	  \"entityRegistrationDTO\": null, "+
    		"	  \"functionalityArea\": \"Scheduling_Coal_Position_Test\", "+
    		"	  \"modifiedBy\": \"string\", "+
    		"	  \"modifiedDate\": null, "+
    		"	  \"jsonDTO\": { "+
    		"	  \"closingBalance\": 10, "+
    		"	  \"coalConsumed\": 10, "+
    		"	  \"coalPositionId\": 0, "+
    		"	  \"coalReceived\": 20, "+
    		"	  \"createdBy\": \"string\", "+
    		"	  \"forDate\": \"2022-07-01\", "+
    		"	  \"generatorName\": \"string\", "+
    		"	  \"openingBalance\": 30, "+
    		"	  \"utgId\": 61 "+
    		"	}, " +
    		"	  \"status\": \"Testing New\" "+
    		"	}		";
	
	@Test
	public void getCoalPositionByDateTest() throws BusinessException, Exception {
		
		Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd").create();
		CoalPositionBO schDto = gson.fromJson(jsonschcoaal, CoalPositionBO.class);
		ResponseEntity<WSResp<CoalPositionBO>> respCP = new ResponseEntity<WSResp<CoalPositionBO>>(new WSResp<CoalPositionBO>(schDto, true, "Coal Position Data Fetched Successfully!"), HttpStatus.OK);
		Mockito.when(coalPositionController.getCoalPositionByDate(new Date(), 61)).thenReturn(respCP);
		
		String uri = "/coal-position/61/2022-07-05";
		MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();
		int status = mvcResult.getResponse().getStatus();

		assertEquals(200, status);
	}
	
	@Test
	public void newCoalPositionTest() throws BusinessException, Exception {
		
		Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd").create();
		CoalPositionBO schDto = gson.fromJson(jsonschcoaal, CoalPositionBO.class);
		ResponseEntity<WSResp<CoalPositionBO>> respCP = new ResponseEntity<WSResp<CoalPositionBO>>(new WSResp<CoalPositionBO>(schDto, true, "Coal Position Data Fetched Successfully!"), HttpStatus.OK);
		Mockito.when(coalPositionController.newCoalPosition(61, new Date())).thenReturn(respCP);
		
		String uri = "/coal-position/newCoalPosition/61/2022-07-05";
		MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();
		int status = mvcResult.getResponse().getStatus();

		assertEquals(200, status);
	}
	
	@Test
	public void saveCoalPositionTest() throws BusinessException, Exception {
		
		Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd'T'HH:mm:ss").create();
		CoalPositionBO schDto = gson.fromJson(jsonschcoaal, CoalPositionBO.class);
		ResponseEntity<WSResp<CoalPositionBO>> respCP = new ResponseEntity<WSResp<CoalPositionBO>>(new WSResp<CoalPositionBO>(schDto,true,"Request processed successfully"),HttpStatus.OK);
		Mockito.when(coalPositionController.saveCoalPosition(schDto)).thenReturn(respCP);
		
		String uri = "/coal-position/saveCoalPosition";
		MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.post(uri)
				.contentType(MediaType.APPLICATION_JSON)
		        .content(objectMapper.writeValueAsString(schDto)))
				.andReturn();
		int status = mvcResult.getResponse().getStatus();

		assertEquals(200, status);
	}

	@Test
	public void updateCoalPositionTest() throws BusinessException, Exception {
		
		Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd'T'HH:mm:ss").create();
		CoalPositionBO schDto = gson.fromJson(jsonschcoaal, CoalPositionBO.class);
		ResponseEntity<WSResp<CoalPositionBO>> respCP = new ResponseEntity<WSResp<CoalPositionBO>>(new WSResp<CoalPositionBO>(schDto,true,"Request processed successfully"),HttpStatus.OK);
		Mockito.when(coalPositionController.updateCoalPosition(schDto)).thenReturn(respCP);
		
		String uri = "/coal-position/update";
		MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.put(uri)
				.contentType(MediaType.APPLICATION_JSON)
		        .content(objectMapper.writeValueAsString(schDto)))
				.andReturn();
		int status = mvcResult.getResponse().getStatus();

		assertEquals(200, status);
	}

	@Test
	public void getCurrentTimeBlockTest() throws Exception, BusinessException {
		TimeInterval timeBlock = coalPositionService.getCurrentTimeBlock();
		ResponseEntity<WSResp<TimeInterval>> respTMBlk = new ResponseEntity<WSResp<TimeInterval>>(
				new WSResp<TimeInterval>(timeBlock, true, "Time Block fetched Successfully!"), HttpStatus.OK);
		Mockito.when(coalPositionController.getCurrentTimeBlock()).thenReturn(respTMBlk);
		
		String uri = "/coal-position/findCurrentTimeBlock";
		MvcResult mvcResult =  mockMvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();
		int status = mvcResult.getResponse().getStatus();

		assertEquals(200, status);
	}
	
	@Test
	public void getAllCoalPositionByDateTest() throws BusinessException, Exception {
		Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd'T'HH:mm:ss").create();
		CoalPositionBO schDto = gson.fromJson(jsonschcoaal, CoalPositionBO.class);
		List<CoalPositionBO> colposlist = new ArrayList<CoalPositionBO>();
		colposlist.add(schDto);
		ResponseEntity<WSResp<List<CoalPositionBO>>> respCP = new ResponseEntity<WSResp<List<CoalPositionBO>>>(new WSResp<List<CoalPositionBO>>(colposlist, true, "Coal Position Data Fetched Successfully!"), HttpStatus.OK);
		Mockito.when(coalPositionController.getAllCoalPositionByDate()).thenReturn(respCP);
		
		String uri = "/coal-position/allcoalpositions";
		MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();
		int status = mvcResult.getResponse().getStatus();

		assertEquals(200, status);
	}

	@Test
	public void getCoalPositionOfPreviousDayTest() throws BusinessException, Exception {
		
		Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd'T'HH:mm:ss").create();
		CoalPositionBO schDto = gson.fromJson(jsonschcoaal, CoalPositionBO.class);
		ResponseEntity<WSResp<CoalPositionBO>> respCP = new ResponseEntity<WSResp<CoalPositionBO>>(new WSResp<CoalPositionBO>(schDto, true, "Coal Position Data Fetched Successfully!"), HttpStatus.OK);
		Mockito.when(coalPositionController.getCoalPositionByDate(new Date(), 61)).thenReturn(respCP);
		
		String uri = "/coal-position/previousDay/61";
		MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();
		int status = mvcResult.getResponse().getStatus();

		assertEquals(200, status);
	}
	
	@Test
	public void findDraftTest() throws Exception, BusinessException {
		Draft<CoalPositionBO> draftDTO = coalPositionService.getDraftedCoalPositionByDateAndUtgId(new Date(), 61);
		ResponseEntity<WSResp<Draft<CoalPositionBO>>> respDraft = new ResponseEntity<WSResp<Draft<CoalPositionBO>>>(
				new WSResp<Draft<CoalPositionBO>>(draftDTO, true, "Data Fetched Successfully!"),
				HttpStatus.OK);
		Mockito.when(coalPositionController.getDraftedCoalPoistionByDate(new Date(), 61)).thenReturn(respDraft);
		
		String uri = "/coal-position/draft/61/2022-07-05";
		MvcResult mvcResult =  mockMvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();
		int status = mvcResult.getResponse().getStatus();

		assertEquals(200, status);
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void saveDraftTest() throws Exception, BusinessException {
		Gson gson = new GsonBuilder().setDateFormat("dd-MM-yyyy'T'HH:mm:ss").create();
		DraftDTO<CoalPositionBO> draftDTO = gson.fromJson(jsonschDraft, DraftDTO.class);
		
		Draft<CoalPositionBO> savedDraft = coalPositionService.saveAsDraft(draftDTO);
		ResponseEntity<WSResp<Draft<CoalPositionBO>>> respSavedDraft = new ResponseEntity<WSResp<Draft<CoalPositionBO>>>(new WSResp<Draft<CoalPositionBO>>(savedDraft, true, "Draft Data Saved Successfully!"), HttpStatus.OK);
		Mockito.when(coalPositionController.saveCoalPositionAsDraft(draftDTO)).thenReturn(respSavedDraft);
		
		String uri = "/coal-position/saveDraft";
		MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.post(uri)
				.contentType(MediaType.APPLICATION_JSON)
		        .content(objectMapper.writeValueAsString(draftDTO)))
				.andReturn();
		int status = mvcResult.getResponse().getStatus();

		assertEquals(200, status);
	}

}