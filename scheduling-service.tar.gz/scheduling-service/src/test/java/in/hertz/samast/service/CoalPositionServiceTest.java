/**
 * 
 */
package in.hertz.samast.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.context.WebApplicationContext;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import in.hertz.samast.domain.CoalPositionBO;
import in.hertz.samast.domain.DraftDTO;
import in.hertz.samast.domain.exception.BusinessException;
import in.hertz.samast.entity.Draft;
import in.hertz.samast.entity.TimeInterval;

/**
 * @author Bibhuti Parida
 *
 */
@ExtendWith(MockitoExtension.class)
@AutoConfigureMockMvc
@WebAppConfiguration
@ContextConfiguration(classes = {CoalPositionService.class, WebApplicationContext.class})
@WebMvcTest(controllers = CoalPositionService.class)
public class CoalPositionServiceTest {

	@MockBean
    private CoalPositionServiceImpl coalPositionService;
	
	@Autowired
    protected MockMvc mockMvc;

	private String jsonschcoaal =
			"	{						"+
			"	  \"closingBalance\": 10, "+
			"	  \"coalConsumed\": 10, "+
			"	  \"coalPositionId\": 0, "+
			"	  \"coalReceived\": 20, "+
			"	  \"createdBy\": \"string\", "+
			"	  \"forDate\": \"01-07-2022T12:04:38\", "+
			"	  \"generatorName\": \"string\", "+
			"	  \"openingBalance\": 30, "+
			"	  \"utgId\": 61 "+
			"	} ";
			
	private String jsonschDraft = 
    		"	{ "+
    		"	  \"createdBy\": \"Bibhuti Test\", "+
    		"	  \"createdDate\": null, "+
    		"	  \"currentStage\": \"\", "+
    		"	  \"entityRegistrationDTO\": null, "+
    		"	  \"functionalityArea\": \"Scheduling_DC_Test\", "+
    		"	  \"modifiedBy\": \"string\", "+
    		"	  \"modifiedDate\": null, "+
    		"	  \"jsonDTO\": { "+
    		"	  \"closingBalance\": 10, "+
    		"	  \"coalConsumed\": 10, "+
    		"	  \"coalPositionId\": 0, "+
    		"	  \"coalReceived\": 20, "+
    		"	  \"createdBy\": \"string\", "+
    		"	  \"forDate\": \"01-07-2022T12:04:38\", "+
    		"	  \"generatorName\": \"string\", "+
    		"	  \"openingBalance\": 30, "+
    		"	  \"utgId\": 61 "+
    		"	}, " +
    		"	  \"status\": \"Testing New\" "+
    		"	}		";
	
	@Test
	public void newCoalPositionTest()  throws Exception, BusinessException {
		Gson gson = new GsonBuilder().setDateFormat("dd-MM-yyyy'T'HH:mm:ss").create();
		CoalPositionBO schDto = gson.fromJson(jsonschcoaal, CoalPositionBO.class);
		Mockito.when(coalPositionService.newCoalPosition(new Date(), 61)).thenReturn(schDto);
	}

	@Test
	public void saveCoalPositionTest()  throws Exception, BusinessException {
		Gson gson = new GsonBuilder().setDateFormat("dd-MM-yyyy'T'HH:mm:ss").create();
		CoalPositionBO schDto = gson.fromJson(jsonschcoaal, CoalPositionBO.class);
		Mockito.when(coalPositionService.saveCoalPosition(schDto)).thenReturn(schDto);
	}

	@Test
	public void getAllCoalPositionsTest()  throws Exception, BusinessException {
		Gson gson = new GsonBuilder().setDateFormat("dd-MM-yyyy'T'HH:mm:ss").create();
		CoalPositionBO schDto = gson.fromJson(jsonschcoaal, CoalPositionBO.class);
		List<CoalPositionBO> coalPosList = new ArrayList<CoalPositionBO>();
		coalPosList.add(schDto);
		Mockito.when(coalPositionService.getAllCoalPositions()).thenReturn(coalPosList);
	}

	@Test
	public void getCoalPositionByDateTest()  throws Exception, BusinessException {
		Gson gson = new GsonBuilder().setDateFormat("dd-MM-yyyy'T'HH:mm:ss").create();
		CoalPositionBO schDto = gson.fromJson(jsonschcoaal, CoalPositionBO.class);
		Mockito.when(coalPositionService.getCoalPositionByDate(new Date(), 61)).thenReturn(schDto);
	}
	
	@Test
	public void updateCoalPositionTest()  throws Exception, BusinessException {
		Gson gson = new GsonBuilder().setDateFormat("dd-MM-yyyy'T'HH:mm:ss").create();
		CoalPositionBO schDto = gson.fromJson(jsonschcoaal, CoalPositionBO.class);
		Mockito.when(coalPositionService.updateCoalPosition(schDto)).thenReturn(schDto);
	}

	@SuppressWarnings("unchecked")
	@Test
	public void saveAsDraftTest()  throws Exception, BusinessException {
		Draft<CoalPositionBO> draft = new Draft<CoalPositionBO>();
		Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").create();
		DraftDTO<CoalPositionBO> draftDTO = gson.fromJson(jsonschDraft, DraftDTO.class);
		Mockito.when(coalPositionService.saveAsDraft(draftDTO)).thenReturn(draft);
	}

	@Test
	public void getDraftedCoalPositionByDateAndUtgIdTest()  throws Exception, BusinessException {
		Draft<CoalPositionBO> draft = new Draft<CoalPositionBO>();
		Mockito.when(coalPositionService.getDraftedCoalPositionByDateAndUtgId(new Date(), 61)).thenReturn(draft);
	}
	
	@Test
	public void getCurrentTimeBlockTest()  throws Exception, BusinessException {
		TimeInterval t = new TimeInterval();
		Mockito.when(coalPositionService.getCurrentTimeBlock()).thenReturn(t);
	}
			
}
