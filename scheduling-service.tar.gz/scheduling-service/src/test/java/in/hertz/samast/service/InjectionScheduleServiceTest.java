/**
 * 
 */
package in.hertz.samast.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.context.WebApplicationContext;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import in.hertz.samast.domain.DraftDTO;
import in.hertz.samast.domain.InjectionScheduleBO;
import in.hertz.samast.domain.InjectionScheduleSummaryBO;
import in.hertz.samast.domain.PSSDetailsDTO;
import in.hertz.samast.domain.exception.BusinessException;
import in.hertz.samast.entity.Draft;
import in.hertz.samast.entity.TimeInterval;

/**
 * @author Bibhuti Parida
 *
 */
@ExtendWith(MockitoExtension.class)
@AutoConfigureMockMvc
@WebAppConfiguration
@ContextConfiguration(classes = {InjectionScheduleServiceImpl.class, WebApplicationContext.class})
@WebMvcTest(controllers = InjectionScheduleServiceImpl.class)
public class InjectionScheduleServiceTest {

	@MockBean
	private InjectionScheduleServiceImpl injectionScheduleQCAService;
	
	@Autowired
    protected MockMvc mockMvc;
	
	private String jsonschDraft = 
    		"	{ "+
    		"	  \"createdBy\": \"Bibhuti Test\", "+
    		"	  \"createdDate\": null, "+
    		"	  \"currentStage\": \"\", "+
    		"	  \"functionalityArea\": \"Scheduling_DC_Test\", "+
    		"	  \"modifiedBy\": \"string\", "+
    		"	  \"modifiedDate\": null, "+
    		"	  \"jsonDTO\": { "+
    		"	    \"approvedBy\": 0, "+
    		"	    \"approvedDate\": null , "+
    		"	    \"forDate\": \"2022-06-21\", "+
    		"	    \"issueDate\": \"2022-06-21 05:09:03\", "+
    		"	    \"injectionScheduleDetail\": [ "+
    		"	      { "+
    		"	    	\"availableCapacity\": 0, 	"+
    		"	    	\"dayAheadForcast\": 0,		"+
    		"	    	\"injectionScheduleUID\": 0,"+
    		"	    	\"quantum\": 0,				"+
    		"	    	\"timeIntervalId\": 0		"+
    		"	      } "+
    		"	    ], "+
    		"	    \"remarks\": \"Testing Remarks\", "+
    		"	    \"revisionNumber\": -1, "+
    		"	    \"injectionUtgId\": 0, "+
    		"	    \"status\": \"Testing New\" "+
    		"	  }, "+
    		"	  \"status\": \"Testing New\" "+
    		"	}		";

	private String jsonschIS =
	    	"{" +
	        "\"forDate\": \"2022-06-14\","+
	        "\"issueDate\": \"2022-06-14 11:07:59\","+
	        "\"revisionNumber\": -1,"+
	        "\"dataSource\": \"NRLDC\","+
	        "\"injectionName\": \"Sedam-Mercury \","+
	        "\"injectionUtgId\": 67,"+
	        "\"approvedBy\": null,"+
	        "\"approvedDate\": null,"+
	        "\"status\": null,"+
	        "\"remarks\": null,"+
	        "\"injectionScheduleDetail\": ["+
	        "    { " +
	        "        \"timeIntervalId\": 1,"+
	        "        \"quantum\": 0.0,"+
	        "        \"availableCapacity\": null,"+
	        "        \"injectionScheduleUID\": 10.0,"+
	        "         \"dayAheadForcast\": 11.0"+
	        "    }, "+
	        "    { "+
	        "        \"timeIntervalId\": 2,"+
	        "        \"quantum\": 0.0,"+
	        "        \"availableCapacity\": null,"+
	        "        \"injectionScheduleUID\": 10.0,"+
	        "         \"dayAheadForcast\": 11.0"+
	        "    }"+
	        "]"+
	    "}";
	
	@Test
	public void getPSSListByQCAIdTest()  throws Exception, BusinessException {
		List<PSSDetailsDTO> pssList = new ArrayList<PSSDetailsDTO>();
		Mockito.when(injectionScheduleQCAService.getPSSListByQCAId(1)).thenReturn(pssList);
	}
	
	@Test
	public void getDeclaredCapacityByUTGLatestRevTest()  throws Exception, BusinessException {
		List<InjectionScheduleBO> injectionScheduleList = new ArrayList<InjectionScheduleBO>();
		Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").create();
		InjectionScheduleBO schDto = gson.fromJson(jsonschIS, InjectionScheduleBO.class);
		injectionScheduleList.add(schDto);
		Mockito.when(injectionScheduleQCAService.getPSSSummary(new Date(), 1)).thenReturn(injectionScheduleList);
	}
	
	@Test
	public void getInjectionScheduleByUTGTest()  throws Exception, BusinessException {
		Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").create();
		InjectionScheduleBO schDto = gson.fromJson(jsonschIS, InjectionScheduleBO.class);
		Mockito.when(injectionScheduleQCAService.getInjectionScheduleByUTG(new Date(), 1)).thenReturn(schDto);
	}

	
	@Test
	public void getInjectionScheduleByRevisionNoTest()  throws Exception, BusinessException {
		Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").create();
		InjectionScheduleBO schDto = gson.fromJson(jsonschIS, InjectionScheduleBO.class);
		Mockito.when(injectionScheduleQCAService.getInjectionScheduleByRevisionNo(new Date(), 1, 1)).thenReturn(schDto);
	}

	@Test
	public void getCurrentTimeBlockTest()  throws Exception, BusinessException {
		TimeInterval t = new TimeInterval();
		Mockito.when(injectionScheduleQCAService.getCurrentTimeBlock()).thenReturn(t);
	}
	
	@Test
	public void getExBusCapacityTest()  throws Exception, BusinessException {
		Integer exBusCapacity = new Integer(61);
		Mockito.when(injectionScheduleQCAService.getExBusCapacity(61)).thenReturn(exBusCapacity);
	}

	@Test
	public void getRevisionNoByScheduleTypeTest()  throws Exception, BusinessException {
		List<Integer> revisionList = new ArrayList<Integer>();
		Mockito.when(injectionScheduleQCAService.getRevisionNoByScheduleType(new Date(), 1, "DayAhead")).thenReturn(revisionList);
	}
	
	@Test
	public void getAllRevisionNoTest()  throws Exception, BusinessException {
		List<Integer> revisionList = new ArrayList<Integer>();
		Mockito.when(injectionScheduleQCAService.getAllRevisionNo(new Date(), 1)).thenReturn(revisionList);
	}

	@Test
	public void getLatestRevisionNoByUTG()  throws Exception, BusinessException {
		Mockito.when(injectionScheduleQCAService.getLatestRevisionNoByUTG(new Date(), 1)).thenReturn(new Integer(0));
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void saveDraftTest()  throws Exception, BusinessException {
		Draft<InjectionScheduleBO> draft = new Draft<InjectionScheduleBO>();
		Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").create();
		DraftDTO<InjectionScheduleBO> draftDTO = gson.fromJson(jsonschDraft, DraftDTO.class);
		Mockito.when(injectionScheduleQCAService.saveDraft(draftDTO)).thenReturn(draft);
	}

	@Test
	public void fetchDraftDataTest()  throws Exception, BusinessException {
		Draft<InjectionScheduleBO> draft = new Draft<InjectionScheduleBO>();
		Mockito.when(injectionScheduleQCAService.fetchDraftData(new Date(), 61)).thenReturn(draft);
	}

	@Test
	public void newInjectionScheduleTest()  throws Exception, BusinessException {
		Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").create();
		InjectionScheduleBO schDto = gson.fromJson(jsonschIS, InjectionScheduleBO.class);
		Mockito.when(injectionScheduleQCAService.newInjectionSchedule(new Date(), 61)).thenReturn(schDto);
	}
	
	@Test
	public void saveDCTest()  throws Exception, BusinessException {
		Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").create();
		InjectionScheduleBO schDto = gson.fromJson(jsonschIS, InjectionScheduleBO.class);
		Mockito.when(injectionScheduleQCAService.saveInjectionSchedule(schDto)).thenReturn(schDto);
	}

	
	@Test
	public void getInjectionSummaryListByQCAIdTest()  throws Exception, BusinessException {
		Mockito.when(injectionScheduleQCAService.getInjectionSummaryListByQCAId(1, new Date())).thenReturn(new ArrayList<InjectionScheduleSummaryBO>());
	}
	
	@Test
	public void getInjectionScheduleByRevisionNoScheduleTypeTest()  throws Exception, BusinessException {
		Mockito.when(injectionScheduleQCAService.getInjectionScheduleByRevisionNoScheduleType(new Date(), 1, 1, "DayAhead")).thenReturn(new InjectionScheduleBO());
	}

}
