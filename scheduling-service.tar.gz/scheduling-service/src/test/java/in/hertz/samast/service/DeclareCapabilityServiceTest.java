/**
 * 
 */
package in.hertz.samast.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.context.WebApplicationContext;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import in.hertz.samast.domain.DraftDTO;
import in.hertz.samast.domain.ScheduleQuantumBaseDTO;
import in.hertz.samast.domain.exception.BusinessException;
import in.hertz.samast.entity.Draft;
import in.hertz.samast.entity.TimeInterval;


/**
 * @author Bibhuti Parida
 *
 */
@ExtendWith(MockitoExtension.class)
@AutoConfigureMockMvc
@WebAppConfiguration
@ContextConfiguration(classes = {DeclareCapacityServiceImpl.class, WebApplicationContext.class})
@WebMvcTest(controllers = DeclareCapacityServiceImpl.class)
public class DeclareCapabilityServiceTest {

	@MockBean
    private DeclareCapacityServiceImpl declareCapabilityService;
	
	@Autowired
    protected MockMvc mockMvc;

	private String jsonschDC =
		    	"{" +
		        "\"forDate\": \"2022-06-14\","+
		        "\"issueDate\": \"2022-06-14 11:07:59\","+
		        "\"revision\": -1,"+
		        "\"dataSource\": \"NRLDC\","+
		        "\"sellerEntity\": \"Sedam-Mercury \","+
		        "\"buyerEntity\": null,"+
		        "\"sellerUTGId\": 67,"+
		        "\"buyerUTGId\": null,"+
		        "\"contractType\": null,"+
		        "\"approvedBy\": null,"+
		        "\"approvedDate\": null,"+
		        "\"status\": null,"+
		        "\"remarks\": null,"+
		        "\"quantumList\": ["+
		        "    { " +
		        "        \"timeBlock\": 2,"+
		        "        \"time\": null,"+
		        "        \"quantum\": 0.0,"+
		        "        \"availedQuantum\": null,"+
		        "        \"frequency\": null,"+
		        "        \"offBarQuantum\": 10.0,"+
		        "         \"onBarQuantum\": 11.0,"+
		        "        \"sellerDcQuantum\": null,"+
		        "        \"status\": null,"+
		        "        \"combinedDC\": null,"+
		        "        \"openDC\": null"+
		        "    }, "+
		        "    { "+
		        "        \"timeBlock\": 1,"+
		        "        \"time\": null, "+
		        "        \"quantum\": 0.0, "+
		        "        \"availedQuantum\": null,"+
		        "        \"frequency\": null,"+
		        "        \"offBarQuantum\": 10.0,"+
		        "        \"onBarQuantum\": 11.0,"+
		        "        \"sellerDcQuantum\": null,"+
		        "        \"status\": null,"+
		        "        \"combinedDC\": null,"+
		        "        \"openDC\": null"+
		        "    }"+
		        "]"+
		    "}";

	private String jsonschDraft = 
    		"	{ "+
    		"	  \"createdBy\": \"Bibhuti Test\", "+
    		"	  \"createdDate\": null, "+
    		"	  \"currentStage\": \"\", "+
    		"	  \"entityRegistrationDTO\": null, "+
    		"	  \"functionalityArea\": \"Scheduling_DC_Test\", "+
    		"	  \"modifiedBy\": \"string\", "+
    		"	  \"modifiedDate\": null, "+
    		"	  \"jsonDTO\": { "+
    		"	    \"approvedBy\": 0, "+
    		"	    \"approvedDate\": null , "+
    		"	    \"buyerEntity\": \"string\", "+
    		"	    \"buyerUTGId\": 0, "+
    		"	    \"contractType\": \"string\", "+
    		"	    \"dataSource\": \"NRLDC\", "+
    		"	    \"forDate\": \"2022-06-21\", "+
    		"	    \"issueDate\": \"2022-06-21 05:09:03\", "+
    		"	    \"quantumList\": [ "+
    		"	      { "+
    		"	        \"availedQuantum\": 0, "+
    		"	        \"combinedDC\": 0, "+
    		"	        \"frequency\": 0, "+
    		"	        \"offBarQuantum\": 10, "+
    		"	        \"onBarQuantum\": 10, "+
    		"	        \"openDC\": 0, "+
    		"	        \"quantum\": 0, "+
    		"	        \"sellerDcQuantum\": 0, "+
    		"	        \"status\": true, "+
    		"	        \"time\": \"string\", "+
    		"	        \"timeBlock\": -1 "+
    		"	      } "+
    		"	    ], "+
    		"	    \"remarks\": \"Testing Remarks\", "+
    		"	    \"revision\": -1, "+
    		"	    \"sellerEntity\": \"string\", "+
    		"	    \"sellerUTGId\": 0, "+
    		"	    \"status\": \"Testing New\" "+
    		"	  }, "+
    		"	  \"status\": \"Testing New\" "+
    		"	}		";
	
	@Test
	public void getDeclaredCapacityByUTGLatestRevTest()  throws Exception, BusinessException {
		
		Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").create();
		ScheduleQuantumBaseDTO schDto = gson.fromJson(jsonschDC, ScheduleQuantumBaseDTO.class);
		Mockito.when(declareCapabilityService.getDeclaredCapacityByUTG(new Date(), 61, -1)).thenReturn(schDto);
	}
	
	@Test
	public void getDeclaredCapacityByUTGTest()  throws Exception, BusinessException {
		
		Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").create();
		ScheduleQuantumBaseDTO schDto = gson.fromJson(jsonschDC, ScheduleQuantumBaseDTO.class);
		Mockito.when(declareCapabilityService.getDeclaredCapacityByUTG(new Date(), 61)).thenReturn(schDto);
	}
	
	@Test
	public void saveDCTest()  throws Exception, BusinessException {
		Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").create();
		ScheduleQuantumBaseDTO schDto = gson.fromJson(jsonschDC, ScheduleQuantumBaseDTO.class);
		Mockito.when(declareCapabilityService.saveDC(schDto)).thenReturn(schDto);
	}

	@Test
	public void getCurrentTimeBlockTest()  throws Exception, BusinessException {
		TimeInterval t = new TimeInterval();
		Mockito.when(declareCapabilityService.getCurrentTimeBlock()).thenReturn(t);
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void saveDraftTest()  throws Exception, BusinessException {
		Draft<ScheduleQuantumBaseDTO> draft = new Draft<ScheduleQuantumBaseDTO>();
		Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").create();
		DraftDTO<ScheduleQuantumBaseDTO> draftDTO = gson.fromJson(jsonschDraft, DraftDTO.class);
		Mockito.when(declareCapabilityService.saveDraft(draftDTO)).thenReturn(draft);
	}

	@Test
	public void fetchDraftDataTest()  throws Exception, BusinessException {
		Draft<ScheduleQuantumBaseDTO> draft = new Draft<ScheduleQuantumBaseDTO>();
		Mockito.when(declareCapabilityService.fetchDraftData(new Date(), 61)).thenReturn(draft);
	}

	@Test
	public void newDeclareCapacityTest()  throws Exception, BusinessException {
		
		Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").create();
		ScheduleQuantumBaseDTO schDto = gson.fromJson(jsonschDC, ScheduleQuantumBaseDTO.class);
		Mockito.when(declareCapabilityService.newDeclareCapacity(new Date(), 61)).thenReturn(schDto);
	}
	
	@Test
	public void getAllDeclaredCapacityTest()  throws Exception, BusinessException {
		List<ScheduleQuantumBaseDTO> schList = new ArrayList<ScheduleQuantumBaseDTO>();
		Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").create();
		ScheduleQuantumBaseDTO schDto = gson.fromJson(jsonschDC, ScheduleQuantumBaseDTO.class);
		schList.add(schDto);
		Mockito.when(declareCapabilityService.getAllDeclaredCapacity()).thenReturn(schList);
	}

	@Test
	public void getAllRevisionNoTest()  throws Exception, BusinessException {
		List<Integer> revList = new ArrayList<Integer>();
		Mockito.when(declareCapabilityService.getAllRevisionNo(new Date(), 61)).thenReturn(revList);
	}
	
	@Test
	public void getLatestRevisionNoByUTGTest()  throws Exception, BusinessException {
		Integer revNo = new Integer(1);
		Mockito.when(declareCapabilityService.getLatestRevisionNoByUTG(new Date(), 61)).thenReturn(revNo);
	}
	
	@Test
	public void getExBusCapacityTest()  throws Exception, BusinessException {
		Integer exBusCapacity = new Integer(61);
		Mockito.when(declareCapabilityService.getExBusCapacity(61)).thenReturn(exBusCapacity);
	}
	
	@Test
	public void getRevisionNoByDCTypeTest()  throws Exception, BusinessException {
		List<Integer> revList = new ArrayList<Integer>();
		Mockito.when(declareCapabilityService.getRevisionNoByDCType(new Date(), 61, "DayAhead")).thenReturn(revList);
	}
}
