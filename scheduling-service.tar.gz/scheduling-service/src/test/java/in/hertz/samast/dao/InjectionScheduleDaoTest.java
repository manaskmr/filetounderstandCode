/**
 * 
 */
package in.hertz.samast.dao;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.web.context.WebApplicationContext;

import in.hertz.samast.entity.InjectionSchedule;

/**
 * @author Bibhuti Parida
 *
 */
@ExtendWith(MockitoExtension.class)
@AutoConfigureMockMvc
@WebAppConfiguration
@ContextConfiguration(classes = {InjectionScheduleDao.class, WebApplicationContext.class})
@WebMvcTest(controllers = InjectionScheduleDao.class)
public class InjectionScheduleDaoTest {

	@MockBean
	private InjectionScheduleDao injectionScheduleDao;
	
	@Test
	public void findAllTest() {
		List<InjectionSchedule> genUnitTypeList = injectionScheduleDao.findAll();
		assertNotNull(genUnitTypeList);
	}
	
	@Test
	public void findByIdTest() {
		Optional<InjectionSchedule> genUnitType = injectionScheduleDao.findById(1);
		assertNotNull(genUnitType);
	}
}
