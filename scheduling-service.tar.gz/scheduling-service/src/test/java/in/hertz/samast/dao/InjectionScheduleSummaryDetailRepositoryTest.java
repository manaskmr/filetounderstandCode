/**
 * 
 */
package in.hertz.samast.dao;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.web.context.WebApplicationContext;

import in.hertz.samast.entity.InjectionScheduleSummaryDetail;

/**
 * @author Bibhuti Parida
 *
 */
@ExtendWith(MockitoExtension.class)
@AutoConfigureMockMvc
@WebAppConfiguration
@ContextConfiguration(classes = {InjectionScheduleSummaryDetailRepository.class, WebApplicationContext.class})
@WebMvcTest(controllers = InjectionScheduleSummaryDetailRepository.class)
public class InjectionScheduleSummaryDetailRepositoryTest {

	@MockBean
	private InjectionScheduleSummaryDetailRepository injectionScheduleSummaryDetailRepository;
	
	@Test
	public void findAllTest() {
		List<InjectionScheduleSummaryDetail> isDetailList = injectionScheduleSummaryDetailRepository.findAll();
		assertNotNull(isDetailList);
	}
	
	@Test
	public void findByIdTest() {
		Optional<InjectionScheduleSummaryDetail> isDetail = injectionScheduleSummaryDetailRepository.findById(1);
		assertNotNull(isDetail);
	}
}
