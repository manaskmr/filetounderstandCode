/**
 * 
 */
package in.hertz.samast.ctrl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import in.hertz.samast.domain.DraftDTO;
import in.hertz.samast.domain.ScheduleQuantumBaseDTO;
import in.hertz.samast.domain.WSResp;
import in.hertz.samast.domain.exception.BusinessException;
import in.hertz.samast.entity.Draft;
import in.hertz.samast.entity.TimeInterval;
import in.hertz.samast.service.DeclareCapacityService;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import org.mockito.junit.jupiter.MockitoExtension;
/**
 * 
 * @author Bibhuti Parida
 *
 */
@ExtendWith(MockitoExtension.class)
@AutoConfigureMockMvc
@WebAppConfiguration
@ContextConfiguration(classes = {DeclareCapacityCtrl.class, WebApplicationContext.class})
@WebMvcTest(controllers = DeclareCapacityCtrl.class)
public class DeclareCapacityCtrlTest {

	@Autowired
    protected MockMvc mockMvc;
    
    @MockBean
	protected DeclareCapacityCtrl declareCapacityCtrl;
    
    @MockBean
	protected DeclareCapacityService declareCapacityService;
    
    @Autowired
    private ObjectMapper objectMapper;
    
    private String jsonschDC =
    	"{" +
        "\"forDate\": \"2022-06-14\","+
        "\"issueDate\": \"2022-06-24T09:47:51+530\","+
        "\"revision\": -1,"+
        "\"dataSource\": \"NRLDC\","+
        "\"sellerEntity\": \"Sedam-Mercury \","+
        "\"buyerEntity\": null,"+
        "\"sellerUTGId\": 67,"+
        "\"buyerUTGId\": null,"+
        "\"contractType\": null,"+
        "\"approvedBy\": null,"+
        "\"approvedDate\": null,"+
        "\"status\": null,"+
        "\"remarks\": null,"+
        "\"quantumList\": ["+
        "    { " +
        "        \"timeBlock\": 2,"+
        "        \"time\": null,"+
        "        \"quantum\": 0.0,"+
        "        \"availedQuantum\": null,"+
        "        \"frequency\": null,"+
        "        \"offBarQuantum\": 10.0,"+
        "         \"onBarQuantum\": 11.0,"+
        "        \"sellerDcQuantum\": null,"+
        "        \"status\": null,"+
        "        \"combinedDC\": null,"+
        "        \"openDC\": null"+
        "    }, "+
        "    { "+
        "        \"timeBlock\": 1,"+
        "        \"time\": null, "+
        "        \"quantum\": 0.0, "+
        "        \"availedQuantum\": null,"+
        "        \"frequency\": null,"+
        "        \"offBarQuantum\": 10.0,"+
        "        \"onBarQuantum\": 11.0,"+
        "        \"sellerDcQuantum\": null,"+
        "        \"status\": null,"+
        "        \"combinedDC\": null,"+
        "        \"openDC\": null"+
        "    }"+
        "]"+
    "}";

    private String jsonschDraft = 
    		"	{ "+
    		"	  \"createdBy\": \"Bibhuti Test\", "+
    		"	  \"createdDate\": null, "+
    		"	  \"currentStage\": \"\", "+
    		"	  \"entityRegistrationDTO\": null, "+
    		"	  \"functionalityArea\": \"Scheduling_DC_Test\", "+
    		"	  \"modifiedBy\": \"string\", "+
    		"	  \"modifiedDate\": null, "+
    		"	  \"jsonDTO\": { "+
    		"	    \"approvedBy\": 0, "+
    		"	    \"approvedDate\": null , "+
    		"	    \"buyerEntity\": \"string\", "+
    		"	    \"buyerUTGId\": 0, "+
    		"	    \"contractType\": \"string\", "+
    		"	    \"dataSource\": \"NRLDC\", "+
    		"	    \"forDate\": \"2022-06-21\", "+
    		"	    \"issueDate\": \"2022-06-24T09:47:51\", "+
    		"	    \"quantumList\": [ "+
    		"	      { "+
    		"	        \"availedQuantum\": 0, "+
    		"	        \"combinedDC\": 0, "+
    		"	        \"frequency\": 0, "+
    		"	        \"offBarQuantum\": 10, "+
    		"	        \"onBarQuantum\": 10, "+
    		"	        \"openDC\": 0, "+
    		"	        \"quantum\": 0, "+
    		"	        \"sellerDcQuantum\": 0, "+
    		"	        \"status\": true, "+
    		"	        \"time\": \"string\", "+
    		"	        \"timeBlock\": -1 "+
    		"	      } "+
    		"	    ], "+
    		"	    \"remarks\": \"Testing Remarks\", "+
    		"	    \"revision\": -1, "+
    		"	    \"sellerEntity\": \"string\", "+
    		"	    \"sellerUTGId\": 0, "+
    		"	    \"status\": \"Testing New\" "+
    		"	  }, "+
    		"	  \"status\": \"Testing New\" "+
    		"	}		";

	@Test
	public void getDeclaredCapacityTest() throws Exception, BusinessException {
		
		Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd'T'HH:mm:ss").create();
		ScheduleQuantumBaseDTO schDto = gson.fromJson(jsonschDC, ScheduleQuantumBaseDTO.class);
		ResponseEntity<WSResp<ScheduleQuantumBaseDTO>> respDc = new ResponseEntity<WSResp<ScheduleQuantumBaseDTO>>(new WSResp<ScheduleQuantumBaseDTO>(schDto, true, "DC Data Fetched Successfully!"), HttpStatus.OK);
		Mockito.when(declareCapacityCtrl.getDeclaredCapacity(61, new Date())).thenReturn(respDc);
		
		String uri = "/declare-capacity/61/2022-06-15";
		MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();
		int status = mvcResult.getResponse().getStatus();

		assertEquals(200, status);
	}
	
	@Test
	public void getDeclaredCapacityByRevisionNoTest() throws Exception, BusinessException {
		Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd'T'HH:mm:ss").create();
		ScheduleQuantumBaseDTO schDto = gson.fromJson(jsonschDC, ScheduleQuantumBaseDTO.class);
		ResponseEntity<WSResp<ScheduleQuantumBaseDTO>> respDc = new ResponseEntity<WSResp<ScheduleQuantumBaseDTO>>(new WSResp<ScheduleQuantumBaseDTO>(schDto, true, "DC Data Fetched Successfully!"), HttpStatus.OK);
		Mockito.when(declareCapacityCtrl.getDeclaredCapacityByRevisionNo(61, new Date(), -1)).thenReturn(respDc);
		
		String uri = "/declare-capacity/findDCByRevNo/61/2022-06-15/-1";
		MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();
		int status = mvcResult.getResponse().getStatus();

		assertEquals(200, status);
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void saveDraftTest() throws Exception, BusinessException {
		
		Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd'T'HH:mm:ss").create();
		DraftDTO<ScheduleQuantumBaseDTO> draftDTO = gson.fromJson(jsonschDraft, DraftDTO.class);
		
		Draft<ScheduleQuantumBaseDTO> savedDraft = declareCapacityService.saveDraft(draftDTO);
		ResponseEntity<WSResp<Draft<ScheduleQuantumBaseDTO>>> respSavedDraft = new ResponseEntity<WSResp<Draft<ScheduleQuantumBaseDTO>>>(new WSResp<Draft<ScheduleQuantumBaseDTO>>(savedDraft, true, "Draft Data Saved Successfully!"), HttpStatus.OK);
		Mockito.when(declareCapacityCtrl.saveDraft(draftDTO)).thenReturn(respSavedDraft);
		
		String uri = "/declare-capacity/saveDraft";
		MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.post(uri)
				.contentType(MediaType.APPLICATION_JSON)
		        .content(objectMapper.writeValueAsString(draftDTO)))
				.andReturn();
		int status = mvcResult.getResponse().getStatus();

		assertEquals(200, status);
	}

	@Test
	public void findDraftTest() throws Exception, BusinessException {
		Draft<ScheduleQuantumBaseDTO> draftDTO = declareCapacityService.fetchDraftData(new Date(), 61);
		ResponseEntity<WSResp<Draft<ScheduleQuantumBaseDTO>>> respDraft = new ResponseEntity<WSResp<Draft<ScheduleQuantumBaseDTO>>>(
				new WSResp<Draft<ScheduleQuantumBaseDTO>>(draftDTO, true, "Data Fetched Successfully!"),
				HttpStatus.OK);
		Mockito.when(declareCapacityCtrl.findDraft(61, new Date())).thenReturn(respDraft);
		
		String uri = "/declare-capacity/findDraft/61/2022-06-21";
		MvcResult mvcResult =  mockMvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();
		int status = mvcResult.getResponse().getStatus();

		assertEquals(200, status);
	}
	
	@Test
	public void saveDeclareCapacityTest() throws Exception, BusinessException {
		
		Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd'T'HH:mm:ss").create();
		ScheduleQuantumBaseDTO dcDTO = gson.fromJson(jsonschDC, ScheduleQuantumBaseDTO.class);
		ResponseEntity<WSResp<ScheduleQuantumBaseDTO>> respSavedDC = new ResponseEntity<WSResp<ScheduleQuantumBaseDTO>>(
				new WSResp<ScheduleQuantumBaseDTO>(dcDTO, true, "DC Data Saved Successfully!"), HttpStatus.OK);
		Mockito.when(declareCapacityCtrl.saveDeclareCapacity(dcDTO)).thenReturn(respSavedDC);
		
		String uri = "/declare-capacity/saveDC";
		MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.post(uri)
				.contentType(MediaType.APPLICATION_JSON)
		        .content(objectMapper.writeValueAsString(dcDTO)))
				.andReturn();
		int status = mvcResult.getResponse().getStatus();

		assertEquals(200, status);
	}
	
	@Test
	public void newDeclareCapacityTest() throws Exception, BusinessException {
		ScheduleQuantumBaseDTO dcDTO = declareCapacityService.newDeclareCapacity(new Date(), 61);
		ResponseEntity<WSResp<ScheduleQuantumBaseDTO>> respDc = new ResponseEntity<WSResp<ScheduleQuantumBaseDTO>>(
				new WSResp<ScheduleQuantumBaseDTO>(dcDTO, true, "DC Data Saved Successfully!"), HttpStatus.OK);
		Mockito.when(declareCapacityCtrl.newDeclareCapacity(61, new Date())).thenReturn(respDc);
		
		String uri = "/declare-capacity/newDC/61/2022-06-21";
		MvcResult mvcResult =  mockMvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();
		int status = mvcResult.getResponse().getStatus();

		assertEquals(200, status);
	}
	
    @Test
	public void getAllDeclaredCapacityTest() throws Exception, BusinessException {
		List<ScheduleQuantumBaseDTO> dcBOList = new ArrayList<ScheduleQuantumBaseDTO>();
		Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd'T'HH:mm:ss").create();
		ScheduleQuantumBaseDTO schDto = gson.fromJson(jsonschDC, ScheduleQuantumBaseDTO.class);
		dcBOList.add(schDto);
		ResponseEntity<WSResp<List<ScheduleQuantumBaseDTO>>> respdcBOList = new ResponseEntity<WSResp<List<ScheduleQuantumBaseDTO>>>(
				new WSResp<List<ScheduleQuantumBaseDTO>>(dcBOList, true, "DC Data fetched Successfully!"),
				HttpStatus.OK);

		Mockito.when(declareCapacityCtrl.getAllDeclaredCapacity()).thenReturn(respdcBOList);

		String uri = "/declare-capacity/findAllDC";
		MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();
		int status = mvcResult.getResponse().getStatus();
		String content = mvcResult.getResponse().getContentAsString();

		assertEquals(200, status);
		assertNotNull(content);
		
        verify(declareCapacityCtrl,times(1)).getAllDeclaredCapacity();
        verifyNoMoreInteractions(declareCapacityCtrl);
	}
	
	@Test
	public void getCurrentTimeBlockTest() throws Exception, BusinessException {
		TimeInterval timeBlock = declareCapacityService.getCurrentTimeBlock();
		ResponseEntity<WSResp<TimeInterval>> respTMBlk = new ResponseEntity<WSResp<TimeInterval>>(
				new WSResp<TimeInterval>(timeBlock, true, "Time Block fetched Successfully!"), HttpStatus.OK);
		Mockito.when(declareCapacityCtrl.getCurrentTimeBlock()).thenReturn(respTMBlk);
		
		String uri = "/declare-capacity/findCurrentTimeBlock";
		MvcResult mvcResult =  mockMvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();
		int status = mvcResult.getResponse().getStatus();

		assertEquals(200, status);
	}
	
	@Test
	public void getAllRevisionNoTest() throws Exception, BusinessException {
		List<Integer> revisionList = declareCapacityService.getAllRevisionNo(new Date(), 61);
		
		ResponseEntity<WSResp<List<Integer>>> respRevNo = new ResponseEntity<WSResp<List<Integer>>>(
				new WSResp<List<Integer>>(revisionList, true, "Revision Number fetched Successfully!"),
				HttpStatus.OK);
		Mockito.when(declareCapacityCtrl.getAllRevisionNo(61, new Date())).thenReturn(respRevNo);
		
		String uri = "/declare-capacity/findAllRevisionNo/61/2022-06-21";
		MvcResult mvcResult =  mockMvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();
		int status = mvcResult.getResponse().getStatus();

		assertEquals(200, status);
	}

	@Test
	public void getLatestRevisionNoTest() throws Exception, BusinessException {
		ResponseEntity<WSResp<String>> respRevNo = new ResponseEntity<WSResp<String>>(
				new WSResp<String>(new String(), true, "Revision Number fetched Successfully!"),
				HttpStatus.OK);
		Mockito.when(declareCapacityCtrl.getLatestRevisionNo(61, new Date())).thenReturn(respRevNo);
		
		String uri = "/declare-capacity/findLatestRevisionNo/61/2022-06-21";
		MvcResult mvcResult =  mockMvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();
		int status = mvcResult.getResponse().getStatus();

		assertEquals(200, status);
	}
	
	@Test
	public void getExBusCapacityTest() throws Exception, BusinessException {
		Integer exBusCapacity = declareCapacityService.getExBusCapacity(61);
		
		ResponseEntity<WSResp<Integer>> respExBusCapacity = new ResponseEntity<WSResp<Integer>>(
				new WSResp<Integer>(exBusCapacity, true, "Ex-Bus Capacity fetched Successfully!"),
				HttpStatus.OK);
		Mockito.when(declareCapacityCtrl.getExBusCapacity(61)).thenReturn(respExBusCapacity);
		
		String uri = "/declare-capacity/findExBusCapacity/61";
		MvcResult mvcResult =  mockMvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();
		int status = mvcResult.getResponse().getStatus();

		assertEquals(200, status);
	}
	
	@Test
	public void getRevisionNoByDCTypeTest() throws Exception, BusinessException {
		List<Integer> revisionList = declareCapacityService.getRevisionNoByDCType(new Date(), 61, "DayAhead");
		
		ResponseEntity<WSResp<List<Integer>>> respRevNoList = new ResponseEntity<WSResp<List<Integer>>>(
				new WSResp<List<Integer>>(revisionList, true, "Revision Number fetched Successfully!"),
				HttpStatus.OK);
		Mockito.when(declareCapacityCtrl.getRevisionNoByDCType(61, new Date(), "DayAhead")).thenReturn(respRevNoList);
		
		String uri = "/declare-capacity/findRevisionNoByDCType/61/2022-06-21/DayAhead";
		MvcResult mvcResult =  mockMvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();
		int status = mvcResult.getResponse().getStatus();

		assertEquals(200, status);
	}
}
