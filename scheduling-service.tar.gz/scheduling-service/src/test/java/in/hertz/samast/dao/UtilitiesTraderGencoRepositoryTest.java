/**
 * 
 */
package in.hertz.samast.dao;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.web.context.WebApplicationContext;

import in.hertz.samast.entity.UtilitiesTraderGenco;


/**
 * @author user
 *
 */
@ExtendWith(MockitoExtension.class)
@AutoConfigureMockMvc
@WebAppConfiguration
@ContextConfiguration(classes = {UtilitiesTraderGencoRepository.class, WebApplicationContext.class})
@WebMvcTest(controllers = UtilitiesTraderGencoRepository.class)
public class UtilitiesTraderGencoRepositoryTest {

	@MockBean
	private UtilitiesTraderGencoRepository utilitiesTraderGencoRepository;
	
	@Test
	public void findAllTest() {
		List<UtilitiesTraderGenco> genList = utilitiesTraderGencoRepository.findAll();
		assertNotNull(genList);
	}
	
	@Test
	public void findByIdTest() {
		Optional<UtilitiesTraderGenco> genTG = utilitiesTraderGencoRepository.findById(1);
		assertNotNull(genTG);
	}
}
