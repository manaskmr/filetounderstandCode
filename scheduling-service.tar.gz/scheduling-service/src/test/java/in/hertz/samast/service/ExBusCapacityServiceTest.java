/**
 * 
 */
package in.hertz.samast.service;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.context.WebApplicationContext;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import in.hertz.samast.domain.ExBusCapacityBO;
import in.hertz.samast.domain.GenerationUnitBO;
import in.hertz.samast.domain.exception.BusinessException;

/**
 * @author Bibhuti Parida
 *
 */
@ExtendWith(MockitoExtension.class)
@AutoConfigureMockMvc
@WebAppConfiguration
@ContextConfiguration(classes = {ExBusCapacityServiceImpl.class, WebApplicationContext.class})
@WebMvcTest(controllers = ExBusCapacityServiceImpl.class)
public class ExBusCapacityServiceTest {
	
	@MockBean
	private ExBusCapacityServiceImpl exBusCapacityService;
	
	@Autowired
    protected MockMvc mockMvc;
	
	private String jsonschexbus =
	"  {					"+
	"    \"exBusCapacity\": 0, "+
	"    \"exBusSldc\": 0,	"+
	"    \"id\": 0,			"+
	"    \"utgID\": 0			"+
	"  }					";
	
	@Test
	public void getExBusCapacityTest()  throws Exception, BusinessException {
		Integer exBusCapacity = new Integer(1);
		Mockito.when(exBusCapacityService.getExBusCapacity(61)).thenReturn(exBusCapacity);
	}
	
	@Test
	public void getAllExBusCapacityTest()  throws Exception, BusinessException {
		Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").create();
		ExBusCapacityBO exbusDTO = gson.fromJson(jsonschexbus, ExBusCapacityBO.class);
		List<ExBusCapacityBO> exBusList = new ArrayList<ExBusCapacityBO>();
		exBusList.add(exbusDTO);
		Mockito.when(exBusCapacityService.getAllExBusCapacity()).thenReturn(exBusList);
	}

	@Test
	public void getExBusCapacityByGenTypeTest()  throws Exception, BusinessException {
		Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").create();
		ExBusCapacityBO exbusDTO = gson.fromJson(jsonschexbus, ExBusCapacityBO.class);
		List<ExBusCapacityBO> exBusList = new ArrayList<ExBusCapacityBO>();
		exBusList.add(exbusDTO);
		Mockito.when(exBusCapacityService.getExBusCapacityByGenType(1)).thenReturn(exBusList);
	}
	
	@Test
	public void getAllGenTypeTest()  throws Exception, BusinessException {
		List<GenerationUnitBO> exBusList = new ArrayList<GenerationUnitBO>();
		Mockito.when(exBusCapacityService.getAllGenType()).thenReturn(exBusList);
	}
	
	@Test
	public void updateAllExBusCapacityTest()  throws Exception, BusinessException {
		Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").create();
		ExBusCapacityBO exbusBO = gson.fromJson(jsonschexbus, ExBusCapacityBO.class);
		List<ExBusCapacityBO> exbusBOList = new ArrayList<ExBusCapacityBO>();
		exbusBOList.add(exbusBO);
		Mockito.when(exBusCapacityService.updateAllExBusCapacity(exbusBOList)).thenReturn(exbusBOList);
	}
	
}
