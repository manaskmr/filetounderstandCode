/**
 * 
 */
package in.hertz.samast.ctrl;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import in.hertz.samast.domain.ForecastSubscriptionBO;
import in.hertz.samast.domain.ForecastSubscriptionUsagesBO;
import in.hertz.samast.domain.PSSDetailsDTO;
import in.hertz.samast.domain.WSResp;
import in.hertz.samast.domain.exception.BusinessException;

/**
 * @author Bibhuti Parida
 *
 */
@ExtendWith(MockitoExtension.class)
@AutoConfigureMockMvc
@WebAppConfiguration
@ContextConfiguration(classes = {ForecastSubscriptionCtrl.class, WebApplicationContext.class})
@WebMvcTest(controllers = ForecastSubscriptionCtrl.class)
public class ForecastSubscriptionCtrlTest {

	@MockBean
	private ForecastSubscriptionCtrl forecastSubscriptionCtrl;
	
	@Autowired
    protected MockMvc mockMvc;
	
	private String jsonschfsadd =
	    	"{" +
	    	"	    \"pssUtgId\": 240, "+
	    	"	    \"qcaUtgId\": null, "+
	    	"	    \"registrationNo\": \"ABCTest\", "+
	    	"	    \"noOfDays\": 10, "+
	    	"	    \"forecastServiceCostDay\": 3000, "+
	    	"	    \"forecastServiceCost\": 30000, "+
	    	"	    \"gstValue\": 5400, "+
	    	"	    \"totalAmt\": 35400, "+
	    	"	    \"rtgsNo\": \"TEstTest\" "+
	    	"}";
	
	private String jsonschfsupdate =
	    	"{" +
    		"	  \"forDate\": \"2022-07-11\", "+
    		"	  \"pssUtgid\": 240,			"+
    		"	  \"qcaUtgId\": null,			"+
    		"	  \"viewerUtgId\": 240			"+
	    	"}";
	
	
    @Autowired
    private ObjectMapper objectMapper;
    
	@Test
	public void getPSSListByQCAIdTest() throws Exception, BusinessException {
		List<PSSDetailsDTO> pssList = new ArrayList<PSSDetailsDTO>();
		Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd'T'HH:mm:ss").create();
		PSSDetailsDTO schDto = gson.fromJson(jsonschfsadd, PSSDetailsDTO.class);
		pssList.add(schDto);
		ResponseEntity<WSResp<List<PSSDetailsDTO>>> respisList = new ResponseEntity<WSResp<List<PSSDetailsDTO>>>(new WSResp<List<PSSDetailsDTO>>(pssList, true, "PSS Data Fetched Successfully!"), HttpStatus.OK);
		Mockito.when(forecastSubscriptionCtrl.getPSSListByQCAId(111)).thenReturn(respisList);
		
		String uri = "/forecast-subscription/pssByQCAId/111";
		MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();
		int status = mvcResult.getResponse().getStatus();

		assertEquals(200, status);
	}

	@Test
	public void getForecastSubscriptionListByPSSIdTest() throws Exception, BusinessException {
		List<ForecastSubscriptionBO> fsBOList = new ArrayList<ForecastSubscriptionBO>();
		Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd").create();
		ForecastSubscriptionBO isBO = gson.fromJson(jsonschfsadd, ForecastSubscriptionBO.class);
		fsBOList.add(isBO);
		ResponseEntity<WSResp<List<ForecastSubscriptionBO>>> respis = new ResponseEntity<WSResp<List<ForecastSubscriptionBO>>>(
				new WSResp<List<ForecastSubscriptionBO>>(fsBOList, true, "Forecast Subscription Data Fetched Successfully!"), HttpStatus.OK);
		Mockito.when(forecastSubscriptionCtrl.getForecastSubscriptionListByPSSId(1)).thenReturn(respis);
		
		String uri = "/forecast-subscription/forecastSubscriptionListByPSSId/111";
		MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();
		int status = mvcResult.getResponse().getStatus();

		assertEquals(200, status);
	}
	
	@Test
	public void getForecastSubscriptionByPSSIdTest() throws Exception, BusinessException {
		List<ForecastSubscriptionBO> fsBOList = new ArrayList<ForecastSubscriptionBO>();
		Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd").create();
		ForecastSubscriptionBO isBO = gson.fromJson(jsonschfsadd, ForecastSubscriptionBO.class);
		fsBOList.add(isBO);
		ResponseEntity<WSResp<List<ForecastSubscriptionBO>>> respis = new ResponseEntity<WSResp<List<ForecastSubscriptionBO>>>(
				new WSResp<List<ForecastSubscriptionBO>>(fsBOList, true, "Forecast Subscription Data Fetched Successfully!"), HttpStatus.OK);
		Mockito.when(forecastSubscriptionCtrl.getForecastSubscriptionByPSSId(1)).thenReturn(respis);
		
		String uri = "/forecast-subscription/forecastSubscriptionByPSSId/111";
		MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();
		int status = mvcResult.getResponse().getStatus();

		assertEquals(200, status);
	}

	@Test
	public void getForecastSubscriptionDetailByPSSIdTest() throws Exception, BusinessException {
		List<ForecastSubscriptionUsagesBO> fsBOList = new ArrayList<ForecastSubscriptionUsagesBO>();
		Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd").create();
		ForecastSubscriptionUsagesBO isBO = gson.fromJson(jsonschfsupdate, ForecastSubscriptionUsagesBO.class);
		fsBOList.add(isBO);
		ResponseEntity<WSResp<List<ForecastSubscriptionUsagesBO>>> respis = new ResponseEntity<WSResp<List<ForecastSubscriptionUsagesBO>>>(
				new WSResp<List<ForecastSubscriptionUsagesBO>>(fsBOList, true, "Forecast Subscription Usages Data Fetched Successfully!"), HttpStatus.OK);
		Mockito.when(forecastSubscriptionCtrl.getForecastSubscriptionDetailByPSSId(1, new Date())).thenReturn(respis);
		
		String uri = "/forecast-subscription/forecastSubscriptionDetailByPSSId/111/2022-07-12";
		MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();
		int status = mvcResult.getResponse().getStatus();

		assertEquals(200, status);
	}

	@Test
	public void newFSTest() throws Exception, BusinessException {
		Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd").create();
		ForecastSubscriptionBO isBO = gson.fromJson(jsonschfsupdate, ForecastSubscriptionBO.class);
		ResponseEntity<WSResp<ForecastSubscriptionBO>> respis = new ResponseEntity<WSResp<ForecastSubscriptionBO>>(
				new WSResp<ForecastSubscriptionBO>(isBO, true, "Forecast Subscription Data Fetched Successfully!"), HttpStatus.OK);
		Mockito.when(forecastSubscriptionCtrl.newFS(1, 10)).thenReturn(respis);
		
		String uri = "/forecast-subscription/newFS/111/10";
		MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();
		int status = mvcResult.getResponse().getStatus();

		assertEquals(200, status);
	}

	@Test
	public void saveForecastSubscriptionTest() throws Exception, BusinessException {
		Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd").create();
		ForecastSubscriptionBO isDTO = gson.fromJson(jsonschfsadd, ForecastSubscriptionBO.class);
		ResponseEntity<WSResp<ForecastSubscriptionBO>> respSavedIS = new ResponseEntity<WSResp<ForecastSubscriptionBO>>(
				new WSResp<ForecastSubscriptionBO>(isDTO, true, "Forecast Subscription Data saved Successfully!"), HttpStatus.OK);
		Mockito.when(forecastSubscriptionCtrl.saveForecastSubscription(isDTO)).thenReturn(respSavedIS);
		
		String uri = "/forecast-subscription/saveForecastSubscription";
		MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.post(uri)
				.contentType(MediaType.APPLICATION_JSON)
		        .content(objectMapper.writeValueAsString(isDTO)))
				.andReturn();
		int status = mvcResult.getResponse().getStatus();

		assertEquals(200, status);
	}
	
	@Test
	public void updateForecastSubscriptionTest() throws Exception, BusinessException {
		Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd").create();
		ForecastSubscriptionUsagesBO isDTO = gson.fromJson(jsonschfsupdate, ForecastSubscriptionUsagesBO.class);
		ResponseEntity<WSResp<ForecastSubscriptionUsagesBO>> respSavedIS = new ResponseEntity<WSResp<ForecastSubscriptionUsagesBO>>(
				new WSResp<ForecastSubscriptionUsagesBO>(isDTO, true, "Forecast Subscription Usages Data updated Successfully!"), HttpStatus.OK);
		Mockito.when(forecastSubscriptionCtrl.updateForecastSubscription(isDTO)).thenReturn(respSavedIS);
		
		String uri = "/forecast-subscription/updateForecastSubscriptionUsages";
		MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.post(uri)
				.contentType(MediaType.APPLICATION_JSON)
		        .content(objectMapper.writeValueAsString(isDTO)))
				.andReturn();
		int status = mvcResult.getResponse().getStatus();

		assertEquals(200, status);
	}

}
