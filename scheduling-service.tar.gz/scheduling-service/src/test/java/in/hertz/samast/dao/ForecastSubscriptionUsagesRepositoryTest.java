/**
 * 
 */
package in.hertz.samast.dao;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.web.context.WebApplicationContext;

import in.hertz.samast.entity.ForecastSubscriptionUsages;

/**
 * @author Bibhuti Parida
 *
 */
@ExtendWith(MockitoExtension.class)
@AutoConfigureMockMvc
@WebAppConfiguration
@ContextConfiguration(classes = {ForecastSubscriptionUsagesRepository.class, WebApplicationContext.class})
@WebMvcTest(controllers = ForecastSubscriptionUsagesRepository.class)
public class ForecastSubscriptionUsagesRepositoryTest {

	@MockBean
	private ForecastSubscriptionUsagesRepository forecastSubscriptionUsagesRepository;
	
	@Test
	public void findAllTest() {
		List<ForecastSubscriptionUsages> isList = forecastSubscriptionUsagesRepository.findAll();
		assertNotNull(isList);
	}
	
	@Test
	public void findByIdTest() {
		Optional<ForecastSubscriptionUsages> is = forecastSubscriptionUsagesRepository.findById(1);
		assertNotNull(is);
	}
	
	@Test
	public void findByPSSIdTest() {
		List<ForecastSubscriptionUsages> is = forecastSubscriptionUsagesRepository.findByPSSId(1, new Date());
		assertNotNull(is);
	}
}
