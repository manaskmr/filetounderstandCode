/**
 * 
 */
package in.hertz.samast.dao;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.web.context.WebApplicationContext;

import in.hertz.samast.entity.PSS;

/**
 * @author Bibhuti Parida
 *
 */
@ExtendWith(MockitoExtension.class)
@AutoConfigureMockMvc
@WebAppConfiguration
@ContextConfiguration(classes = {PSSRepository.class, WebApplicationContext.class})
@WebMvcTest(controllers = PSSRepository.class)
public class PSSRepositoryTest {

	@MockBean
	private PSSRepository pssRepository;
	
	@Test
	public void findAllTest() {
		List<PSS> pssList = pssRepository.findAll();
		assertNotNull(pssList);
	}
	
	@Test
	public void findByIdTest() {
		Optional<PSS> pss = pssRepository.findById(1);
		assertNotNull(pss);
	}
	
	@Test
	public void findDraftByNameTest() throws Exception {
		List<PSS> pssList = pssRepository.getPSSListByQCAId(1);
		assertNotNull(pssList);
	}
}
