package in.hertz.samast.dao;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.text.ParseException;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.web.context.WebApplicationContext;

import in.hertz.samast.domain.exception.BusinessException;
import in.hertz.samast.entity.UtilityShare;
import in.hertz.samast.util.UtilityShareType.ShareType;

/**
 * @author vikas
 *
 */
@ExtendWith(MockitoExtension.class)
@AutoConfigureMockMvc
@WebAppConfiguration
@ContextConfiguration(classes = {UtilityShareRepository.class, WebApplicationContext.class})
@WebMvcTest(controllers = UtilityShareRepository.class)
public class UtilityShareRepositoryTest {

	@MockBean
	private UtilityShareRepository utilityShareRepository;
	
	@Test
	public void findAllTest() {
		List<UtilityShare> utilityShareList = utilityShareRepository.findAll();
		assertNotNull(utilityShareList);
	}
	
	@Test
	public void findByIdTest() {
		Optional<UtilityShare> utilityShare = utilityShareRepository.findById(1);
		assertNotNull(utilityShare);
	}
	
	@Test
	public void findInjectorSharesForDateTest() throws ParseException, BusinessException {
		List<UtilityShare> utilityShare = utilityShareRepository.findInjectorSharesForDate(1, new Date(), ShareType.DISCOM_PROFIT);
		assertNotNull(utilityShare);
	}
	
	@Test
	public void findSharedForDateRange() throws ParseException, BusinessException {
		List<UtilityShare> utilityShare = utilityShareRepository.findSharedForDateRange(1, 2, new Date(), new Date(), ShareType.DISCOM_PROFIT);
		assertNotNull(utilityShare);
	}
	
}
