/**
 * 
 */
package in.hertz.samast.dao;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.web.context.WebApplicationContext;

import in.hertz.samast.entity.GenerationUnitType;

/**
 * @author Bibhuti Parida
 *
 */
@ExtendWith(MockitoExtension.class)
@AutoConfigureMockMvc
@WebAppConfiguration
@ContextConfiguration(classes = {GenerationUnitTypeRepository.class, WebApplicationContext.class})
@WebMvcTest(controllers = GenerationUnitTypeRepository.class)
public class GenerationUnitTypeRepositoryTest {

	@MockBean
	private GenerationUnitTypeRepository generationUnitTypeRepository;
	
	@Test
	public void findAllTest() {
		List<GenerationUnitType> genUnitTypeList = generationUnitTypeRepository.findAll();
		assertNotNull(genUnitTypeList);
	}
	
	@Test
	public void findByIdTest() {
		Optional<GenerationUnitType> genUnitType = generationUnitTypeRepository.findById(1);
		assertNotNull(genUnitType);
	}
}
