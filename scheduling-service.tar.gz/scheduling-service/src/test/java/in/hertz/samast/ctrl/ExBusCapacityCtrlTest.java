/**
 * 
 */
package in.hertz.samast.ctrl;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import in.hertz.samast.domain.ExBusCapacityBO;
import in.hertz.samast.domain.GenerationUnitBO;
import in.hertz.samast.domain.WSResp;
import in.hertz.samast.domain.exception.BusinessException;
import in.hertz.samast.service.ExBusCapacityService;

/**
 * @author Bibhuti Parida
 *
 */
@ExtendWith(MockitoExtension.class)
@AutoConfigureMockMvc
@WebAppConfiguration
@ContextConfiguration(classes = {ExBusCapacityCtrl.class, WebApplicationContext.class})
@WebMvcTest(controllers = ExBusCapacityCtrl.class)
public class ExBusCapacityCtrlTest {
		
	@Autowired
	protected MockMvc mockMvc;
	
	@MockBean
	protected ExBusCapacityCtrl exBusCapacityCtrl;
	
	@Autowired
	private ObjectMapper objectMapper;

	@MockBean
	private ExBusCapacityService exBusCapacityService;
	
	private String jsonschexbus =
	"  {					"+
	"    \"exBusCapacity\": 0, "+
	"    \"exBusSldc\": 0,	"+
	"    \"id\": 0,			"+
	"    \"utgID\": 0			"+
	"  }					";
	
	@Test
	public void getAllExBusCapacityTest() throws BusinessException, Exception {
		Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd'T'HH:mm:ss").create();
		ExBusCapacityBO schDto = gson.fromJson(jsonschexbus, ExBusCapacityBO.class);
		List<ExBusCapacityBO> exbuslist = new ArrayList<ExBusCapacityBO>();
		exbuslist.add(schDto);
		ResponseEntity<WSResp<List<ExBusCapacityBO>>> respCP = new ResponseEntity<WSResp<List<ExBusCapacityBO>>>(new WSResp<List<ExBusCapacityBO>>(exbuslist, true, "ex bus capacity Data Fetched Successfully!"), HttpStatus.OK);
		Mockito.when(exBusCapacityCtrl.getAllExBusCapacity()).thenReturn(respCP);
		
		String uri = "/sldc-config-exbus/findAll";
		MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();
		int status = mvcResult.getResponse().getStatus();

		assertEquals(200, status);
	}
	
	@Test
	public void getExBusCapacityByGenTypeTest() throws BusinessException, Exception {
		Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd'T'HH:mm:ss").create();
		ExBusCapacityBO schDto = gson.fromJson(jsonschexbus, ExBusCapacityBO.class);
		List<ExBusCapacityBO> exbuslist = new ArrayList<ExBusCapacityBO>();
		exbuslist.add(schDto);
		ResponseEntity<WSResp<List<ExBusCapacityBO>>> respCP = new ResponseEntity<WSResp<List<ExBusCapacityBO>>>(new WSResp<List<ExBusCapacityBO>>(exbuslist, true, "ex bus capacity Data Fetched Successfully!"), HttpStatus.OK);
		Mockito.when(exBusCapacityCtrl.getExBusCapacityByGenType(1)).thenReturn(respCP);
		
		String uri = "/sldc-config-exbus/findByGenType/1";
		MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();
		int status = mvcResult.getResponse().getStatus();

		assertEquals(200, status);
	}

	@Test
	public void getAllGenTypeTest() throws BusinessException, Exception {
		List<GenerationUnitBO> exbuslist = new ArrayList<GenerationUnitBO>();
		ResponseEntity<WSResp<List<GenerationUnitBO>>> respCP = new ResponseEntity<WSResp<List<GenerationUnitBO>>>(new WSResp<List<GenerationUnitBO>>(exbuslist, true, "Generation Type Data Fetched Successfully!"), HttpStatus.OK);
		Mockito.when(exBusCapacityCtrl.getAllGenType()).thenReturn(respCP);
		
		String uri = "/sldc-config-exbus/findAllGenType";
		MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();
		int status = mvcResult.getResponse().getStatus();

		assertEquals(200, status);
	}

	@Test
	public void updateCoalPositionTest() throws BusinessException, Exception {
		
		Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd'T'HH:mm:ss").create();
		ExBusCapacityBO schDto = gson.fromJson(jsonschexbus, ExBusCapacityBO.class);
		List<ExBusCapacityBO> exBusList = new ArrayList<ExBusCapacityBO>();
		exBusList.add(schDto);
		ResponseEntity<WSResp<List<ExBusCapacityBO>>> respCP = new ResponseEntity<WSResp<List<ExBusCapacityBO>>>(new WSResp<List<ExBusCapacityBO>>(exBusList,true,"Request processed successfully"),HttpStatus.OK);
		Mockito.when(exBusCapacityCtrl.update66AllExBusCapacity(exBusList)).thenReturn(respCP);
		
		String uri = "/sldc-config-exbus/updateAll";
		MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.post(uri)
				.contentType(MediaType.APPLICATION_JSON)
		        .content(objectMapper.writeValueAsString(exBusList)))
				.andReturn();
		int status = mvcResult.getResponse().getStatus();

		assertEquals(200, status);
	}
}
