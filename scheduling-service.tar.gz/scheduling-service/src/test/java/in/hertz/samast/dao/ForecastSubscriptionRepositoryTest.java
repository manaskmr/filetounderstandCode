/**
 * 
 */
package in.hertz.samast.dao;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.web.context.WebApplicationContext;

import in.hertz.samast.entity.ForecastSubscription;

/**
 * @author Bibhuti Parida
 *
 */
@ExtendWith(MockitoExtension.class)
@AutoConfigureMockMvc
@WebAppConfiguration
@ContextConfiguration(classes = {ForecastSubscriptionRepository.class, WebApplicationContext.class})
@WebMvcTest(controllers = ForecastSubscriptionRepository.class)
public class ForecastSubscriptionRepositoryTest {

	@MockBean
	private ForecastSubscriptionRepository forecastSubscriptionRepository;
	
	@Test
	public void findAllTest() {
		List<ForecastSubscription> fsList = forecastSubscriptionRepository.findAll();
		assertNotNull(fsList);
	}
	
	@Test
	public void findByIdTest() {
		Optional<ForecastSubscription> fs = forecastSubscriptionRepository.findById(1);
		assertNotNull(fs);
	}
	
	@Test
	public void ffindByPSSIdTest() {
		List<ForecastSubscription> fsList = forecastSubscriptionRepository.findByPSSId(1);
		assertNotNull(fsList);
	}
}
