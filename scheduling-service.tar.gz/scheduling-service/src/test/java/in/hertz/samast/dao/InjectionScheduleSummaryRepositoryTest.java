/**
 * 
 */
package in.hertz.samast.dao;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.web.context.WebApplicationContext;

import in.hertz.samast.entity.InjectionScheduleSummary;

/**
 * @author Bibhuti Parida
 *
 */
@ExtendWith(MockitoExtension.class)
@AutoConfigureMockMvc
@WebAppConfiguration
@ContextConfiguration(classes = {InjectionScheduleSummaryRepository.class, WebApplicationContext.class})
@WebMvcTest(controllers = InjectionScheduleSummaryRepository.class)
public class InjectionScheduleSummaryRepositoryTest {
	
	@MockBean
	private InjectionScheduleSummaryRepository injectionScheduleSummaryRepository;
	
	@Test
	public void findAllTest() {
		List<InjectionScheduleSummary> isList = injectionScheduleSummaryRepository.findAll();
		assertNotNull(isList);
	}
	
	@Test
	public void findByIdTest() {
		Optional<InjectionScheduleSummary> is = injectionScheduleSummaryRepository.findById(1);
		assertNotNull(is);
	}
	
	@Test
	public void getInjectionScheduleSummaryByUTGTest() throws Exception {
		List<InjectionScheduleSummary> isList = injectionScheduleSummaryRepository.getInjectionScheduleSummaryByUTG(1, new Date());
		assertNotNull(isList);
	}

	@Test
	public void getInjectionScheduleSummaryLatestRevisionTest() throws Exception {
		List<InjectionScheduleSummary> isList = injectionScheduleSummaryRepository.getInjectionScheduleSummaryLatestRevision(1, new Date(), 1);
		assertNotNull(isList);
	}
	
	@Test
	public void getLatestRevisionNoByUTGTest() throws Exception {
		Integer revisionNo = injectionScheduleSummaryRepository.getLatestRevisionNoByUTG(1, new Date());
		assertNotNull(revisionNo);
	}
}
