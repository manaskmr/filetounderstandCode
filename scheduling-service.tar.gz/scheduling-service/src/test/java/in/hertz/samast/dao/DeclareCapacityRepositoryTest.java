/**
 * 
 */
package in.hertz.samast.dao;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.web.context.WebApplicationContext;

import in.hertz.samast.entity.DeclareCapability;

/**
 * @author Bibhuti Parida
 *
 */
@ExtendWith(MockitoExtension.class)
@AutoConfigureMockMvc
@WebAppConfiguration
@ContextConfiguration(classes = {DeclareCapacityRepository.class, WebApplicationContext.class})
@WebMvcTest(controllers = DeclareCapacityRepository.class)
public class DeclareCapacityRepositoryTest {

	@MockBean
	private DeclareCapacityRepository declareCapacityRepository;
	
	@Test
	public void findAllTest() {
		List<DeclareCapability> dcList = declareCapacityRepository.findAll();
		assertNotNull(dcList);
	}
	
	@Test
	public void findByIdTest() {
		Optional<DeclareCapability> dc = declareCapacityRepository.findById(1);
		assertNotNull(dc);
	}
	
	@Test
	public void getDeclaredCapacityByUTGTest() throws Exception {
		List<DeclareCapability>  dcList = declareCapacityRepository.getDeclaredCapacityByUTG(1, new Date());
		assertNotNull(dcList);
	}

	@Test
	public void getDeclaredCapacityLatestRevisionTest() throws Exception {
		List<DeclareCapability>  dcList = declareCapacityRepository.getDeclaredCapacityLatestRevision(1, new Date(), -1);
		assertNotNull(dcList);
	}

	@Test
	public void getLatestRevisionNoByUTGTest() throws Exception {
		Integer revNo = declareCapacityRepository.getLatestRevisionNoByUTG(1, new Date());
		assertNotNull(revNo);
	}

}
