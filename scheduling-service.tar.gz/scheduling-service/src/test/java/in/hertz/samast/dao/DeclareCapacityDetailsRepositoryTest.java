/**
 * 
 */
package in.hertz.samast.dao;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.web.context.WebApplicationContext;

import in.hertz.samast.entity.DeclareCapabilityDetails;

/**
 * @author Bibhuti Parida
 *
 */
@ExtendWith(MockitoExtension.class)
@AutoConfigureMockMvc
@WebAppConfiguration
@ContextConfiguration(classes = {DeclareCapacityDetailsRepository.class, WebApplicationContext.class})
@WebMvcTest(controllers = DeclareCapacityDetailsRepository.class)
public class DeclareCapacityDetailsRepositoryTest {
	
	@MockBean
	private DeclareCapacityDetailsRepository declareCapacityDetailsRepository;
	
	@Test
	public void findAllTest() {
		List<DeclareCapabilityDetails> dcDetailsList = declareCapacityDetailsRepository.findAll();
		assertNotNull(dcDetailsList);
	}
	
	@Test
	public void findByIdTest() {
		Optional<DeclareCapabilityDetails> dcDetails = declareCapacityDetailsRepository.findById(1);
		assertNotNull(dcDetails);
	}

}
