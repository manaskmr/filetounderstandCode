/**
 * 
 */
package in.hertz.samast.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.context.WebApplicationContext;

import in.hertz.samast.domain.exception.BusinessException;
import in.hertz.samast.entity.TimeInterval;

/**
 * @author Bibhuti Parida
 *
 */
@ExtendWith(MockitoExtension.class)
@AutoConfigureMockMvc
@WebAppConfiguration
@ContextConfiguration(classes = {TimeIntervalServiceImpl.class, WebApplicationContext.class})
@WebMvcTest(controllers = TimeIntervalServiceImpl.class)
public class TimeIntervalServiceTest {
	
	@MockBean
	private TimeIntervalServiceImpl timeIntervalService;
	
	@Autowired
    protected MockMvc mockMvc;
	
	@Test
	public void getCurrentTimeBlockTest()  throws Exception, BusinessException {
		TimeInterval t = new TimeInterval();
		Mockito.when(timeIntervalService.getCurrentTimeBlock()).thenReturn(t);
	}

	@Test
	public void findAllTimeIntervalsTest()  throws Exception, BusinessException {
		List<TimeInterval> t = new ArrayList<TimeInterval>();
		Mockito.when(timeIntervalService.findAllTimeIntervals()).thenReturn(t);
	}

	@Test
	public void findByBlockTest()  throws Exception, BusinessException {
		TimeInterval t = new TimeInterval();
		Mockito.when(timeIntervalService.findByBlock(0)).thenReturn(t);
	}

	@Test
	public void findTimeBlockTest()  throws Exception, BusinessException {
		TimeInterval t = new TimeInterval();
		Mockito.when(timeIntervalService.findTimeBlock("00:15:00")).thenReturn(t);
	}

	@Test
	public void findTimeIntervalByFromTimeTest()  throws Exception, BusinessException {
		TimeInterval t = new TimeInterval();
		Mockito.when(timeIntervalService.findTimeIntervalByFromTime("00:15:00")).thenReturn(t);
	}
	
	@Test
	public void findTimeIntervalByToTimeTest()  throws Exception, BusinessException {
		TimeInterval t = new TimeInterval();
		Mockito.when(timeIntervalService.findTimeIntervalByToTime("00:15:00")).thenReturn(t);
	}
	
	@Test
	public void findTimeIntervalByBetweenTimeTest()  throws Exception, BusinessException {
		TimeInterval t = new TimeInterval();
		Mockito.when(timeIntervalService.findTimeIntervalByBetweenTime("00:15:00")).thenReturn(t);
	}

	@Test
	public void findTimeIntervalByBetweenTimeZoneTest()  throws Exception, BusinessException {
		TimeInterval t = new TimeInterval();
		Mockito.when(timeIntervalService.findTimeIntervalByBetweenTimeZone("00:15:00")).thenReturn(t);
	}
	
	@Test
	public void findMaxBlockTest()  throws Exception, BusinessException {
		Mockito.when(timeIntervalService.findMaxBlock()).thenReturn(0);
	}
	
	@Test
	public void timeDifferentTest()  throws Exception, BusinessException {
		Mockito.when(timeIntervalService.timeDifferent(new Date())).thenReturn(new Long(0));
	}
}
