package in.hertz.samast.service;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.text.ParseException;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.context.WebApplicationContext;

import in.hertz.samast.domain.UtilityShareBO;
import in.hertz.samast.domain.exception.BusinessException;
import in.hertz.samast.util.UtilityShareType.ShareType;

@ExtendWith(MockitoExtension.class)
@AutoConfigureMockMvc
@WebAppConfiguration
@ContextConfiguration(classes = {UtilityShareServiceImpl.class, WebApplicationContext.class})
@WebMvcTest(controllers = UtilityShareServiceImpl.class)
public class UtilityShareServiceTest {
	
	@MockBean
	private UtilityShareServiceImpl utilityShareService;
	
	@Autowired
    protected MockMvc mockMvc;
	
	@Test
	public void findInjectorShareBOTest() throws ParseException, BusinessException {
		List<UtilityShareBO> utilityShare = utilityShareService.findInjectorShareBO(1, new Date(), ShareType.DISCOM_PROFIT);
		assertNotNull(utilityShare);
	}

	
}
