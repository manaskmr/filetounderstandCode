/**
 * 
 */
package in.hertz.samast.dao;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.web.context.WebApplicationContext;

import in.hertz.samast.entity.ExBusCapacity;

/**
 * @author Bibhuti Parida
 *
 */
@ExtendWith(MockitoExtension.class)
@AutoConfigureMockMvc
@WebAppConfiguration
@ContextConfiguration(classes = {ExBusCapacityRepository.class, WebApplicationContext.class})
@WebMvcTest(controllers = ExBusCapacityRepository.class)
public class ExBusCapacityRepositoryTest {
	
	@MockBean
	private ExBusCapacityRepository exBusCapacityRepository;
	
	@Test
	public void findAllTest() {
		List<ExBusCapacity> exBusCapacityList = exBusCapacityRepository.findAll();
		assertNotNull(exBusCapacityList);
	}
	
	@Test
	public void findByIdTest() {
		Optional<ExBusCapacity> exBusCapacity = exBusCapacityRepository.findById(1);
		assertNotNull(exBusCapacity);
	}

	@Test
	public void getExBusCapacityByUTGTest() throws Exception {
		List<ExBusCapacity> exBusCapacityList = exBusCapacityRepository.getExBusCapacityByUTG(61);
		assertNotNull(exBusCapacityList);
	}
	
	@Test
	public void getExBusCapacityByGenTypeTest() throws Exception {
		List<ExBusCapacity> exBusCapacityList = exBusCapacityRepository.getExBusCapacityByGenType(61);
		assertNotNull(exBusCapacityList);
	}
}
