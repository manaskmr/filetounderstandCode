package in.hertz.samast;

import org.junit.jupiter.api.Test;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = SchedulingServiceApplication.class)
public class SchedulingServiceApplicationTests {

	@Test
	public void contextLoads() {
	}
    
	@Test
	public void applicationMainTest() {
		SchedulingServiceApplication.main(new String[] {});
	}
}
