/**
 * 
 */
package in.hertz.samast.ctrl;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import in.hertz.samast.domain.DraftDTO;
import in.hertz.samast.domain.InjectionScheduleBO;
import in.hertz.samast.domain.InjectionScheduleSummaryBO;
import in.hertz.samast.domain.PSSDetailsDTO;
import in.hertz.samast.domain.WSResp;
import in.hertz.samast.domain.exception.BusinessException;
import in.hertz.samast.entity.Draft;
import in.hertz.samast.entity.TimeInterval;
import in.hertz.samast.service.InjectionScheduleService;

/**
 * @author Bibhuti Parida
 *
 */
@ExtendWith(MockitoExtension.class)
@AutoConfigureMockMvc
@WebAppConfiguration
@ContextConfiguration(classes = {InjectionScheduleCtrl.class, WebApplicationContext.class})
@WebMvcTest(controllers = InjectionScheduleCtrl.class)
public class InjectionScheduleCtrlTest {

	@Autowired
    protected MockMvc mockMvc;
	
    @MockBean
	protected InjectionScheduleCtrl injectionScheduleCtrl;
    
    @MockBean
	protected InjectionScheduleService injectionScheduleService;
    
    @Autowired
    private ObjectMapper objectMapper;
	
	private String jsonschDraft = 
    		"	{ "+
    		"	  \"createdBy\": \"Bibhuti Test\", "+
    		"	  \"createdDate\": null, "+
    		"	  \"currentStage\": \"\", "+
    		"	  \"functionalityArea\": \"Injection_Scheduling_QCA\", "+
    		"	  \"modifiedBy\": \"string\", "+
    		"	  \"modifiedDate\": null, "+
    		"	  \"jsonDTO\": { "+
    		"	    \"approvedBy\": 0, "+
    		"	    \"approvedDate\": null , "+
    		"	    \"forDate\": \"2022-07-07\", "+
    		"	    \"issueDate\": null, "+
    		"	    \"injectionScheduleDetail\": [ "+
    		"	      { "+
    		"	    	\"availableCapacity\": 10, 	"+
    		"	    	\"dayAheadForcast\": 10,		"+
    		"	    	\"injectionScheduleUID\": null,"+
    		"	    	\"quantum\": 10,				"+
    		"	    	\"timeIntervalId\": 1		"+
    		"	      } "+
    		"	    ], "+
    		"	    \"remarks\": \"Testing Remarks\", "+
    		"	    \"revisionNumber\": -1, "+
    		"	    \"injectionUtgId\": 61, "+
    		"	    \"status\": \"Testing New\" "+
    		"	  }, "+
    		"	  \"status\": \"Testing New\" "+
    		"	}		";

	private String jsonschIS =
	    	"{" +
	        "\"forDate\": \"2022-06-14\","+
	        "\"issueDate\": \"2022-06-14 11:07:59\","+
	        "\"revisionNumber\": -1,"+
	        "\"dataSource\": \"NRLDC\","+
	        "\"injectionName\": \"Sedam-Mercury \","+
	        "\"injectionUtgId\": 67,"+
	        "\"approvedBy\": null,"+
	        "\"approvedDate\": null,"+
	        "\"status\": null,"+
	        "\"remarks\": null,"+
	        "\"injectionScheduleDetail\": ["+
	        "    { " +
	        "        \"timeIntervalId\": 1,"+
	        "        \"quantum\": 0.0,"+
	        "        \"availableCapacity\": null,"+
	        "        \"injectionScheduleUID\": 10.0,"+
	        "         \"dayAheadForcast\": 11.0"+
	        "    }, "+
	        "    { "+
	        "        \"timeIntervalId\": 2,"+
	        "        \"quantum\": 0.0,"+
	        "        \"availableCapacity\": null,"+
	        "        \"injectionScheduleUID\": 10.0,"+
	        "         \"dayAheadForcast\": 11.0"+
	        "    }"+
	        "]"+
	    "}";
	
	@Test
	public void getPSSListByQCAIdTest() throws Exception, BusinessException {
		List<PSSDetailsDTO> pssList = new ArrayList<PSSDetailsDTO>();
		Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd'T'HH:mm:ss").create();
		PSSDetailsDTO schDto = gson.fromJson(jsonschIS, PSSDetailsDTO.class);
		pssList.add(schDto);
		ResponseEntity<WSResp<List<PSSDetailsDTO>>> respisList = new ResponseEntity<WSResp<List<PSSDetailsDTO>>>(new WSResp<List<PSSDetailsDTO>>(pssList, true, "PSS Data Fetched Successfully!"), HttpStatus.OK);
		Mockito.when(injectionScheduleCtrl.getPSSListByQCAId(111)).thenReturn(respisList);
		
		String uri = "/injection-schedule/pssByQCAId/111";
		MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();
		int status = mvcResult.getResponse().getStatus();

		assertEquals(200, status);
	}
	
	@Test
	public void getPSSSummaryTest() throws Exception, BusinessException {
		List<InjectionScheduleBO> isBOList  = new ArrayList<InjectionScheduleBO>();
		Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd").create();
		InjectionScheduleBO schDto = gson.fromJson(jsonschIS, InjectionScheduleBO.class);
		isBOList.add(schDto);
		ResponseEntity<WSResp<List<InjectionScheduleBO>>> respisList = new ResponseEntity<WSResp<List<InjectionScheduleBO>>>(new WSResp<List<InjectionScheduleBO>>(isBOList, true, "PSS summary Data Fetched Successfully!"), HttpStatus.OK);
		Mockito.when(injectionScheduleCtrl.getPSSSummary(111, new Date())).thenReturn(respisList);
		
		String uri = "/injection-schedule/111/2022-07-07";
		MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();
		int status = mvcResult.getResponse().getStatus();

		assertEquals(200, status);
	}

	@Test
	public void getInjectionSummaryListByQCAIdTest() throws Exception, BusinessException {
		List<InjectionScheduleSummaryBO> isBOList  = new ArrayList<InjectionScheduleSummaryBO>();
		ResponseEntity<WSResp<List<InjectionScheduleSummaryBO>>> respisList = new ResponseEntity<WSResp<List<InjectionScheduleSummaryBO>>>(new WSResp<List<InjectionScheduleSummaryBO>>(isBOList, true, "Injection Schedule Summary Data Fetched Successfully!"), HttpStatus.OK);
		Mockito.when(injectionScheduleCtrl.getInjectionSummaryListByQCAId(111, new Date())).thenReturn(respisList);
		
		String uri = "/injection-schedule/injectionSummaryByQCAId/111/2022-07-07";
		MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();
		int status = mvcResult.getResponse().getStatus();

		assertEquals(200, status);
	}

	@Test
	public void getInjectionScheduleTest() throws Exception, BusinessException {
		Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd").create();
		InjectionScheduleBO isBO = gson.fromJson(jsonschIS, InjectionScheduleBO.class);
		ResponseEntity<WSResp<InjectionScheduleBO>> respis = new ResponseEntity<WSResp<InjectionScheduleBO>>(
				new WSResp<InjectionScheduleBO>(isBO, true, "Injection Schedule Data Fetched Successfully!"), HttpStatus.OK);
		Mockito.when(injectionScheduleCtrl.getInjectionSchedule(61, new Date())).thenReturn(respis);
		
		String uri = "/injection-schedule/injectionSchedule/111/2022-07-07";
		MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();
		int status = mvcResult.getResponse().getStatus();

		assertEquals(200, status);
	}
	
	@Test
	public void getInjectionScheduleByRevisionNoTest() throws Exception, BusinessException {
		Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd").create();
		InjectionScheduleBO isBO = gson.fromJson(jsonschIS, InjectionScheduleBO.class);
		ResponseEntity<WSResp<InjectionScheduleBO>> respis = new ResponseEntity<WSResp<InjectionScheduleBO>>(
				new WSResp<InjectionScheduleBO>(isBO, true, "Injection Schedule Data Fetched Successfully!"), HttpStatus.OK);
		Mockito.when(injectionScheduleCtrl.getInjectionScheduleByRevisionNo(61, new Date(), 1)).thenReturn(respis);
		
		String uri = "/injection-schedule/injectionScheduleByRevNo/1/2022-07-07/1";
		MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();
		int status = mvcResult.getResponse().getStatus();

		assertEquals(200, status);
	}

	@Test
	public void getCurrentTimeBlockTest() throws Exception, BusinessException {
		TimeInterval timeBlock = injectionScheduleService.getCurrentTimeBlock();
		ResponseEntity<WSResp<TimeInterval>> respTMBlk = new ResponseEntity<WSResp<TimeInterval>>(
				new WSResp<TimeInterval>(timeBlock, true, "Time Block fetched Successfully!"), HttpStatus.OK);
		Mockito.when(injectionScheduleCtrl.getCurrentTimeBlock()).thenReturn(respTMBlk);
		
		String uri = "/injection-schedule/currentTimeBlock";
		MvcResult mvcResult =  mockMvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();
		int status = mvcResult.getResponse().getStatus();

		assertEquals(200, status);
	}
	
	@Test
	public void getExBusCapacityTest() throws Exception, BusinessException {
		Integer exBusCapacity = injectionScheduleService.getExBusCapacity(61);
		
		ResponseEntity<WSResp<Integer>> respExBusCapacity = new ResponseEntity<WSResp<Integer>>(
				new WSResp<Integer>(exBusCapacity, true, "Ex-Bus Capacity fetched Successfully!"),
				HttpStatus.OK);
		Mockito.when(injectionScheduleCtrl.getExBusCapacity(61)).thenReturn(respExBusCapacity);
		
		String uri = "/injection-schedule/exBusCapacity/61";
		MvcResult mvcResult =  mockMvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();
		int status = mvcResult.getResponse().getStatus();

		assertEquals(200, status);
	}
	
	@Test
	public void getRevisionNoByScheduleTypeTest() throws Exception, BusinessException {
		ResponseEntity<WSResp<List<Integer>>> respis = new ResponseEntity<WSResp<List<Integer>>>(
				new WSResp<List<Integer>>(new ArrayList<Integer>(), true, "Injection Schedule Data Fetched Successfully!"), HttpStatus.OK);
		Mockito.when(injectionScheduleCtrl.getRevisionNoByScheduleType(61, new Date(), "DayAhead")).thenReturn(respis);
		
		String uri = "/injection-schedule/revisionNoByScheduleType/1/2022-07-07/DayAhead";
		MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();
		int status = mvcResult.getResponse().getStatus();

		assertEquals(200, status);
	}

	@Test
	public void getAllRevisionNoTest() throws Exception, BusinessException {
		List<Integer> revisionList = injectionScheduleService.getAllRevisionNo(new Date(), 61);
		ResponseEntity<WSResp<List<Integer>>> respRevNo = new ResponseEntity<WSResp<List<Integer>>>(
				new WSResp<List<Integer>>(revisionList, true, "Revision Number fetched Successfully!"),
				HttpStatus.OK);
		Mockito.when(injectionScheduleCtrl.getAllRevisionNo(61, new Date())).thenReturn(respRevNo);
		
		String uri = "/injection-schedule/allRevisionNo/61/2022-06-21";
		MvcResult mvcResult =  mockMvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();
		int status = mvcResult.getResponse().getStatus();

		assertEquals(200, status);
	}
	
	@Test
	public void getLatestRevisionNoTest() throws Exception, BusinessException {
		ResponseEntity<WSResp<Integer>> respis = new ResponseEntity<WSResp<Integer>>(
				new WSResp<Integer>(new Integer(1), true, "Revision Number fetched Successfully!"), HttpStatus.OK);
		Mockito.when(injectionScheduleCtrl.getLatestRevisionNo(61, new Date())).thenReturn(respis);
		
		String uri = "/injection-schedule/latestRevisionNo/1/2022-07-07";
		MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();
		int status = mvcResult.getResponse().getStatus();

		assertEquals(200, status);
	}

	@SuppressWarnings("unchecked")
	@Test
	public void saveDraftTest() throws Exception, BusinessException {
		Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd").create();
		DraftDTO<InjectionScheduleBO> draftDTO = gson.fromJson(jsonschDraft, DraftDTO.class);
		Draft<InjectionScheduleBO> savedDraft = injectionScheduleService.saveDraft(draftDTO);
		ResponseEntity<WSResp<Draft<InjectionScheduleBO>>> respSavedDraft = 
				new ResponseEntity<WSResp<Draft<InjectionScheduleBO>>>(
						new WSResp<Draft<InjectionScheduleBO>>(savedDraft, true, "Draft Data Saved Successfully!"),
						HttpStatus.OK);
		Mockito.when(injectionScheduleCtrl.saveDraft(draftDTO)).thenReturn(respSavedDraft);
		
		String uri = "/injection-schedule/saveDraft";
		MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.post(uri)
				.contentType(MediaType.APPLICATION_JSON)
		        .content(objectMapper.writeValueAsString(draftDTO)))
				.andReturn();
		int status = mvcResult.getResponse().getStatus();

		assertEquals(200, status);
	}

	@Test
	public void findDraftTest() throws Exception, BusinessException {
		Draft<InjectionScheduleBO> draftDTO = injectionScheduleService.fetchDraftData(new Date(), 61);
		ResponseEntity<WSResp<Draft<InjectionScheduleBO>>> respDraft = new ResponseEntity<WSResp<Draft<InjectionScheduleBO>>>(
				new WSResp<Draft<InjectionScheduleBO>>(draftDTO, true, "Data Fetched Successfully!"),
				HttpStatus.OK);
		Mockito.when(injectionScheduleCtrl.findDraft(61, new Date())).thenReturn(respDraft);
		
		String uri = "/injection-schedule/draft/61/2022-06-21";
		MvcResult mvcResult =  mockMvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();
		int status = mvcResult.getResponse().getStatus();

		assertEquals(200, status);
	}

	@Test
	public void newInjectionScheduleTest() throws Exception, BusinessException {
		InjectionScheduleBO dcDTO = injectionScheduleService.newInjectionSchedule(new Date(), 61);
		ResponseEntity<WSResp<InjectionScheduleBO>> respDc = new ResponseEntity<WSResp<InjectionScheduleBO>>(
				new WSResp<InjectionScheduleBO>(dcDTO, true, "Injection Schedule Data initiated Successfully!"), HttpStatus.OK);
		Mockito.when(injectionScheduleCtrl.newInjectionSchedule(61, new Date())).thenReturn(respDc);
		
		String uri = "/injection-schedule/newIS/61/2022-06-21";
		MvcResult mvcResult =  mockMvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();
		int status = mvcResult.getResponse().getStatus();

		assertEquals(200, status);
	}

	@Test
	public void saveInjectionScheduleTest() throws Exception, BusinessException {
		
		Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd").create();
		InjectionScheduleBO isDTO = gson.fromJson(jsonschIS, InjectionScheduleBO.class);
		ResponseEntity<WSResp<InjectionScheduleBO>> respSavedIS = new ResponseEntity<WSResp<InjectionScheduleBO>>(
				new WSResp<InjectionScheduleBO>(isDTO, true, "Injection Schedule Data Saved Successfully!"), HttpStatus.OK);
		Mockito.when(injectionScheduleCtrl.saveInjectionSchedule(isDTO)).thenReturn(respSavedIS);
		
		String uri = "/injection-schedule/saveIS";
		MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.post(uri)
				.contentType(MediaType.APPLICATION_JSON)
		        .content(objectMapper.writeValueAsString(isDTO)))
				.andReturn();
		int status = mvcResult.getResponse().getStatus();

		assertEquals(200, status);
	}

}
