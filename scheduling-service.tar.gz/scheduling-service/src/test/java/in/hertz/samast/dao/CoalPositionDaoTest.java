/**
 * 
 */
package in.hertz.samast.dao;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.math.BigInteger;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.web.context.WebApplicationContext;

import in.hertz.samast.entity.coalposition.CoalPosition;

/**
 * @author Bibhuti Parida
 *
 */
@ExtendWith(MockitoExtension.class)
@AutoConfigureMockMvc
@WebAppConfiguration
@ContextConfiguration(classes = {CoalPositionDao.class, WebApplicationContext.class})
@WebMvcTest(controllers = CoalPositionDao.class)
public class CoalPositionDaoTest {
	
	@MockBean
	private CoalPositionDao coalPositionDao;
	
	@Test
	public void findAllTest() {
		List<CoalPosition> coalPosList = coalPositionDao.findAll();
		assertNotNull(coalPosList);
	}
	
	@Test
	public void findByIdTest() {
		BigInteger bi = new BigInteger("1");
		Optional<CoalPosition> colPos = coalPositionDao.findById(bi);
		assertNotNull(colPos);
	}

	@Test
	public void findCoalPositionByDateTest() throws Exception {
		SimpleDateFormat formatter  =  new SimpleDateFormat("yyyy-MM-dd");
		Date sdate = formatter.parse("2022-06-23");
		CoalPosition coalPo = coalPositionDao.findCoalPositionByDate(sdate, 61);
		//assertNotNull(coalPo);
	}
}
