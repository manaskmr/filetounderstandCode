/**
 * 
 */
package in.hertz.samast.dao;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.web.context.WebApplicationContext;

import in.hertz.samast.entity.UtilityShareDetails;

/**
 * @author vikas
 *
 */
@ExtendWith(MockitoExtension.class)
@AutoConfigureMockMvc
@WebAppConfiguration
@ContextConfiguration(classes = {UtilityShareDetailsRepository.class, WebApplicationContext.class})
@WebMvcTest(controllers = UtilityShareDetailsRepository.class)
public class UtilityShareDetailsRepositoryTest {

	@MockBean
	private UtilityShareDetailsRepository utilityShareDetailsRepository;
	
	@Test
	public void findAllTest() {
		List<UtilityShareDetails> utilityShareList = utilityShareDetailsRepository.findAll();
		assertNotNull(utilityShareList);
	}
	
	@Test
	public void findByIdTest() {
		Optional<UtilityShareDetails> utilityShare = utilityShareDetailsRepository.findById(1);
		assertNotNull(utilityShare);
	}
	
	@Test
	public void deleteByUtilityShareTest() {
		int utilityShare = utilityShareDetailsRepository.deleteByUtilityShare(1);
		assertEquals(utilityShare, 0);
	}
	
}
