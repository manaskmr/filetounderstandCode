package in.hertz.samast.dao;

import java.text.ParseException;
import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import in.hertz.samast.domain.exception.BusinessException;
import in.hertz.samast.entity.UtilityShare;
import in.hertz.samast.util.UtilityShareType.ShareType;

@Repository
public interface UtilityShareRepository extends JpaRepository<UtilityShare, Integer>{

	@Query("SELECT us FROM UtilityShare us " + "WHERE us.injectorUtg.UID =:utgId and us.fromDate <=:fDate and us.toDate >=:fDate and us.shareType =:type")
	public List<UtilityShare> findInjectorSharesForDate(@Param("utgId") int utgId, @Param("fDate") Date fDate, @Param("type") ShareType type)
			throws ParseException, BusinessException ;


	@Query("SELECT us FROM UtilityShare us " + "WHERE us.beneficiaryUtg.UID =:beneficiaryUtgId and us.injectorUtg.UID =:injectorUtgId and us.shareType =:shareType and "
			+ "(((us.fromDate <=:fromDate and us.toDate >=:fromDate) and (us.fromDate <=:toDate and us.toDate >=:toDate)) or "
			+ "(us.fromDate >=:fromDate and us.toDate <=:toDate) or "
			+ "((us.fromDate <=:fromDate and us.toDate <=:fromDate) and (us.fromDate <=:toDate and us.toDate <=:toDate)) or"
			+ "((us.fromDate >=:fromDate and us.toDate >=:fromDate) and (us.fromDate <=:toDate and us.toDate >=:toDate)))")
	public List<UtilityShare> findSharedForDateRange(@Param("beneficiaryUtgId") int beneficiaryUtgId, @Param("injectorUtgId") int injectorUtgId, @Param("fromDate") Date fromDate,
			@Param("toDate") Date toDate, @Param("shareType") ShareType shareType) throws ParseException, BusinessException ;
	
}