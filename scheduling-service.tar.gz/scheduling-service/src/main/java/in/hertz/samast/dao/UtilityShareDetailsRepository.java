package in.hertz.samast.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import in.hertz.samast.entity.UtilityShareDetails;

@Repository
public interface UtilityShareDetailsRepository extends JpaRepository<UtilityShareDetails, Integer> {
	
	@Modifying
	@Query("delete from UtilityShareDetails usd where usd.regulatedShare.UID = :utilityShare")
	public int deleteByUtilityShare(@Param("utilityShare") int utilityShare);

}
