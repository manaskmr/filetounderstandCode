package in.hertz.samast.dao;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.slf4j.LoggerFactory;

import ch.qos.logback.classic.Logger;
import in.hertz.samast.domain.InjectionScheduleQueryParamDto;

public class CustomInjectionScheduleDaoImpl implements CustomInjectionScheduleDao {

	@PersistenceContext
    private EntityManager entityManager;
	private static final String YYYY_MM_dd = "yyyy-MM-dd";
	private static final String HH_mm = "HH:mm";
	private static final String SQL_QUERY = "select tm.BLOCK_NUMBER,tm.SCH_TIME,tm.TO_TIME, ct.CONTRACT_TYPE_UID, ct.SHORT_NAME ,injs.FOR_DATE,injs.ISSUE_DATE,"
											+ "	sum(injsd.SCH_QUANTUM) as quantum1,"
											+ " injsd.TIME_INTERVAL_UID \n"
											+ " from injection_schedule injs,\n"
											+ " injection_schedule_details injsd,\n"
											+ " time_interval tm, contract_type ct \n"
											+ " where injs.INJECTION_SCHEDULE_UID = injsd.INJECTION_SCHEDULE_UID\n"
											+ " and injsd.TIME_INTERVAL_UID=tm.TIME_INTERVAL_UID\n"
											+ " and injs.CONTRACT_TYPE = ct.CONTRACT_TYPE_UID\n"
											+ " and injs.INJECTING_ENTITY = ?1 and injs.FOR_DATE = ?2 \n"
											+ " and injs.revision_number=?3"
											+ " group by FOR_DATE,ISSUE_DATE,TIME_INTERVAL_UID,CONTRACT_TYPE\n"
											+ " order by FOR_DATE,ISSUE_DATE,TIME_INTERVAL_UID,CONTRACT_TYPE";
	
	private static final Logger LOGGER = (Logger) LoggerFactory.getLogger(CustomInjectionScheduleDaoImpl.class);
	

	@Override
	public List<Object[]> findInjectionScheduleByQueryParams(
			InjectionScheduleQueryParamDto injectionScheduleQueryParamDto) {
	
		Query query = entityManager.createNativeQuery(SQL_QUERY);
		DateFormat df = new SimpleDateFormat(YYYY_MM_dd);
		String strDate = df.format(injectionScheduleQueryParamDto.getForDate());
		Date date = null;
		
		try {
			date = df.parse(strDate);
		} catch (ParseException e) {
			LOGGER.debug(e.getMessage(),e);
		}		
		query.setParameter(1, injectionScheduleQueryParamDto.getUtgId());
		query.setParameter(2, strDate);
		query.setParameter(3, injectionScheduleQueryParamDto.getRevisionNo());
				
		List<Object[]> listOfObjects = query.getResultList();
		
		return listOfObjects;
	}

	

	
	

}
