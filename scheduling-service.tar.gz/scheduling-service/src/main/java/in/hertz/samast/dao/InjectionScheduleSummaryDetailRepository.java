/**
 * 
 */
package in.hertz.samast.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import in.hertz.samast.entity.InjectionScheduleSummaryDetail;

/**
 * 
 * @author Bibhuti Parida
 * This is Injection Schedule Summary Detail Repository interface which manages injection_schedule_summary_detail table data for scheduling services
 *
 */
@Repository
public interface InjectionScheduleSummaryDetailRepository extends JpaRepository<InjectionScheduleSummaryDetail, Integer> {

}
