/**
 * 
 */
package in.hertz.samast.service;

import java.text.ParseException;
import java.util.Date;
import java.util.List;

import in.hertz.samast.domain.UtilityShareBO;
import in.hertz.samast.domain.exception.BusinessException;
import in.hertz.samast.util.UtilityShareType.ShareType;

/**
 * @author vikas
 *
 */
public interface UtilityShareService {
	
	public void addUtilityShare(List<UtilityShareBO> boList) throws BusinessException, Exception;
	
	public UtilityShareBO findById(int utilityShareId) throws BusinessException, Exception;

	public void editUtilityShare(List<UtilityShareBO> bos) throws BusinessException,ParseException; 

	public List<UtilityShareBO> findInjectorShareBO(int utgId, Date forDate, ShareType shareType) throws ParseException, BusinessException;

	public void deleteUtilityShare(Integer utilityShareId) throws BusinessException;

}
