package in.hertz.samast.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import in.hertz.samast.entity.Generation;
import in.hertz.samast.entity.UtilitiesTraderGenco;

@Repository
public interface GenerationRepository extends JpaRepository<Generation, Integer> {
	
 @Query("SELECT g FROM Generation g "
		+ "WHERE g.generationTypeDetail.generationTypeShortName IN (:shortName) OR g.energySourceDetail.sourceName IN (:sourceName)")
	public List<Generation> getIdByShortName(List<String> shortName, List<String> sourceName ) throws Exception;

 @Query("SELECT g FROM Generation g WHERE g.utilitiesTraderGenco = :utilitiesTraderGenco")
 	public Generation findByUtg(UtilitiesTraderGenco utilitiesTraderGenco) throws Exception;
}
