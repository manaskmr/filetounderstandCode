/**
 * 
 */
package in.hertz.samast.dao;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import in.hertz.samast.entity.ForecastSubscriptionUsages;

/**
 * @author Bibhuti Parida
 *
 */
@Repository
public interface ForecastSubscriptionUsagesRepository   extends JpaRepository<ForecastSubscriptionUsages, Integer> {

	@Query("SELECT fsu FROM ForecastSubscriptionUsages fsu WHERE fsu.utilitiesTraderGencoPSS.UID = :pssUtgId and fsu.forDate = :forDate")
	public List<ForecastSubscriptionUsages> findByPSSId(@Param("pssUtgId") int pssUtgId, @Param("forDate") Date forDate);
}
