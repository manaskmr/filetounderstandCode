package in.hertz.samast.dao;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import in.hertz.samast.entity.ContractDefination;

/*
 * 
 * @author Dipu Kumar
 * 
 */

@Repository
public interface ContractDefinitionDao extends JpaRepository<ContractDefination, Integer> {
	
	@Query("SELECT cd FROM ContractDefination cd WHERE cd.injector.UID = :injectorUtgId AND cd.fromDate <= :forDate AND cd.toDate >= :forDate")
	public List<ContractDefination> findAllContractDefinition(@Param("injectorUtgId") int injectorUtgId, @Param("forDate") Date forDate) throws Exception;
	
	@Query("SELECT cd FROM ContractDefination cd WHERE cd.injector.UID = :injectorUtgId AND cd.drawee.UID = :draweeUtgId AND cd.fromDate <= :forDate AND cd.toDate >= :forDate")
	public ContractDefination findContractDefinition(@Param("injectorUtgId") int injectorUtgId, @Param("draweeUtgId") int draweeUtgId, @Param("forDate") Date forDate) throws Exception; 
}