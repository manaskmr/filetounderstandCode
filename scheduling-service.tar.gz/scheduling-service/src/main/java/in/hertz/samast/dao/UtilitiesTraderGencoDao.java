package in.hertz.samast.dao;

import java.math.BigInteger;

import org.springframework.data.jpa.repository.JpaRepository;

import in.hertz.samast.entity.UtilitiesTraderGenco;
import in.hertz.samast.entity.coalposition.CoalPosition;

public interface UtilitiesTraderGencoDao extends JpaRepository<UtilitiesTraderGenco,Integer>{

}
