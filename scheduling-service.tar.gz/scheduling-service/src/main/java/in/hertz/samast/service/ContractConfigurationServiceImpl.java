package in.hertz.samast.service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;

import ch.qos.logback.classic.Logger;
import in.hertz.samast.dao.ContractConfigurationDao;
import in.hertz.samast.dao.ContractTypeDao;
import in.hertz.samast.dao.DraftRepository;
import in.hertz.samast.dao.UtilitiesTraderGencoDao;
import in.hertz.samast.domain.ContractConfigurationSearchDto;
import in.hertz.samast.domain.ContractConfigurationTimeblockedDto;
import in.hertz.samast.domain.ContractDefinitionDto;
import in.hertz.samast.domain.ContractQuantumDto;
import in.hertz.samast.domain.Page;
import in.hertz.samast.domain.UtilityTraderGencoDTO;
import in.hertz.samast.domain.exception.BusinessException;
import in.hertz.samast.entity.ContractDefination;
import in.hertz.samast.entity.ContractQuantum;
import in.hertz.samast.entity.Draft;
import in.hertz.samast.entity.TimeInterval;
import in.hertz.samast.entity.UtilitiesTraderGenco;

@Service
public class ContractConfigurationServiceImpl implements ContractConfigurationService{
	
	@Autowired
	ContractConfigurationDao configurationContractDao;
	
	@Autowired
	UtilitiesTraderGencoDao utilitiesTraderGencoDao;
	
	@Autowired
	ContractTypeDao contractTypeDao;
		
	@Autowired
	private DraftRepository<ContractDefinitionDto> draftRepoistoryDao;
	
	@Autowired
	private TimeIntervalService timeIntervalService;
	
	private static final String FUNCTIONALITY_AREA= "Scheduling_Contract";
	private static final String FAILURE_MESSAGE = "Contract Configuration Draft having date %s and approvalno %s not found";
	private static final String DD_MM_YYYY_FORMAT = "dd-MM-yyyy";
	private static final String YYYY_MM_DD = "yyyy-MM-dd";
	private static final String TIME_FORMAT = "HH:mm";
	private static final Logger LOGGER = (Logger) LoggerFactory.getLogger(ContractConfigurationServiceImpl.class);
	
	private final ObjectMapper mapper = new ObjectMapper(); 
	
	
	@Override
	public boolean addConfigurationContract(ContractDefinitionDto contractDefinitionDto) throws BusinessException,Exception{
		
		boolean retVal = false;
		try {
			ContractDefination contractDefination = mapDtoToEntity(contractDefinitionDto);	
			retVal = configurationContractDao.save(contractDefination)!=null;
		}catch(Exception ex) {
			throw new BusinessException(ex.getMessage());
		}
		
		return retVal;
	}

	private ContractDefinitionDto mapEntityToDto(ContractDefination contractDefination) throws BusinessException, Exception{
		
		return convertToContractDefinationDto(contractDefination);
	}
	
	
	private ContractDefination mapDtoToEntity(ContractDefinitionDto contractDefinationDto) {
		return convertToContractDefination(contractDefinationDto);
	}
	
	
	private ContractDefination convertToContractDefination(ContractDefinitionDto contractDefinitionDto) {
		
		ContractDefination contractDefination = new ContractDefination();		
		contractDefination.setAcceptanceNumber(contractDefinitionDto.getAcceptanceNumber());
		contractDefination.setApplicationNumber(contractDefinitionDto.getApplicationNumber());
		contractDefination.setAcceptanceNumber(contractDefinitionDto.getAcceptanceNumber());
		contractDefination.setApplicantName(contractDefinitionDto.getApplicantName());
		
		contractDefination.setApplicationNumberAlias(contractDefinitionDto.getApplicationNumberAlias());
		contractDefination.setApprovalDate(contractDefinitionDto.getApprovalDate());
		
		contractDefination.setContractBelongTo(contractDefinitionDto.getContractBelongTo());
		contractDefination.setContractStatus(contractDefinitionDto.getContractStatus());
		contractDefination.setContractTypeUid(contractTypeDao.getById(contractDefinitionDto.getContractTypeUid()));
		contractDefination.setDrawee(utilitiesTraderGencoDao.findById(contractDefinitionDto.getDrawee()).get());
		contractDefination.setDraweeName(contractDefinitionDto.getDraweeName());
		contractDefination.setFromDate(contractDefinitionDto.getFromDate());
		contractDefination.setToDate(contractDefinitionDto.getToDate());
		contractDefination.setIssueDate(contractDefinitionDto.getIssueDate());
		contractDefination.setRoute(contractDefinitionDto.getRoute());
		contractDefination.setRevisionNo(contractDefinitionDto.getRevisionNo());
		
		contractDefination.setInjector(utilitiesTraderGencoDao.findById(contractDefinitionDto.getInjector()).get());
		contractDefination.setInjectorName(contractDefinitionDto.getInjectorName());
		
		
		
		List<ContractQuantumDto> listContractQuantumDto = convertContractConfigurationTimeblockedDtoToContractQuantumDto(contractDefinitionDto);
		contractDefinitionDto.setListcontractQuantumDto(listContractQuantumDto);
		
		if(contractDefinitionDto.getListcontractQuantumDto().size()>0) {
			contractDefination.setContractQuantums(new ArrayList<ContractQuantum>());
		}
		
		
		ContractQuantum contractQuantum = null;
				
		for(ContractQuantumDto contractQuantumDto : contractDefinitionDto.getListcontractQuantumDto()) {
			contractQuantum = new ContractQuantum();
			contractQuantum.setFromBlock(contractQuantumDto.getFromBlock());
			contractQuantum.setToBlock(contractQuantumDto.getToBlock());
			contractQuantum.setQuantum(contractQuantumDto.getQuantum().floatValue());
			contractQuantum.setContractDefination(contractDefination);
			contractDefination.getContractQuantums().add(contractQuantum);
		}
		
		return contractDefination;
		
		
	}
	
	private List<ContractQuantumDto> convertContractConfigurationTimeblockedDtoToContractQuantumDto(ContractDefinitionDto contractDefinitionDto) {
		
		List<ContractConfigurationTimeblockedDto> listContractConfigurationTimeblockedDto = contractDefinitionDto.getListcontractQuantumTimeBlockedDto();
		
		List<ContractQuantumDto> listContractQuantumDto = new ArrayList<>();
		
		Map<Double,  List<ContractConfigurationTimeblockedDto>> mapByQuantum;
	    mapByQuantum = listContractConfigurationTimeblockedDto.stream().collect(Collectors.groupingBy(ContractConfigurationTimeblockedDto::getQuantum));
	    
	    for (Map.Entry<Double,List<ContractConfigurationTimeblockedDto>> entry : mapByQuantum.entrySet()) {
	    	
	    	Double quantum = entry.getKey();
	    	int startingBlockNo= 0;
	    	int endingBlockNo = 0;
	    	ContractQuantumDto contractQuantumDto = null;
	    	
	    	List<ContractConfigurationTimeblockedDto> listContractConfigurationTimeblockedDto1  = entry.getValue();
	    	
	    	if(listContractConfigurationTimeblockedDto1!=null) {	    	
	    		int size = listContractConfigurationTimeblockedDto1.size();
	    		startingBlockNo = listContractConfigurationTimeblockedDto1.get(0).getTimeBlockNumber();
	    		endingBlockNo = listContractConfigurationTimeblockedDto1.get(size-1).getTimeBlockNumber();
	    		contractQuantumDto = new ContractQuantumDto();
	    		contractQuantumDto.setFromBlock(startingBlockNo);
	    		contractQuantumDto.setToBlock(endingBlockNo);
	    		contractQuantumDto.setQuantum(quantum);
	    		listContractQuantumDto.add(contractQuantumDto);
	    	}	    	
	    }
		return listContractQuantumDto;
	}
	
	
	private ContractDefinitionDto convertToContractDefinationDto(ContractDefination contractDefination) throws BusinessException, Exception{
		
		ContractDefinitionDto contractDefinitionDto = new ContractDefinitionDto();
		
		contractDefinitionDto.setAcceptanceNumber(contractDefination.getAcceptanceNumber());
		contractDefinitionDto.setApplicant(contractDefination.getApplicantName());
		contractDefinitionDto.setApplicationNumber(contractDefination.getApplicationNumber());
		contractDefinitionDto.setAcceptanceNumber(contractDefination.getAcceptanceNumber());
		
		contractDefinitionDto.setApplicationNumberAlias(contractDefination.getApplicationNumberAlias());
		contractDefinitionDto.setApprovalDate(contractDefination.getApprovalDate());
		
		contractDefinitionDto.setContractBelongTo(contractDefination.getContractBelongTo());
		contractDefinitionDto.setContractStatus(contractDefination.getContractStatus());
		contractDefinitionDto.setContractTypeUid(contractDefination.getContractTypeUid().getUID());
		contractDefinitionDto.setDrawee(contractDefination.getDrawee().getUID());
		contractDefinitionDto.setDraweeName(utilitiesTraderGencoDao.findById(contractDefinitionDto.getDrawee()).get().getName());
		contractDefinitionDto.setFromDate(contractDefination.getFromDate());
		contractDefinitionDto.setIssueDate(contractDefination.getIssueDate());
		
		contractDefinitionDto.setContractType(contractTypeDao.findById(contractDefination.getContractTypeUid().getUID()).get().getShortName());
		
		contractDefinitionDto.setInjector(contractDefination.getInjector().getUID());
		contractDefinitionDto.setInjectorName(utilitiesTraderGencoDao.findById(contractDefinitionDto.getInjector()).get().getName());
		
		if(contractDefination.getContractQuantums().size()>0) {
			contractDefinitionDto.setListcontractQuantumDto(new ArrayList<ContractQuantumDto>());
		}
		
		ContractQuantumDto contractQuantumDto = null;
		List<ContractQuantum>listContractQuatum = contractDefination.getContractQuantums();
		
		for(ContractQuantum contractQuantum : listContractQuatum) {
			contractQuantumDto = new ContractQuantumDto();
			contractQuantumDto.setFromBlock(contractQuantum.getFromBlock());
			contractQuantumDto.setToBlock(contractQuantum.getToBlock());
			contractQuantumDto.setQuantum((double)contractQuantum.getQuantum());
			contractQuantumDto.setContractDefinitionUid(contractQuantum.getContractDefination().getUID());
			contractQuantumDto.setContractQuantumUid(contractQuantum.getUID());
			
			TimeInterval timeInterval1 =  timeIntervalService.findByBlock(contractQuantum.getFromBlock());
			TimeInterval timeInterval2 = timeIntervalService.findByBlock(contractQuantum.getToBlock());
			
			DateFormat timeFormat = new SimpleDateFormat(TIME_FORMAT);
			
			contractQuantumDto.getSchedule()[0].setStartSchedule(timeFormat.format(timeInterval1.getTimeInterval()));
			contractQuantumDto.getSchedule()[0].setEndSchedule(timeFormat.format(timeInterval1.getToTime()));
			
			contractQuantumDto.getSchedule()[1].setStartSchedule(timeFormat.format(timeInterval2.getTimeInterval()));
			contractQuantumDto.getSchedule()[1].setEndSchedule(timeFormat.format(timeInterval2.getToTime()));
			contractDefinitionDto.getListcontractQuantumDto().add(contractQuantumDto);
		}
		
		return contractDefinitionDto;
	}


	@Override
	public List<ContractDefinitionDto> findAllContractDefinitionByParams(ContractConfigurationSearchDto contractConfigurationSearchDto,int pageNo, int pageSize ) throws BusinessException, Exception {
		
		List<ContractDefination> listContractDefination = configurationContractDao.findContractDefinitionByMultiPleParams(contractConfigurationSearchDto,pageNo,pageSize);
		List<ContractDefinitionDto> listContractDefinitionDto = new ArrayList<>();
		ContractDefinitionDto contractDefinitionDto = null;
		LOGGER.info("listContractDefination size ==" +listContractDefination.size());
		
		try {
			for(ContractDefination contractDefination:listContractDefination) {
				contractDefinitionDto = convertToContractDefinationDto(contractDefination);
				listContractDefinitionDto.add(contractDefinitionDto);
			}
		} catch (Exception e) {
			
			throw new BusinessException(e.getMessage());
		}
		return listContractDefinitionDto;
	}
	
	
	@Override
	public Page<List<ContractDefinitionDto>> findAllPagedContractDefinitionByParams(
		ContractConfigurationSearchDto contractConfigurationSearchDto, int pageNo, int pageSize) throws BusinessException, Exception {
		
		

		Page<List<ContractDefination>> pagelistContractDefination = configurationContractDao.findPagedContractDefinitionByMultiPleParams(contractConfigurationSearchDto,pageNo,pageSize);
		Page<List<ContractDefinitionDto>> pagelistContractDefinationDto = null;
		
		List<ContractDefination> listContractDefination = pagelistContractDefination.getData();
		ContractDefinitionDto contractDefinitionDto = null;
		List<ContractDefinitionDto> listContractDefinitionDto = new ArrayList<>();
		
		try {
			for(ContractDefination contractDefination:listContractDefination) {
				contractDefinitionDto = convertToContractDefinationDto(contractDefination);
				
				String draweeName = null;
				String injectorName = null;
				String contractType = null;
				if(utilitiesTraderGencoDao.findById(contractDefinitionDto.getDrawee()).isPresent()) {
					draweeName = utilitiesTraderGencoDao.findById(contractDefinitionDto.getDrawee()).get().getName();
				}
				
				if(utilitiesTraderGencoDao.findById(contractDefinitionDto.getInjector()).isPresent()) {
					injectorName = utilitiesTraderGencoDao.findById(contractDefinitionDto.getInjector()).get().getName();
				}
				contractDefinitionDto.setDraweeName(draweeName);
				contractDefinitionDto.setInjectorName(injectorName);
				
				if(contractTypeDao.findById(contractDefinitionDto.getContractTypeUid()).isPresent()) {
					contractType = contractTypeDao.findById(contractDefinitionDto.getContractTypeUid()).get().getShortName();
				}
				contractDefinitionDto.setContractType(contractType);	
				    
				listContractDefinitionDto.add(contractDefinitionDto);
			}
		} catch (Exception e) {
			throw new BusinessException(e.getMessage());
		}
		pagelistContractDefinationDto = new Page<>(pageNo,pageSize,pagelistContractDefination.getTotalCount(),listContractDefinitionDto);
		
		return pagelistContractDefinationDto;
	}


	@Override
	public boolean saveAsDraft(ContractDefinitionDto contractDefinitionDto) throws BusinessException {
		boolean retval = false;
		ContractDefinitionDto contractDefinitionDtoBOExits = null;
		
		SimpleDateFormat sdf =new SimpleDateFormat(DD_MM_YYYY_FORMAT);
		SimpleDateFormat sdf2 =new SimpleDateFormat(YYYY_MM_DD);
		
		String strdate = sdf.format(contractDefinitionDto.getIssueDate());
		String sdate = sdf2.format(contractDefinitionDto.getIssueDate());
		
		try {
			
			List<Draft<ContractDefinitionDto>> listDraft = draftRepoistoryDao.findContractConfigurationDraftByDate(sdf2.parse(sdate));
			Draft<ContractDefinitionDto> draft = null;
			LOGGER.info("listDraftdraft =" + listDraft);
			
			if(listDraft==null || (listDraft!=null && checkDraftExistsByDateContractTypeAndInjectorAndDrawee(listDraft, contractDefinitionDto)==false)) {
				draft = new Draft<>();					
				draft.setCreatedBy(contractDefinitionDto.getCreatedBy());
				draft.setInsertTime(new Date());
				draft.setFunctionalityArea(FUNCTIONALITY_AREA);
				draft.setStatus("NEW");
				draft.setData(contractDefinitionDto);
			} else {				
				for (Draft<ContractDefinitionDto> draft1 : listDraft) {			
					contractDefinitionDtoBOExits = mapper.convertValue(draft1.getData(), ContractDefinitionDto.class);
						if(contractDefinitionDtoBOExits.getAcceptanceNumber() == contractDefinitionDtoBOExits.getAcceptanceNumber()) {
							draft = draft1;
							break;
						}
				}
				if(draft!=null) {
					draft.setCreatedBy(draft.getCreatedBy());
					draft.setUpdatedBy(contractDefinitionDto.getCreatedBy());
					draft.setUpdateTime(new Date());
					draft.setFunctionalityArea(FUNCTIONALITY_AREA);
					draft.setStatus("Updated");
					draft.setData(contractDefinitionDto);
				} else {
					throw new BusinessException(String.format(FAILURE_MESSAGE, strdate,contractDefinitionDto.getAcceptanceNumber()));
				}
			}
			retval = draftRepoistoryDao.save(draft)!=null;
		}catch(Exception ex) {
			throw new BusinessException(ex.getMessage());
		}

		return retval;
	}
	
	private boolean checkDraftExistsByDateContractTypeAndInjectorAndDrawee(List<Draft<ContractDefinitionDto>> listDraftedContractDefinitionDto,ContractDefinitionDto contractDefinitionDto) {
		
		boolean retval = false;
		ContractDefinitionDto contractDefinitionDtoBOExists = null;
		
		for(Draft<ContractDefinitionDto> draft1 : listDraftedContractDefinitionDto)  {
			contractDefinitionDtoBOExists = mapper.convertValue(draft1.getData(), ContractDefinitionDto.class);
			
			if(contractDefinitionDtoBOExists.getContractTypeUid() == contractDefinitionDto.getContractTypeUid() && 
					contractDefinitionDtoBOExists.getInjector()== contractDefinitionDto.getInjector() && 
					contractDefinitionDtoBOExists.getDrawee() == contractDefinitionDto.getDrawee() &&
					contractDefinitionDtoBOExists.getAcceptanceNumber() == contractDefinitionDto.getAcceptanceNumber())
					 {
				retval = true;
				break;
			}
		}
		
		return retval;
	}


	@Override
	public List<UtilityTraderGencoDTO> getAllInjectingEntities() {
		
		List<UtilitiesTraderGenco> listUtilitiesTraderGenco = utilitiesTraderGencoDao.findAll();
		UtilityTraderGencoDTO utilityTraderGencoDto = null;
		List<UtilityTraderGencoDTO> listUtilityTraderGencoDto = new ArrayList<>();
		
		for(UtilitiesTraderGenco utilitiesTraderGenco : listUtilitiesTraderGenco) {
			utilityTraderGencoDto = new UtilityTraderGencoDTO();
			utilityTraderGencoDto.setUtilitiesTraderGencoId(utilitiesTraderGenco.getUID());
			utilityTraderGencoDto.setName(utilitiesTraderGenco.getName());
			utilityTraderGencoDto.setAliasName(utilitiesTraderGenco.getAliasName());
			listUtilityTraderGencoDto.add(utilityTraderGencoDto);
		}
		
		return listUtilityTraderGencoDto;
	}


	@Override
	public ContractDefinitionDto getDraftContractConfiguration(String approvalNo) {
		
		ContractDefinitionDto contractDefinitionDto = null;
		Draft<ContractDefinitionDto> draft = null;
		
		Draft<ContractDefinitionDto> draftContractDefinitionDto = draftRepoistoryDao.findDraftByApprovalNumber(approvalNo);
		
		return mapper.convertValue(draftContractDefinitionDto.getData(), ContractDefinitionDto.class);
	}


	@Override
	public Map<String,Object>getContractDefinationsBySearchCriteria(String criteria,Integer pageNo, Integer pageSize) throws BusinessException, Exception {
		
		Pageable paging = PageRequest.of(pageNo, pageSize);
		
		org.springframework.data.domain.Page<ContractDefination> pageContractDefinitions = configurationContractDao.getContractConfigurationBySearchCriteria(criteria,paging);
	    List<ContractDefination> listContractDefination = pageContractDefinitions.getContent();
	    	   
	    List<ContractDefinitionDto> listlistContractDefinationDto = new ArrayList<>();
	    ContractDefinitionDto contractDefinitionDto = null;
	    
	    for(ContractDefination contractDefination : listContractDefination) {
	    	contractDefinitionDto = convertToContractDefinationDto(contractDefination);
	    	listlistContractDefinationDto.add(contractDefinitionDto);
	    } 
	    LOGGER.info("criteria ==" +criteria);
	    LOGGER.info("listlistContractDefinationDto==" +listlistContractDefinationDto.size());
	    
	    Map<String,Object> map = new HashMap<>();
	    map.put("PageNo",pageContractDefinitions.getNumber());
		map.put("PageSize", pageContractDefinitions.getSize());
		map.put("NoOfPages", pageContractDefinitions.getTotalPages());
		map.put("ItemCount", pageContractDefinitions.getTotalElements());
		map.put("searchResult", listlistContractDefinationDto);
		
		
	   return map;
	}


	@Override
	public List<ContractDefinitionDto> viewAllContractConfigurationDto() throws BusinessException, Exception {
		List<ContractDefination> listContractDefination = null;	
		List<ContractDefinitionDto> listContractDefinationDto = null;
		
		try {
			 listContractDefination = configurationContractDao.findAll();
			 listContractDefinationDto = new ArrayList<>();			
		     ContractDefinitionDto  contractDefinitionDto = null;
					
			if (listContractDefination!=null) {
				try {
					for(ContractDefination contractDefination : listContractDefination) {
						contractDefinitionDto = mapEntityToDto(contractDefination);
						listContractDefinationDto.add(contractDefinitionDto);
					}
				} catch (Exception e) {
					throw new BusinessException(e.getMessage());
				}
			}
		}catch(Exception ex) {
			throw new BusinessException(ex.getMessage());
		}
		
		 return listContractDefinationDto;
	}	


}
