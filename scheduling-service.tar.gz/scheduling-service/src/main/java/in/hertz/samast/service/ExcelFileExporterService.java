package in.hertz.samast.service;

import java.io.ByteArrayInputStream;
import java.util.List;

import in.hertz.samast.domain.ContractDefinitionDto;
import in.hertz.samast.domain.exception.BusinessException;

public interface ExcelFileExporterService {
	
	public ByteArrayInputStream contractConfigurationByParamtersListToExcelFile(List<ContractDefinitionDto> listContractDefinitionDto) throws BusinessException,Exception;
	

}
