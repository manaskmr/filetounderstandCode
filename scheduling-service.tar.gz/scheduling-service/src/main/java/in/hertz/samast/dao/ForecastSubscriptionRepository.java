/**
 * 
 */
package in.hertz.samast.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import in.hertz.samast.entity.ForecastSubscription;

/**
 * @author Bibhuti Parida
 *
 */
@Repository
public interface ForecastSubscriptionRepository  extends JpaRepository<ForecastSubscription, Integer> {

	@Query("SELECT fs FROM ForecastSubscription fs WHERE fs.utilitiesTraderGencoPSS.UID = :pssUtgId and fs.status = 'APPROVED' and fs.remainingDays > 0")
	public List<ForecastSubscription> findByPSSId(@Param("pssUtgId") int pssUtgId);
}
