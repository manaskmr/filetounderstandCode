package in.hertz.samast.service;

import in.hertz.samast.domain.InjectionScheduleBO;
import in.hertz.samast.domain.ScheduleQuantumBaseDTO;
import in.hertz.samast.domain.exception.BusinessException;

public interface SldcApprovalService {

	public boolean approveDcBySldc(ScheduleQuantumBaseDTO ursBO) throws Exception, BusinessException;

	public ScheduleQuantumBaseDTO rejectDcBySldc(ScheduleQuantumBaseDTO ursBO) throws Exception, BusinessException;
	
	public boolean sldcApproveInjectionSchedule(InjectionScheduleBO ursBO) throws Exception, BusinessException;
	
	public InjectionScheduleBO sldcRejectInjectionSchedule(InjectionScheduleBO ursBO) throws Exception, BusinessException;



}
