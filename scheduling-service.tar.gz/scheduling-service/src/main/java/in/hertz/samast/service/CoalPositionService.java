package in.hertz.samast.service;

import java.text.ParseException;
import java.util.Date;
import java.util.List;

import in.hertz.samast.domain.CoalPositionBO;
import in.hertz.samast.domain.DraftDTO;
import in.hertz.samast.domain.exception.BusinessException;
import in.hertz.samast.entity.Draft;
import in.hertz.samast.entity.TimeInterval;

public interface CoalPositionService {
	public CoalPositionBO newCoalPosition(Date forDate, int utgId) throws BusinessException;
	public CoalPositionBO saveCoalPosition(CoalPositionBO coalPositionBO) throws BusinessException, ParseException;	
	public CoalPositionBO updateCoalPosition(CoalPositionBO coalPositionBO) throws BusinessException, ParseException;	
	public List<CoalPositionBO> getAllCoalPositions() throws BusinessException;
	public CoalPositionBO getCoalPositionByDate(Date date, int utgId) throws BusinessException, ParseException;
	public Draft<CoalPositionBO> saveAsDraft(DraftDTO<CoalPositionBO> draftDTO) throws BusinessException, ParseException;
	public Draft<CoalPositionBO> getDraftedCoalPositionByDateAndUtgId(Date forDate, int utgId) throws BusinessException;
	public TimeInterval getCurrentTimeBlock()  throws Exception, BusinessException;
}