/**
 * 
 */
package in.hertz.samast.ctrl;

import java.util.Date;
import java.util.List;
import java.util.Objects;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.hertz.samast.domain.UtilityShareBO;
import in.hertz.samast.domain.WSResp;
import in.hertz.samast.domain.exception.BusinessException;
import in.hertz.samast.service.UtilityShareService;
import in.hertz.samast.util.UtilityShareType.ShareType;

/**
 * @author sandeep
 *
 */
@RestController
@RequestMapping("/utility-share")
public class UtilityShareCtrl {
	
	@Autowired
	private UtilityShareService utilityShareService;

	@GetMapping("/injector/{utgId}/{forDate}/{shareType}")
	public ResponseEntity<WSResp<List<UtilityShareBO>>> getUtilityShare(@PathVariable("utgId") int utgId,
			@PathVariable("forDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date forDate, @PathVariable("shareType") ShareType shareType)
			throws Exception, BusinessException {
		List<UtilityShareBO> findInjectorShareBO = utilityShareService.findInjectorShareBO(utgId, forDate, shareType);

		if (CollectionUtils.isNotEmpty(findInjectorShareBO)) {
			return new ResponseEntity<>(
					new WSResp<>(findInjectorShareBO, true, "Utility Share Data Fetched Successfully!"), HttpStatus.OK);
		} else {
			return new ResponseEntity<>(
					new WSResp<>(findInjectorShareBO , false, "Utility Share not found"),
					HttpStatus.OK);
		}
	}
	
	@PostMapping("/saveUtilityShare")
	public ResponseEntity<WSResp<UtilityShareBO>> saveUtilityShare(
			@RequestBody List<UtilityShareBO> shareList) throws Exception, BusinessException {
		utilityShareService.addUtilityShare(shareList);
		return new ResponseEntity<>(
				new WSResp<>(new UtilityShareBO(), true, "Data Saved Successfully."),
				HttpStatus.OK);
		
	}

	@DeleteMapping("/deleteUtilityShare/{utilityShareId}")
	public ResponseEntity<WSResp<Integer>> deleteUtilityShare(
			@PathVariable("utilityShareId") int utilityShareId) throws Exception, BusinessException {
		
		if (utilityShareService.findById(utilityShareId) != null) {
			utilityShareService.deleteUtilityShare(utilityShareId);
			return new ResponseEntity<>(
					new WSResp<>(utilityShareId, true, "Data Deleted Successfully."),
					HttpStatus.OK);
		} else {
			return new ResponseEntity<>(
					new WSResp<>(utilityShareId, true, "Data not Deleted."),
					HttpStatus.OK);
		}
	}
	
	@PostMapping("/updateUtilityShare")
	public ResponseEntity<WSResp<UtilityShareBO>> updateUtilityShare(
			@RequestBody List<UtilityShareBO> boList) throws Exception, BusinessException {
		utilityShareService.editUtilityShare(boList);
		return new ResponseEntity<>(
				new WSResp<>(new UtilityShareBO(), true, "Data Updated Successfully."),
				HttpStatus.OK);
	}

	@GetMapping("/getShare/{utilityShareId}")
	public ResponseEntity<WSResp<UtilityShareBO>> getUtilityShare(@PathVariable("utilityShareId") int utilityShareId)
			throws Exception, BusinessException {
		UtilityShareBO findById = utilityShareService.findById(utilityShareId);
		if (Objects.nonNull(findById)) {
			return new ResponseEntity<>(
					new WSResp<>(findById, true, "Utility Share Data Fetched Successfully!"), HttpStatus.OK);
		} else {
			return new ResponseEntity<>(
					new WSResp<>(findById , false, "Utility Share not found"),
					HttpStatus.OK);
		}
	}

}