package in.hertz.samast.dao;

import java.util.List;

import in.hertz.samast.domain.InjectionScheduleQueryParamDto;

public interface CustomInjectionScheduleDao {

	
	List<Object[]>findInjectionScheduleByQueryParams(InjectionScheduleQueryParamDto injectionScheduleQueryParamDto);
}
