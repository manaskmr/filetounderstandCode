package in.hertz.samast.dao;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import in.hertz.samast.entity.ContractDefination;

public interface ContractConfigurationDao extends JpaRepository<ContractDefination,Integer>,CustomConfigurationContractDao{
	@Query(
			value="Select cd from ContractDefination cd "
			+ " where LOWER(cd.injector.name) LIKE LOWER(CONCAT('%',:criteria, '%')) OR "
			+ " LOWER(cd.drawee.name) LIKE LOWER(CONCAT('%',:criteria, '%')) OR"
			+ " LOWER(cd.fromDate) LIKE LOWER(CONCAT('%',:criteria, '%')) OR"
			+ " LOWER(cd.toDate) LIKE LOWER(CONCAT('%',:criteria, '%')) OR" 
			+ " LOWER(cd.applicantName) LIKE LOWER(CONCAT('%',:criteria, '%')) OR"
			+ " LOWER(cd.acceptanceNumber) LIKE LOWER(CONCAT('%',:criteria, '%'))",
			
			countQuery = "Select count(*) from ContractDefination cd1 "
						+ " where LOWER(cd1.injector.name) LIKE LOWER(CONCAT('%',:criteria, '%')) OR"
						+ " LOWER(cd1.drawee.name) LIKE LOWER(CONCAT('%',:criteria, '%')) OR"
						+ " LOWER(cd1.fromDate) LIKE LOWER(CONCAT('%',:criteria, '%')) OR"
						+ " LOWER(cd1.toDate) LIKE LOWER(CONCAT('%',:criteria, '%')) OR"
						+ " LOWER(cd1.applicantName) LIKE LOWER(CONCAT('%',:criteria, '%')) OR"
						+ " LOWER(cd1.acceptanceNumber) LIKE LOWER(CONCAT('%',:criteria, '%'))"
			)
	public org.springframework.data.domain.Page<ContractDefination> getContractConfigurationBySearchCriteria(@Param("criteria")String criteria,Pageable pageable);


}
