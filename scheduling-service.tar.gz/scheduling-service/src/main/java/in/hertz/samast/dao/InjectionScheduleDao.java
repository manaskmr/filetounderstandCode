package in.hertz.samast.dao;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import in.hertz.samast.entity.InjectionSchedule;
import org.springframework.stereotype.Repository;

/*
 * 
 * @author Dipu Kumar
 * @author Sumanta Sen
 * 
 */

@Repository
public interface InjectionScheduleDao extends JpaRepository<InjectionSchedule, Integer>, CustomInjectionScheduleDao {

	@Query("SELECT max(a.revision) FROM InjectionSchedule a WHERE a.injectingEntity.UID = ?1 AND a.forDate = ?2")
	public Integer findLatestRevision(@Param("gencoUtgId") int gencoUtgId, @Param("forDate") Date forDate);
}

