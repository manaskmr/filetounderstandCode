package in.hertz.samast.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import ch.qos.logback.classic.Logger;
import in.hertz.samast.ctrl.ContractConfigurationController;
import in.hertz.samast.domain.ContractConfigurationSearchDto;
import in.hertz.samast.domain.Page;
import in.hertz.samast.entity.ContractDefination;


public class CustomConfigurationContractDaoImpl implements CustomConfigurationContractDao {

	@PersistenceContext
    private EntityManager entityManager;
	
	@Autowired
	private UtilitiesTraderGencoDao utilitiesTraderGencoDao;
	private static final Logger LOGGER = (Logger) LoggerFactory.getLogger(ContractConfigurationController.class);
	private int totalCount;

	@Override
	public List<ContractDefination> findContractDefinitionByMultiPleParams(
		 ContractConfigurationSearchDto contractConfigurationSearchDto,int pageNo, int pageSize) {
		
		 CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		 CriteriaQuery<ContractDefination> cq = cb.createQuery(ContractDefination.class);
		 CriteriaQuery<Long> criteriaQuery = cb.createQuery(Long.class);
		 
		 Root<ContractDefination> contractDefination = cq.from(ContractDefination.class);
		 contractDefination.alias("cont");
		 
		 List<Predicate> predicates = new ArrayList<>();
		 
		 if(contractConfigurationSearchDto.getApprovalNo()!=null) {
			 predicates.add(cb.equal(contractDefination.get("acceptanceNumber"), contractConfigurationSearchDto.getApprovalNo()));
		 }
		 if(contractConfigurationSearchDto.getContractType()!=0) {
			 
			 predicates.add(cb.equal(contractDefination.get("contractTypeUid"), contractConfigurationSearchDto.getContractType()));
		 }
		 if(contractConfigurationSearchDto.getFromDate()!=null) {
			 predicates.add(cb.equal(contractDefination.get("fromDate"), contractConfigurationSearchDto.getFromDate()));
		 }
		 if(contractConfigurationSearchDto.getToDate()!=null) {
			 predicates.add(cb.equal(contractDefination.get("toDate"), contractConfigurationSearchDto.getToDate()));
		 }
		 if(contractConfigurationSearchDto.getDrawee()!=0) {
			 predicates.add(cb.equal(contractDefination.get("drawee"), utilitiesTraderGencoDao.findById(contractConfigurationSearchDto.getDrawee()).get().getUID()));
		 }
		 if(contractConfigurationSearchDto.getInjector()!=0) {
			 predicates.add(cb.equal(contractDefination.get("injector"), utilitiesTraderGencoDao.findById(contractConfigurationSearchDto.getInjector()).get().getUID()));
		 }
		
		
		 
		 Predicate newPredicate = null;
		 long totalCount =0l;
		 
		 for(Predicate pred:predicates) {
			 if(newPredicate==null) {
				 newPredicate = cb.and(pred);
			 }else {
				 newPredicate= cb.and(pred,newPredicate);
			 }
		 }
		 
		
		 if(newPredicate!=null) {
		 	cq.where(newPredicate);
		 }
		
		 this.totalCount = getTotalCount(cb, newPredicate).intValue();
		 
		 LOGGER.info("tottalCount ===" +totalCount);
		 
		 
		 return entityManager
				 .createQuery(cq)
				 .setMaxResults(pageSize)
				 .setFirstResult(pageNo-1)
				 .getResultList();
	}
	
	private Long getTotalCount(CriteriaBuilder criteriaBuilder, Predicate predicate) {
        CriteriaQuery<Long> criteriaQuery = criteriaBuilder.createQuery(Long.class);
        Root<ContractDefination> root = criteriaQuery.from(ContractDefination.class);
        root.alias("cont");
        
        criteriaQuery.select(criteriaBuilder.count(root));
		 long totalCount = 0l;
              
        
        if(predicate!=null) {
          	criteriaQuery.where(predicate);
        }

        return entityManager.createQuery(criteriaQuery).getSingleResult();
    }

	@Override
	public Page<List<ContractDefination>> findPagedContractDefinitionByMultiPleParams(
			ContractConfigurationSearchDto contractConfigurationSearchDto,int pageNo, int pageSize) {
		
		List<ContractDefination> listContractDefination = findContractDefinitionByMultiPleParams(contractConfigurationSearchDto,pageNo,pageSize);
		
		
		return new Page<>(pageNo,pageSize,this.totalCount,listContractDefination);
	}
   
}
