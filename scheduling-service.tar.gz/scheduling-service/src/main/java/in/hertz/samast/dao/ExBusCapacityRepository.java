package in.hertz.samast.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import in.hertz.samast.entity.ExBusCapacity;

/**
 * 
 * @author Bibhuti Parida
 * This is Ex Bus Capacity Repository interface which manages utg_ex_bus_capacity table data for scheduling services
 *
 */
@Repository
public interface ExBusCapacityRepository extends JpaRepository<ExBusCapacity, Integer> {

	@Query("SELECT ebc FROM ExBusCapacity ebc where ebc.utilitiesTraderGenco.UID = :utgId")
	public List<ExBusCapacity> getExBusCapacityByUTG(@Param("utgId") int utgId) throws Exception;
	
	@Query("SELECT ebc FROM ExBusCapacity ebc where ebc.utilitiesTraderGenco.UID in ( select g.utilitiesTraderGenco.UID from Generation g where g.generationTypeDetail.generationTypeUid = :genTypeId)")
	public List<ExBusCapacity> getExBusCapacityByGenType(@Param("genTypeId") int genTypeId) throws Exception;
}
