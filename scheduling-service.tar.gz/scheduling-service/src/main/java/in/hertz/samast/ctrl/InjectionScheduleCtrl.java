
package in.hertz.samast.ctrl;

/**
 * 
 */

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.hertz.samast.domain.DraftDTO;
import in.hertz.samast.domain.InjectionScheduleBO;
import in.hertz.samast.domain.InjectionScheduleQueryParamDto;
import in.hertz.samast.domain.InjectionScheduleSummaryBO;
import in.hertz.samast.domain.PSSDetailsDTO;
import in.hertz.samast.domain.SldcApproveBo;
import in.hertz.samast.domain.WSResp;
import in.hertz.samast.domain.exception.BusinessException;
import in.hertz.samast.entity.Draft;
import in.hertz.samast.entity.ScheduleType;
import in.hertz.samast.entity.TimeInterval;
import in.hertz.samast.service.ContractDefinitionService;
import in.hertz.samast.service.InjectionScheduleService;

/**
 * @author Bibhuti Parida
 *
 */
@RestController
@RequestMapping("/injection-schedule")
public class InjectionScheduleCtrl {

	@Autowired
	private InjectionScheduleService injectionScheduleQCAService;

	
	@Autowired
	private InjectionScheduleService injectionScheduleService;
	
	@Autowired
	private ContractDefinitionService contractDefinitionService;
	
	@Value("${data.not.found}")
	private String dataNotFound;
	

	private static final Logger log = LogManager.getLogger(InjectionScheduleCtrl.class);

	@GetMapping("/pssByQCAId/{qcaUtgId}")
	public ResponseEntity<WSResp<List<PSSDetailsDTO>>> getPSSListByQCAId(@PathVariable("qcaUtgId") int qcaUtgId)
			throws Exception, BusinessException {
		List<PSSDetailsDTO> pssBOList = injectionScheduleQCAService.getPSSListByQCAId(qcaUtgId);

		if (CollectionUtils.isNotEmpty(pssBOList)) {
			return new ResponseEntity<WSResp<List<PSSDetailsDTO>>>(
					new WSResp<List<PSSDetailsDTO>>(pssBOList, true, "PSS Data Fetched Successfully!"), HttpStatus.OK);
		} else {
			return new ResponseEntity<WSResp<List<PSSDetailsDTO>>>(
					new WSResp<List<PSSDetailsDTO>>(pssBOList, false, "PSS not found for QCA"), HttpStatus.OK);
		}
	}

	@GetMapping("/{qcaUtgId}/{forDate}")
	public ResponseEntity<WSResp<List<InjectionScheduleBO>>> getPSSSummary(@PathVariable("qcaUtgId") int qcaUtgId,
			@PathVariable("forDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date forDate)
			throws Exception, BusinessException {
		List<InjectionScheduleBO> isBOList = injectionScheduleQCAService.getPSSSummary(forDate, qcaUtgId);
		if (CollectionUtils.isNotEmpty(isBOList)) {
			return new ResponseEntity<WSResp<List<InjectionScheduleBO>>>(
					new WSResp<List<InjectionScheduleBO>>(isBOList, true, "PSS summary Data Fetched Successfully!"),
					HttpStatus.OK);
		} else {
			return new ResponseEntity<WSResp<List<InjectionScheduleBO>>>(
					new WSResp<List<InjectionScheduleBO>>(isBOList, false, "PSS summary  not found"), HttpStatus.OK);
		}
	}

	@GetMapping("/injectionSchedule/{utgId}/{forDate}")
	public ResponseEntity<WSResp<InjectionScheduleBO>> getInjectionSchedule(@PathVariable("utgId") int utgId,
			@PathVariable("forDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date forDate)
			throws Exception, BusinessException {
		InjectionScheduleBO isBO = injectionScheduleQCAService.getInjectionScheduleByUTG(forDate, utgId);
		if (Objects.nonNull(isBO)) {
			return new ResponseEntity<WSResp<InjectionScheduleBO>>(
					new WSResp<InjectionScheduleBO>(isBO, true, "Injection Schedule Data Fetched Successfully!"),
					HttpStatus.OK);
		} else {
			return new ResponseEntity<WSResp<InjectionScheduleBO>>(
					new WSResp<InjectionScheduleBO>(isBO, false, "Injection Schedule not found"), HttpStatus.OK);
		}
	}

	@GetMapping("/injectionScheduleByRevNo/{utgId}/{forDate}/{revisionNo}")
	public ResponseEntity<WSResp<InjectionScheduleBO>> getInjectionScheduleByRevisionNo(
			@PathVariable("utgId") int utgId,
			@PathVariable("forDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date forDate,
			@PathVariable("revisionNo") int revisionNo) throws Exception, BusinessException {
		InjectionScheduleBO isBO = injectionScheduleQCAService.getInjectionScheduleByRevisionNo(forDate, utgId,
				revisionNo);
		if (Objects.nonNull(isBO)) {
			return new ResponseEntity<WSResp<InjectionScheduleBO>>(
					new WSResp<InjectionScheduleBO>(isBO, true, "Injection Schedule Data Fetched Successfully!"),
					HttpStatus.OK);
		} else {
			return new ResponseEntity<WSResp<InjectionScheduleBO>>(
					new WSResp<InjectionScheduleBO>(isBO, false, "Injection Schedule not found"), HttpStatus.OK);
		}
	}

	@GetMapping("/currentTimeBlock")
	public ResponseEntity<WSResp<TimeInterval>> getCurrentTimeBlock() throws Exception, BusinessException {
		TimeInterval timeBlock = injectionScheduleQCAService.getCurrentTimeBlock();
		if (Objects.nonNull(timeBlock)) {
			return new ResponseEntity<WSResp<TimeInterval>>(
					new WSResp<TimeInterval>(timeBlock, true, "Time Block fetched Successfully!"), HttpStatus.OK);
		} else {
			return new ResponseEntity<WSResp<TimeInterval>>(
					new WSResp<TimeInterval>(timeBlock, false, "Error in fetching Time block Data!"),
					HttpStatus.BAD_REQUEST);
		}
	}

	@GetMapping("/exBusCapacity/{utgId}")
	public ResponseEntity<WSResp<Integer>> getExBusCapacity(@PathVariable("utgId") int utgId)
			throws Exception, BusinessException {
		Integer exBusCapacity = injectionScheduleQCAService.getExBusCapacity(utgId);

		if (Objects.nonNull(exBusCapacity)) {
			return new ResponseEntity<WSResp<Integer>>(
					new WSResp<Integer>(exBusCapacity, true, "Ex-Bus Capacity fetched Successfully!"), HttpStatus.OK);
		} else {
			return new ResponseEntity<WSResp<Integer>>(
					new WSResp<Integer>(exBusCapacity, true, "Ex-Bus Capacity fetched Successfully!"), HttpStatus.OK);
		}
	}

	@GetMapping("/revisionNoByScheduleType/{utgId}/{forDate}/{scheduleType}")
	public ResponseEntity<WSResp<List<Integer>>> getRevisionNoByScheduleType(@PathVariable("utgId") int utgId,
			@PathVariable("forDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date forDate,
			@PathVariable("scheduleType") String scheduleType) throws Exception, BusinessException {
		List<Integer> revisionList = injectionScheduleQCAService.getRevisionNoByScheduleType(forDate, utgId,
				scheduleType);

		if (CollectionUtils.isNotEmpty(revisionList)) {
			return new ResponseEntity<WSResp<List<Integer>>>(
					new WSResp<List<Integer>>(revisionList, true, "Revision Number fetched Successfully!"),
					HttpStatus.OK);
		} else {
			revisionList = new ArrayList<Integer>();
			return new ResponseEntity<WSResp<List<Integer>>>(
					new WSResp<List<Integer>>(revisionList, true, "Revision Number fetched Successfully!"),
					HttpStatus.OK);
		}
	}

	@GetMapping("/allRevisionNo/{utgId}/{forDate}")
	public ResponseEntity<WSResp<List<Integer>>> getAllRevisionNo(@PathVariable("utgId") int utgId,
			@PathVariable("forDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date forDate)
			throws Exception, BusinessException {
		List<Integer> revisionList = injectionScheduleQCAService.getAllRevisionNo(forDate, utgId);

		if (CollectionUtils.isNotEmpty(revisionList)) {
			return new ResponseEntity<WSResp<List<Integer>>>(
					new WSResp<List<Integer>>(revisionList, true, "Revision Number fetched Successfully!"),
					HttpStatus.OK);
		} else {
			revisionList = new ArrayList<Integer>();
			return new ResponseEntity<WSResp<List<Integer>>>(
					new WSResp<List<Integer>>(revisionList, true, "Revision Number fetched Successfully!"),
					HttpStatus.OK);
		}
	}

	@GetMapping("/latestRevisionNo/{utgId}/{forDate}")
	public ResponseEntity<WSResp<Integer>> getLatestRevisionNo(@PathVariable("utgId") int utgId,
			@PathVariable("forDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date forDate)
			throws Exception, BusinessException {
		Integer revisionNo = injectionScheduleQCAService.getLatestRevisionNoByUTG(forDate, utgId);

		if (Objects.nonNull(revisionNo) ) {
			return new ResponseEntity<WSResp<Integer>>(
					new WSResp<Integer>(revisionNo, true, "Revision Number fetched Successfully!"),
					HttpStatus.OK);
		} else {
			revisionNo = null;
			return new ResponseEntity<WSResp<Integer>>(
					new WSResp<Integer>(revisionNo, true, "Revision Number fetched Successfully!"),
					HttpStatus.OK);
		}
	}

	@PostMapping("/saveDraft")
	public ResponseEntity<WSResp<Draft<InjectionScheduleBO>>> saveDraft(
			@RequestBody DraftDTO<InjectionScheduleBO> draftDTO) throws Exception, BusinessException {
		Draft<InjectionScheduleBO> savedDraft = injectionScheduleQCAService.saveDraft(draftDTO);
		if (Objects.nonNull(savedDraft)) {
			return new ResponseEntity<WSResp<Draft<InjectionScheduleBO>>>(
					new WSResp<Draft<InjectionScheduleBO>>(savedDraft, true, "Draft Data Saved Successfully!"),
					HttpStatus.OK);
		} else {
			return new ResponseEntity<WSResp<Draft<InjectionScheduleBO>>>(
					new WSResp<Draft<InjectionScheduleBO>>(savedDraft, false, "Error in Saving Draft Data!"),
					HttpStatus.BAD_REQUEST);
		}
	}

	@GetMapping("/draft/{utgId}/{forDate}")
	public ResponseEntity<WSResp<Draft<InjectionScheduleBO>>> findDraft(@PathVariable("utgId") int utgId,
			@PathVariable("forDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date forDate)
			throws Exception, BusinessException {
		Draft<InjectionScheduleBO> draftBO = injectionScheduleQCAService.fetchDraftData(forDate, utgId);
		if (Objects.nonNull(draftBO)) {
			return new ResponseEntity<WSResp<Draft<InjectionScheduleBO>>>(
					new WSResp<Draft<InjectionScheduleBO>>(draftBO, true, "Data Fetched Successfully!"), HttpStatus.OK);
		} else {
			return new ResponseEntity<WSResp<Draft<InjectionScheduleBO>>>(
					new WSResp<Draft<InjectionScheduleBO>>(draftBO, false, "Data not found"), HttpStatus.OK);
		}
	}

	@GetMapping("/newIS/{utgId}/{forDate}")
	public ResponseEntity<WSResp<InjectionScheduleBO>> newInjectionSchedule(@PathVariable("utgId") int utgId,
			@PathVariable("forDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date forDate)
			throws Exception, BusinessException {
		InjectionScheduleBO isBO = injectionScheduleQCAService.newInjectionSchedule(forDate, utgId);
		if (Objects.nonNull(isBO)) {
			return new ResponseEntity<WSResp<InjectionScheduleBO>>(
					new WSResp<InjectionScheduleBO>(isBO, true, "Injection ScheduleBO Data Saved Successfully!"),
					HttpStatus.OK);
		} else {
			return new ResponseEntity<WSResp<InjectionScheduleBO>>(
					new WSResp<InjectionScheduleBO>(isBO, false, "Error in Saving Injection Schedule Data!"),
					HttpStatus.BAD_REQUEST);
		}
	}

	@PostMapping("/saveIS")
	public ResponseEntity<WSResp<InjectionScheduleBO>> saveInjectionSchedule(
			@RequestBody InjectionScheduleBO injectionScheduleBO) throws Exception, BusinessException {
		InjectionScheduleBO respInjectionScheduleBO = injectionScheduleQCAService
				.saveInjectionSchedule(injectionScheduleBO);
		if (Objects.nonNull(respInjectionScheduleBO)) {
			return new ResponseEntity<WSResp<InjectionScheduleBO>>(new WSResp<InjectionScheduleBO>(
					respInjectionScheduleBO, true, "Injection Schedule Data Saved Successfully!"), HttpStatus.OK);
		} else {
			return new ResponseEntity<WSResp<InjectionScheduleBO>>(
					new WSResp<InjectionScheduleBO>(respInjectionScheduleBO, false,
							"Error in Saving Injection Schedule Data!"),
					HttpStatus.BAD_REQUEST);
		}

	}


    @GetMapping("/serach-injection-schedule-by-params")
	public ResponseEntity<WSResp<Map>> getAllInjectionScheduleByParams1(InjectionScheduleQueryParamDto injectionScheduleQueryParamDto) throws BusinessException, Exception {
		
		
		Map<String,List> map = injectionScheduleService.getInjectionScheduleContractTypeQuantums1(injectionScheduleQueryParamDto);
		
		String response = "Record processed successfully!";
		
		return new ResponseEntity<>(new WSResp<>(map,true,response),HttpStatus.OK);
    }
	
	@GetMapping("/latest-revision/{gencoUtgId}/{date}/{schType}")
	public WSResp<Integer> findLatestRevisionOfInjectionSchedule(@PathVariable int gencoUtgId, @PathVariable @DateTimeFormat(pattern = "yyyy-MM-dd") Date date, @PathVariable String schType) throws BusinessException, Exception {
		Integer revisionNo = injectionScheduleQCAService.findLatestRevision(gencoUtgId, date, schType);
		if (Objects.nonNull(revisionNo) ) {
			return new WSResp<Integer>(revisionNo, true, "Latest revision number fetched successfully");
		} else {
			return new WSResp<Integer>(revisionNo, false, "Error in fetching latest revision number");
		}
	}
	
	@GetMapping("/contract-definitions/{gencoUtgId}/{date}/{schType}")
	public WSResp<List<InjectionScheduleBO>> findContractDefinations(@PathVariable int gencoUtgId, @PathVariable @DateTimeFormat(pattern = "yyyy-MM-dd") Date date, @PathVariable String schType) throws BusinessException, Exception {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		if (schType.equalsIgnoreCase(ScheduleType.DAY_AHEAD.toString()))
			calendar.add(Calendar.DATE, 1);
		Date forDate = calendar.getTime();
		List<InjectionScheduleBO> injectionScheduleBOs = contractDefinitionService.findAllContractDefinition(gencoUtgId, forDate);
		if (injectionScheduleBOs != null)
			return new WSResp<>(injectionScheduleBOs, true, "Contract definition data fetched successfully");
		return new WSResp<>(injectionScheduleBOs, false, "Error in fetching the contract definition data");
	}
	
	@PostMapping("/drafts")
	public WSResp<Void> saveInjectionScheduleDataAsDraft(@RequestBody List<InjectionScheduleBO> injectionScheduleBOs) throws BusinessException, Exception {
		if (injectionScheduleQCAService.saveInjectionScheduleDataAsDraft(injectionScheduleBOs))
			return new WSResp<Void>(null, true, "Draft data saved successfully");
		return new WSResp<Void>(null, false, "Error in saving the draft data");
	}
	
	@PostMapping("/send-to-sldc")
	public WSResp<Void> sendInjectionScheduleDataToSldc(@RequestBody List<InjectionScheduleBO> injectionScheduleBOs) throws BusinessException, Exception {
		return injectionScheduleQCAService.saveInjectionScheduleData(injectionScheduleBOs) ?
			new WSResp<Void>(null, true, "Injection Schedule data sent to SLDC successfully") :
				new WSResp<Void>(null, false, "Error in sending the Injection Schedule data to the SLDC");
	}
	
	@GetMapping("/draft/{gencoUtgId}/{date}/{schType}/{revision}")
	public WSResp<List<Draft<InjectionScheduleBO>>> findDraftedInjectionSchedule(@PathVariable int gencoUtgId, @PathVariable @DateTimeFormat(pattern = "yyyy-MM-dd") Date date, @PathVariable String schType, @PathVariable int revision) throws BusinessException, Exception {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		if (schType.equalsIgnoreCase(ScheduleType.DAY_AHEAD.toString()))
			calendar.add(Calendar.DATE, 1);
		Date forDate = calendar.getTime();
		List<Draft<InjectionScheduleBO>> draft = injectionScheduleQCAService.findDraftedInjectionSchedule(gencoUtgId, forDate, revision);
		if (Objects.isNull(draft))
			return new WSResp<>(draft, false, "Could not fetch draft data");
		return new WSResp<>(draft, true, "Draft data fetched successfully");
	}

	@GetMapping("/injectionSummaryByQCAId/{qcaUtgId}/{forDate}")
	public ResponseEntity<WSResp<List<InjectionScheduleSummaryBO>>> getInjectionSummaryListByQCAId(
			@PathVariable("qcaUtgId") int qcaUtgId,
			@PathVariable("forDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date forDate)
			throws Exception, BusinessException {
		List<InjectionScheduleSummaryBO> isSummaryBOList = injectionScheduleQCAService
				.getInjectionSummaryListByQCAId(qcaUtgId, forDate);

		if (CollectionUtils.isNotEmpty(isSummaryBOList)) {
			return new ResponseEntity<WSResp<List<InjectionScheduleSummaryBO>>>(
					new WSResp<List<InjectionScheduleSummaryBO>>(isSummaryBOList, true,
							"Injection Schedule Summary Data Fetched Successfully!"),
					HttpStatus.OK);
		} else {
			return new ResponseEntity<WSResp<List<InjectionScheduleSummaryBO>>>(
					new WSResp<List<InjectionScheduleSummaryBO>>(isSummaryBOList, false,
							"Injection Schedule Summary not found for QCA"),
					HttpStatus.OK);
		}
	}

	@PostMapping("/latestRevisionDetails")
	public WSResp<List<InjectionScheduleBO>> getLatestRevisionDetailsBySourceName(@RequestBody SldcApproveBo sldcApproveBo)
			throws Exception, BusinessException {
		List<InjectionScheduleBO> dcBOList = injectionScheduleQCAService.getLatestRevisionDetailsBySourceName(sldcApproveBo);

		if (CollectionUtils.isNotEmpty(dcBOList)) {
			return new WSResp<>(dcBOList, true, null);
		} else {
			return new WSResp<>(null, false, dataNotFound);
					
		}
	}

	@PostMapping("/sldcViewInjectionSchedule")
	public WSResp<List<InjectionScheduleBO>> viewInjectionScheduleBySourceName(@RequestBody SldcApproveBo sldcApproveBo)
			throws Exception, BusinessException {
		List<InjectionScheduleBO> boList = injectionScheduleQCAService.viewInjectionScheduleBySourceNameUtgIdsAndQcaUtgIds(sldcApproveBo);

		if (CollectionUtils.isNotEmpty(boList)) {
			return 
					new WSResp<>(boList, true, null);
		} else {
			return 
					new WSResp<>(null, false, dataNotFound);
		}
		
	}

	@PostMapping("/sldcEditInjectionSchedule")
	public WSResp<InjectionScheduleBO> editInjectionScheduleByRevisionNoAndUtgId(@RequestBody SldcApproveBo sldcApproveBo)
			throws Exception, BusinessException {
		InjectionScheduleBO bo = injectionScheduleQCAService.editInjectionScheduleByRevisionNoAndUtgId(sldcApproveBo);
		if (Objects.nonNull(bo)) {
			return new WSResp<>(bo, true, null);
		} else {
			return new WSResp<>(null, false, dataNotFound);
		}
	}

	@GetMapping("/injectionScheduleByRevNoScheduleType/{utgId}/{forDate}/{revisionNo}/{scheduleType}")
	public ResponseEntity<WSResp<InjectionScheduleBO>> getInjectionScheduleByRevisionNoScheduleType(
			@PathVariable("utgId") int utgId,
			@PathVariable("forDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date forDate,
			@PathVariable("revisionNo") int revisionNo, @PathVariable("scheduleType") String scheduleType)
			throws Exception, BusinessException {
		InjectionScheduleBO isBO = injectionScheduleQCAService.getInjectionScheduleByRevisionNoScheduleType(forDate,
				utgId, revisionNo, scheduleType);
		if (Objects.nonNull(isBO)) {
			return new ResponseEntity<WSResp<InjectionScheduleBO>>(
					new WSResp<InjectionScheduleBO>(isBO, true, "Injection Schedule Data Fetched Successfully!"),
					HttpStatus.OK);
		} else {
			return new ResponseEntity<WSResp<InjectionScheduleBO>>(
					new WSResp<InjectionScheduleBO>(isBO, false, "Injection Schedule not found"), HttpStatus.OK);
		}
	}
	
	@PostMapping("/sldcViewInjectionScheduleDetails")
	public WSResp<List<InjectionScheduleBO>> viewInjectionScheduleByUtgIdAndRevisionNo(@RequestBody SldcApproveBo sldcApproveBo)
			throws Exception, BusinessException {
		List<InjectionScheduleBO> boList = injectionScheduleQCAService.viewInjectionScheduleByUtgIdAndRevisionNo(sldcApproveBo);

		if (CollectionUtils.isNotEmpty(boList)) {
			return new WSResp<>(boList, true, null);
		} else {
			return new WSResp<>(null, false, dataNotFound);
		}
	}
}
