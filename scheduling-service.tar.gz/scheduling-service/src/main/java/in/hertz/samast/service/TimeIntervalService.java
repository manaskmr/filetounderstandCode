/**
 * 
 */
package in.hertz.samast.service;

import java.util.Date;
import java.util.List;

import in.hertz.samast.domain.exception.BusinessException;
import in.hertz.samast.entity.TimeInterval;

/**
 * @author Bibhuti Parida
 *
 */
public interface TimeIntervalService {

	public TimeInterval getCurrentTimeBlock()  throws Exception, BusinessException;
	
	public List<TimeInterval> findAllTimeIntervals() throws Exception, BusinessException;
	
	public TimeInterval findByBlock(int block) throws Exception, BusinessException;
	
	public TimeInterval findTimeBlock(String time) throws Exception, BusinessException;
	
	public TimeInterval findTimeIntervalByFromTime(String fromTime) throws Exception, BusinessException;
	
	public TimeInterval findTimeIntervalByToTime(String toTime) throws Exception, BusinessException;
	
	public TimeInterval findTimeIntervalByBetweenTime(String betweenTime) throws Exception, BusinessException;
	
	public TimeInterval findTimeIntervalByBetweenTimeZone(String betweenTime) throws Exception, BusinessException;
	
	public Integer findMaxBlock() throws Exception, BusinessException;
	
	public long timeDifferent(Date existDate) throws Exception, BusinessException;
}
