package in.hertz.samast.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.hertz.samast.dao.ExBusCapacityRepository;
import in.hertz.samast.dao.GenerationUnitTypeRepository;
import in.hertz.samast.dao.UtilitiesTraderGencoRepository;
import in.hertz.samast.domain.ExBusCapacityBO;
import in.hertz.samast.domain.GenerationUnitBO;
import in.hertz.samast.domain.exception.BusinessException;
import in.hertz.samast.entity.ExBusCapacity;
import in.hertz.samast.entity.GenerationUnitType;
import in.hertz.samast.entity.UtilitiesTraderGenco;

/**
 * @author Bibhuti Parida
 * 
 * This is service implementation class for ExBus Capacity Service
 * Functionalities get ex bus capacity for generator
 *
 */
@Service
@Transactional
public class ExBusCapacityServiceImpl implements ExBusCapacityService {
	
	private static final Logger LOG = LogManager.getLogger(ExBusCapacityServiceImpl.class);
	
	@Autowired
	private ExBusCapacityRepository exBusCapacityRepository;
	
	@Autowired
	private UtilitiesTraderGencoRepository utilitiesTraderGencoRepository;
	
	@Autowired
	private GenerationUnitTypeRepository generationUnitTypeRepository;
	
	@Override
	public Integer getExBusCapacity(int utgId) throws Exception, BusinessException {
		LOG.info("Start ExBusCapacityServiceImpl:getExBusCapacity");
		int exbusCapacity = 0;
		List<ExBusCapacity> exbusCapacityList = exBusCapacityRepository.getExBusCapacityByUTG(utgId);
		if (CollectionUtils.isNotEmpty(exbusCapacityList)) {
			exbusCapacity = exbusCapacityList.get(0).getExBusSldc().intValue();
		}
		LOG.info("End ExBusCapacityServiceImpl:getExBusCapacity");
		return exbusCapacity;
	}
	
	@Override
	public List<ExBusCapacityBO> getAllExBusCapacity() throws Exception, BusinessException {
		List<ExBusCapacity> exbusList = exBusCapacityRepository.findAll();
		List<ExBusCapacityBO> exbusBoList = null;
		
		if (CollectionUtils.isNotEmpty(exbusList)) {
			exbusBoList = new ArrayList<ExBusCapacityBO>();
			for (ExBusCapacity exBusCapacity : exbusList) {
				ExBusCapacityBO exBusBo = new ExBusCapacityBO();
				BeanUtils.copyProperties(exBusCapacity, exBusBo);
				exBusBo.setUtgID(exBusCapacity.getUtilitiesTraderGenco().getUID());
				exBusBo.setGeneratorName(exBusCapacity.getUtilitiesTraderGenco().getName());
				exbusBoList.add(exBusBo);
			}
		}
		return exbusBoList;
	}
	
	@Override
	public List<ExBusCapacityBO> updateAllExBusCapacity(List<ExBusCapacityBO> exBusBoList) throws Exception, BusinessException {
		List<ExBusCapacity> exbusList = null;
		List<ExBusCapacity> updatedExbusList = null;
		if (CollectionUtils.isNotEmpty(exBusBoList)) {
			exbusList = new ArrayList<ExBusCapacity>();
			for (ExBusCapacityBO exBusCapacityBO : exBusBoList) {
				ExBusCapacity exBus = new ExBusCapacity();
				BeanUtils.copyProperties(exBusCapacityBO, exBus);
				Optional<UtilitiesTraderGenco> utgObj = utilitiesTraderGencoRepository.findById(exBusCapacityBO.getUtgID());
				if (utgObj.isPresent()) {
					UtilitiesTraderGenco utg = utgObj.get();
					exBus.setUtilitiesTraderGenco(utg);
				} else {
					exbusList.remove(exBusCapacityBO.getID().intValue());
				}
				exbusList.add(exBus);
			}
			updatedExbusList = exBusCapacityRepository.saveAll(exbusList);
		}
		if (CollectionUtils.isNotEmpty(updatedExbusList)) {
			return exBusBoList;
		} else {
			return null;
		}
	}
	
	@Override
	public List<ExBusCapacityBO> getExBusCapacityByGenType(int genTypeId) throws Exception, BusinessException {
		List<ExBusCapacity>  exbusList = exBusCapacityRepository.getExBusCapacityByGenType(genTypeId);
		List<ExBusCapacityBO> exBusBoList = null;
		if (CollectionUtils.isNotEmpty(exbusList)) {
			exBusBoList = new ArrayList<ExBusCapacityBO>();
			for (ExBusCapacity exBusCapacity : exbusList) {
				ExBusCapacityBO exbusBO = new ExBusCapacityBO();
				BeanUtils.copyProperties(exBusCapacity, exbusBO);
				exbusBO.setUtgID(exBusCapacity.getUtilitiesTraderGenco().getUID());
				exbusBO.setGeneratorName(exBusCapacity.getUtilitiesTraderGenco().getName());
				exBusBoList.add(exbusBO);
			}
		}
		return exBusBoList;
	}
	
	@Override
	public List<GenerationUnitBO> getAllGenType() throws Exception, BusinessException {
		List<GenerationUnitType> genTypeList = generationUnitTypeRepository.findAll();
		List<GenerationUnitBO> genTypeBOList = null;
		if (CollectionUtils.isNotEmpty(genTypeList)) {
			genTypeBOList = new ArrayList<GenerationUnitBO>();
			for (GenerationUnitType generationUnitType : genTypeList) {
				GenerationUnitBO guBO = new GenerationUnitBO();
				guBO.setGuTypeUid(generationUnitType.getGenerationTypeUid());
				guBO.setGuTypeName(generationUnitType.getGenerationTypeName());
				guBO.setGuTypeShorName(generationUnitType.getGenerationTypeShortName());
				genTypeBOList.add(guBO);
			}
		}
		return genTypeBOList;
	}
}