package in.hertz.samast.ctrl;

import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.apache.poi.ss.formula.functions.T;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import ch.qos.logback.classic.Logger;
import in.hertz.samast.domain.ContractConfigurationSearchDto;
import in.hertz.samast.domain.ContractDefinitionDto;
import in.hertz.samast.domain.Page;
import in.hertz.samast.domain.UtilityTraderGencoDTO;
import in.hertz.samast.domain.WSResp;
import in.hertz.samast.domain.exception.BusinessException;
import in.hertz.samast.service.ContractConfigurationService;
import in.hertz.samast.service.ExcelFileExporterService;


@CrossOrigin
@RestController
@RequestMapping("/contract-configuration")
public class ContractConfigurationController {
		
	@Autowired
	ContractConfigurationService configurationContractService;
	
	@Autowired
	ExcelFileExporterService excelFileExporterService;
	
	private static final Logger LOGGER = (Logger) LoggerFactory.getLogger(ContractConfigurationController.class);
	private static final String SUCCESS_MESSAGE = "Request processed successfully";
	private static final String DRAFT_SUCCESS_MESSAGE = "Draft saved successfully!";
	
	
	@PostMapping("/") 
	@ResponseBody
    public ResponseEntity<WSResp<T>> saveConfigurationContract (@Valid @RequestBody ContractDefinitionDto contractDefinitionDto) throws BusinessException, Exception { 
	  
	  boolean bool = configurationContractService.addConfigurationContract(contractDefinitionDto); 
	  return new ResponseEntity<>(new WSResp<>(null,bool,SUCCESS_MESSAGE),HttpStatus.OK);
    }
	 
	@PostMapping("/draft")
	public ResponseEntity<WSResp<T>> saveContractConfigurationAsDraft (@Valid @RequestBody ContractDefinitionDto contractDefinitionDto) throws BusinessException {
		
		contractDefinitionDto.setIssueDate(new Date());
		return new ResponseEntity<>(new WSResp<>(null, configurationContractService.saveAsDraft(contractDefinitionDto),
				DRAFT_SUCCESS_MESSAGE), HttpStatus.OK);
	}
	
	@GetMapping("/draft/{approvalNo}")
	public ResponseEntity<WSResp<ContractDefinitionDto>> getDraftByApprovalNumber(@PathVariable("approvalNo") String approvalNo) throws BusinessException, Exception {
		
       return new ResponseEntity<>(new WSResp<>(configurationContractService.getDraftContractConfiguration(approvalNo),true,SUCCESS_MESSAGE),HttpStatus.OK);
	}
	
	@GetMapping("/parameters")
	public ResponseEntity<WSResp<Page>> getContractConfigurationByParams(ContractConfigurationSearchDto contractConfigurationSearchDto,int pageNo, int pageSize) throws BusinessException, Exception {
		
		Page<List<ContractDefinitionDto>>page = configurationContractService.findAllPagedContractDefinitionByParams(contractConfigurationSearchDto, pageNo, pageSize);

		return new ResponseEntity<>(new WSResp<Page>(page,page!=null , SUCCESS_MESSAGE),HttpStatus.OK);
	}
	
	@GetMapping("/injecting-entities")
	public ResponseEntity<WSResp<List>> getInjectingExntities() {
		
		List<UtilityTraderGencoDTO> listUtilityTraderGencoDto = configurationContractService.getAllInjectingEntities();
	
		return new ResponseEntity<WSResp<List>>(new WSResp<>(listUtilityTraderGencoDto,listUtilityTraderGencoDto!=null , SUCCESS_MESSAGE),HttpStatus.OK);
	}
	
	@GetMapping(value = "/download/contractDefinitions.xlsx",produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
    public ResponseEntity<Resource> downloadCsv(HttpServletResponse response,ContractConfigurationSearchDto contractConfigurationSearchDto,int pageNo, int pageSize) throws BusinessException, Exception {
       
        List<ContractDefinitionDto> listContractDefinitionDto = configurationContractService.findAllContractDefinitionByParams(contractConfigurationSearchDto, 1, 10000);
        
        String filename="contractDefinitions.xlsx";   
        InputStreamResource file = new InputStreamResource(excelFileExporterService.contractConfigurationByParamtersListToExcelFile(listContractDefinitionDto));
        
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + filename)
                .contentType(MediaType.APPLICATION_OCTET_STREAM).body(file);
    }
	
	
	@GetMapping("/criteria")
	public ResponseEntity<WSResp<Map>> getContractConfigurationBySearchCriteria(@RequestParam String criteria,@RequestParam int pageNo,@RequestParam int pageSize) throws BusinessException, Exception {
		
	
		Map<String,Object> map = configurationContractService.getContractDefinationsBySearchCriteria(criteria,pageNo,pageSize);
		LOGGER.info("map ==" +map.toString());
		return new ResponseEntity<WSResp<Map>>(new WSResp<Map>(map,true , SUCCESS_MESSAGE),HttpStatus.OK);
	}
	
	@GetMapping("/all-contract-configuration")
	public ResponseEntity<WSResp<List>> getAllContractConfiguration() throws BusinessException, Exception {
		
		List<ContractDefinitionDto> listContractDefinationDtos = configurationContractService.viewAllContractConfigurationDto();
		
		return new ResponseEntity<WSResp<List>>(new WSResp<List>(listContractDefinationDtos,listContractDefinationDtos!=null , SUCCESS_MESSAGE),HttpStatus.OK);
	}
}
