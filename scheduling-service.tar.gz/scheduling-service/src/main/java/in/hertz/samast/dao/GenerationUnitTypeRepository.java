/**
 * 
 */
package in.hertz.samast.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import in.hertz.samast.entity.GenerationUnitType;

/**
 * @author Bibhuti Parida
 *
 */
@Repository
public interface GenerationUnitTypeRepository extends JpaRepository<GenerationUnitType, Integer> {

}
