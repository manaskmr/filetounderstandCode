package in.hertz.samast.ctrl;

import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Objects;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.hertz.samast.domain.CoalPositionBO;
import in.hertz.samast.domain.DraftDTO;
import in.hertz.samast.domain.WSResp;
import in.hertz.samast.domain.exception.BusinessException;
import in.hertz.samast.entity.Draft;
import in.hertz.samast.entity.TimeInterval;
import in.hertz.samast.service.CoalPositionService;
import in.hertz.samast.util.EPMDateUtils;

@RestController
@RequestMapping("/coal-position")
public class CoalPositionController {
		
	@Autowired
	private CoalPositionService coalPositionService;
	
	@GetMapping("/{utgId}/{sDate}")
	public ResponseEntity<WSResp<CoalPositionBO>> getCoalPositionByDate (@PathVariable("sDate") @DateTimeFormat(pattern="yyyy-MM-dd") Date sDate, @PathVariable("utgId") int utgId)  throws BusinessException, ParseException {	 															
		CoalPositionBO coalPositionBO = coalPositionService.getCoalPositionByDate(sDate, utgId);
		if(Objects.nonNull(coalPositionBO)) {
			return new ResponseEntity<WSResp<CoalPositionBO>>(new WSResp<CoalPositionBO>(coalPositionBO,true, "Request processed successfully"), HttpStatus.OK);
		} else {
			return new ResponseEntity<WSResp<CoalPositionBO>>(new WSResp<CoalPositionBO>(coalPositionBO,false, "Record could not be added"),HttpStatus.OK);
		}
	}
	
	@GetMapping("/newCoalPosition/{utgId}/{forDate}")
	public ResponseEntity<WSResp<CoalPositionBO>> newCoalPosition (@PathVariable("utgId") int utgId,
			@PathVariable("forDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date forDate) throws BusinessException, ParseException {	 
		CoalPositionBO coalPos = coalPositionService.newCoalPosition(forDate, utgId);
	  	if(Objects.nonNull(coalPos)) {
	  		return new ResponseEntity<WSResp<CoalPositionBO>>(new WSResp<CoalPositionBO>(coalPos,true,"Request processed successfully"),HttpStatus.OK);
	  	} else {
	  		return new ResponseEntity<WSResp<CoalPositionBO>>(new WSResp<CoalPositionBO>(coalPos,true, "Record could not be added"),HttpStatus.BAD_REQUEST);
	  	}
	}
	
	@PostMapping("/saveCoalPosition")
	public ResponseEntity<WSResp<CoalPositionBO>> saveCoalPosition (@RequestBody CoalPositionBO coalPositionBO) throws BusinessException, ParseException {	 
		CoalPositionBO coalPos = coalPositionService.saveCoalPosition(coalPositionBO);
	  	if(Objects.nonNull(coalPos)) {
	  		return new ResponseEntity<WSResp<CoalPositionBO>>(new WSResp<CoalPositionBO>(coalPos,true,"Request processed successfully"),HttpStatus.OK);
	  	} else {
	  		return new ResponseEntity<WSResp<CoalPositionBO>>(new WSResp<CoalPositionBO>(coalPos,true, "Record could not be added"),HttpStatus.BAD_REQUEST);
	  	}
	}
	
	@PutMapping("/update")
	public ResponseEntity<WSResp<CoalPositionBO>> updateCoalPosition(@RequestBody CoalPositionBO coalPositionBO) throws ParseException, BusinessException {	
		CoalPositionBO coalPos = coalPositionService.updateCoalPosition(coalPositionBO);
		if (Objects.nonNull(coalPos)) {
			return new ResponseEntity<WSResp<CoalPositionBO>>(new WSResp<CoalPositionBO>(coalPos,true,"Request processed successfully"),HttpStatus.OK);
		} else {
			return new ResponseEntity<WSResp<CoalPositionBO>>(new WSResp<CoalPositionBO>(coalPos,false,"CoalPosition with Id "  +coalPositionBO.getCoalPositionId() + " not found!"),HttpStatus.BAD_REQUEST);
		}
	}
	
	@GetMapping("/allcoalpositions")
	public ResponseEntity<WSResp<List<CoalPositionBO>>> getAllCoalPositionByDate() throws BusinessException {	
		List<CoalPositionBO> cooalPosList = coalPositionService.getAllCoalPositions();
		if (CollectionUtils.isNotEmpty(cooalPosList)) {
			return new ResponseEntity<WSResp<List<CoalPositionBO>>>(new WSResp<List<CoalPositionBO>>(cooalPosList,true, "Request processed successfully"),HttpStatus.OK);
		} else {
			return new ResponseEntity<WSResp<List<CoalPositionBO>>>(new WSResp<List<CoalPositionBO>>(cooalPosList,true, "Coal position data not found"),HttpStatus.OK);
		}
	}
		
	@GetMapping("/previousDay/{utgId}")
	public ResponseEntity<WSResp<CoalPositionBO>> getCoalPositionOfPreviousDay(
		@PathVariable("utgId") int utgId) throws BusinessException, ParseException {
		Date prevDate = EPMDateUtils.getPreviousDate();
		Calendar c = Calendar.getInstance();
		c.setTime(prevDate);
		c.add(Calendar.DATE, -1);
		prevDate = c.getTime();
		
		CoalPositionBO coalPositionBO = coalPositionService.getCoalPositionByDate(prevDate, utgId);
		
		if (Objects.nonNull(coalPositionBO)) {
			return new ResponseEntity<WSResp<CoalPositionBO>>(new WSResp<CoalPositionBO>(coalPositionBO,true, "Request processed successfully"),HttpStatus.OK);
		} else {
			return new ResponseEntity<WSResp<CoalPositionBO>>(new WSResp<CoalPositionBO>(coalPositionBO,false, "CoalPosition not found for Date"+prevDate),HttpStatus.OK);
		}
	}
	
	@PostMapping("/saveDraft")
	public ResponseEntity<WSResp<Draft<CoalPositionBO>>> saveCoalPositionAsDraft (@RequestBody DraftDTO<CoalPositionBO> draftDTO) throws BusinessException, ParseException {
		Draft<CoalPositionBO> coalDraft = coalPositionService.saveAsDraft(draftDTO);
		if (Objects.nonNull(coalDraft)) {
			return new ResponseEntity<WSResp<Draft<CoalPositionBO>>>(new WSResp<Draft<CoalPositionBO>>(coalDraft,true,"Request processed successfully"),HttpStatus.OK);
		} else {
			return new ResponseEntity<WSResp<Draft<CoalPositionBO>>>(new WSResp<Draft<CoalPositionBO>>(coalDraft,false,"Request not processed"),HttpStatus.BAD_REQUEST);
		}
	}
	
	@GetMapping("/draft/{utgId}/{sDate}")
	public ResponseEntity<WSResp<Draft<CoalPositionBO>>> getDraftedCoalPoistionByDate (
			@PathVariable("sDate") @DateTimeFormat(pattern="yyyy-MM-dd") Date sDate, @PathVariable("utgId") int utgId)
					throws BusinessException {
		Draft<CoalPositionBO> coalPosBO = coalPositionService.getDraftedCoalPositionByDateAndUtgId(sDate,utgId);
		if (Objects.nonNull(coalPosBO)) {
			return new ResponseEntity<WSResp<Draft<CoalPositionBO>>>(new WSResp<Draft<CoalPositionBO>>(coalPosBO,true,"Request processed successfully"),HttpStatus.OK);
		} else {
			return new ResponseEntity<WSResp<Draft<CoalPositionBO>>>(new WSResp<Draft<CoalPositionBO>>(coalPosBO,true,"Records not found"),HttpStatus.OK);
		}
	}
	
	@GetMapping("/findCurrentTimeBlock")
	public ResponseEntity<WSResp<TimeInterval>> getCurrentTimeBlock() throws Exception, BusinessException {
		TimeInterval timeBlock = coalPositionService.getCurrentTimeBlock();
		if (Objects.nonNull(timeBlock)) {
			return new ResponseEntity<WSResp<TimeInterval>>(
					new WSResp<TimeInterval>(timeBlock, true, "Time Block fetched Successfully!"), HttpStatus.OK);
		} else {
			return new ResponseEntity<WSResp<TimeInterval>>(
					new WSResp<TimeInterval>(timeBlock, false, "Error in fetching Time block Data!"),
					HttpStatus.BAD_REQUEST);
		}
	}
	
}