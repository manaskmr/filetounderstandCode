package in.hertz.samast.service;

import java.sql.SQLException;
import java.sql.Time;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.map.HashedMap;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.ss.usermodel.DateUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import in.hertz.samast.config.BusinessErrorPropertyConfig;
import in.hertz.samast.dao.DeclareCapacityDetailsRepository;
import in.hertz.samast.dao.DeclareCapacityRepository;
import in.hertz.samast.dao.DraftRepository;
import in.hertz.samast.dao.GenerationRepository;
import in.hertz.samast.dao.UtilitiesTraderGencoRepository;
import in.hertz.samast.domain.DraftDTO;
import in.hertz.samast.domain.ScheduleQuantumBaseDTO;
import in.hertz.samast.domain.ScheduleQuantumDTO;
import in.hertz.samast.domain.SldcApproveBo;
import in.hertz.samast.domain.exception.BusinessException;
import in.hertz.samast.entity.DeclareCapability;
import in.hertz.samast.entity.DeclareCapabilityDetails;
import in.hertz.samast.entity.Draft;
import in.hertz.samast.entity.Generation;
import in.hertz.samast.entity.InjectionScheduleSummary;
import in.hertz.samast.entity.TimeInterval;
import in.hertz.samast.entity.UtilitiesTraderGenco;


/**
 * @author Bibhuti Parida
 * 
 * This is service implementation class for declare capacity
 * Functionalities are Save Draft, Retrieve Draft, Save DC, Get Latest DC,
 * Initiate DC data and show all DC data
 *
 */
@Configuration
@Service(value = "declareCapacityService")
@Transactional
@ComponentScan(basePackages = "in.hertz.samast.config")
public class DeclareCapacityServiceImpl implements DeclareCapacityService {
	
	private static final Logger LOG = LogManager.getLogger(DeclareCapacityServiceImpl.class);
	
	private static final String SGS = "SGS";
	private static final String SGS_THERMAL = "SGS-THERMAL";
	private static final String SGS_HYDRO = "SGS-HYDRO";
	private static final String SGS_SOLAR = "SGS-SOLAR";
	private static final String ISGS = "ISGS";

	@Autowired
	private BusinessErrorPropertyConfig bepc;
	
	@Autowired
	private DeclareCapacityRepository declareCapacityRepository;

	@Autowired
	private UtilitiesTraderGencoRepository utilitiesTraderGencoRepository;
	
	@Autowired
	private DeclareCapacityDetailsRepository declareCapacityDetailsRepository;

	@Autowired
	private DraftRepository<ScheduleQuantumBaseDTO> draftRepository;
	
	@Autowired
	private TimeIntervalService timeIntervalService;
	
	@Autowired
	private ExBusCapacityService exBusCapacityService;
	
	@Autowired
	private GenerationRepository generationRepository;
	
	@Value("${time.block.limits}")
	private int timeBlockLimts;
	
	/**
	 * This method retrieve the latest declare capacity based on forDate and UtgId
	 */
	@Override
	public ScheduleQuantumBaseDTO getDeclaredCapacityByUTG(Date forDate, int utgId) throws Exception, BusinessException {
		LOG.info("Start DeclareCapacityServiceImpl:getDeclaredCapacityByUTG");
		ScheduleQuantumBaseDTO dto = null;
		int revisionNo = -1;
		Integer latestRevisionNo = declareCapacityRepository.getLatestRevisionNoByUTG(utgId, forDate);
		if (Objects.nonNull(latestRevisionNo)) {
			revisionNo = latestRevisionNo.intValue();
			
			List<DeclareCapability> dcList = declareCapacityRepository.getDeclaredCapacityLatestRevision(utgId, forDate, revisionNo);
			if (CollectionUtils.isNotEmpty(dcList)) {
				DeclareCapability dc = dcList.get(0);
				dto = convertDCToSchQuantumDTO(dc);
				Set<DeclareCapabilityDetails> capacityDetails = dc.getCapabilityDetails();
				if (CollectionUtils.isNotEmpty(capacityDetails)) {
					List<ScheduleQuantumDTO> bqDTOList = new ArrayList<>();
					for (DeclareCapabilityDetails dcDetail : capacityDetails) {
						ScheduleQuantumDTO bqDTO = convertDCDetailToQuantumDTO(dcDetail);
						bqDTOList.add(bqDTO);
					}

					dto.setQuantumList(sortQuantumList(bqDTOList));
				}
			}
		}
		LOG.info("End DeclareCapacityServiceImpl:getDeclaredCapacityByUTG");
		return dto;
	}

	/**
	 * This method retrieve the latest revision number based on forDate, UtgId
	 */
	@Override
	public Integer getLatestRevisionNoByUTG(Date forDate, int utgId) throws Exception, BusinessException {
		LOG.info("Start DeclareCapacityServiceImpl:getLatestRevisionNoByUTG");
		int revisionNo = -1;
		Integer latestRevisionNo = declareCapacityRepository.getLatestRevisionNoByUTG(utgId, forDate);
		if (Objects.nonNull(latestRevisionNo)) {
			revisionNo = latestRevisionNo.intValue();
		}
		LOG.info("End DeclareCapacityServiceImpl:getLatestRevisionNoByUTG");
		return revisionNo;
	}
	
	/**
	 * This method retrieve the latest declare capacity based on forDate, UtgId
	 * and revision number
	 */
	@Override
	public ScheduleQuantumBaseDTO getDeclaredCapacityByUTG(Date forDate, int utgId, int revisionNo) throws Exception, BusinessException {
		LOG.info("Start DeclareCapacityServiceImpl:getDeclaredCapacityByUTG");
		ScheduleQuantumBaseDTO dto = null;
			
		List<DeclareCapability> dcList = declareCapacityRepository.getDeclaredCapacityLatestRevision(utgId, forDate, revisionNo);
		if (CollectionUtils.isNotEmpty(dcList)) {
			DeclareCapability dc = dcList.get(0);
			dto = convertDCToSchQuantumDTO(dc);
			Set<DeclareCapabilityDetails> capacityDetails = dc.getCapabilityDetails();
			if (CollectionUtils.isNotEmpty(capacityDetails)) {
				List<ScheduleQuantumDTO> bqDTOList = new ArrayList<>();
				for (DeclareCapabilityDetails dcDetail : capacityDetails) {
					ScheduleQuantumDTO bqDTO = convertDCDetailToQuantumDTO(dcDetail);
					bqDTOList.add(bqDTO);
				}
				dto.setQuantumList(sortQuantumList(bqDTOList));
			}
		}
		LOG.info("End DeclareCapacityServiceImpl:getDeclaredCapacityByUTG");
		return dto;
	}
	/**
	 * This method retrieve the latest declare capacity based on forDate, UtgId
	 * @MK
	 */
	public ScheduleQuantumBaseDTO getDeclaredCapacityByUTGAndDate(Date forDate, int utgId)  {
		LOG.info("Start DeclareCapacityServiceImpl:getDeclaredCapacityByUTG");
		ScheduleQuantumBaseDTO dto = null;
			
		List<DeclareCapability> dcList = declareCapacityRepository.getDeclaredCapacityByUtgDate(forDate, utgId);
		if (CollectionUtils.isNotEmpty(dcList)) {
			DeclareCapability dc = dcList.get(0);
			dto = convertDCToSchQuantumDTO(dc);
			Set<DeclareCapabilityDetails> capacityDetails = dc.getCapabilityDetails();
			if (CollectionUtils.isNotEmpty(capacityDetails)) {
				List<ScheduleQuantumDTO> bqDTOList = new ArrayList<>();
				for (DeclareCapabilityDetails dcDetail : capacityDetails) {
					ScheduleQuantumDTO bqDTO = convertDCDetailToQuantumDTO(dcDetail);
					bqDTOList.add(bqDTO);
				}
				dto.setQuantumList(sortQuantumList(bqDTOList));
			}
		}
		LOG.info("End DeclareCapacityServiceImpl:getDeclaredCapacityByUTG");
		return dto;
	}
	
	public List<ScheduleQuantumBaseDTO> getDeclaredCapacityByUTGAndDate(Date fromDate, Date toDate, String format, int utgId){
		List<ScheduleQuantumBaseDTO> scheduleQuantumBaseDTOs = new ArrayList<>();
		Date currDate = fromDate;
		while (currDate.before(toDate) || currDate.equals(toDate)) {
			ScheduleQuantumBaseDTO quantumBaseDTO = getDeclaredCapacityByUTGAndDate(currDate, utgId);
			scheduleQuantumBaseDTOs.add(quantumBaseDTO);
			Calendar c = Calendar.getInstance(); 
			c.setTime(currDate); 
			c.add(Calendar.DATE, 1);
			currDate = c.getTime();
		}
		return scheduleQuantumBaseDTOs;
	}
	
	
	/**
	 * This method for sorting quantum list based on block number
	 * @param dcQuantumList
	 * @return
	 */
	private List<ScheduleQuantumDTO> sortQuantumList(List<ScheduleQuantumDTO> dcQuantumList) {
		if (CollectionUtils.isNotEmpty(dcQuantumList)) {
			Comparator<ScheduleQuantumDTO> timeBlockSorter = (a, b) -> a.getTimeBlock().compareTo(b.getTimeBlock());
			Collections.sort(dcQuantumList, timeBlockSorter);
		}
		return dcQuantumList;
	}
	
	/**
	 * This Method for saving DC data for scheduling DC
	 * checking existing of data based revision no, if exist then give the error
	 * Otherwise create new record on declare Capacity table increment 
	 * of one revision number for scheduling DC
	 */
	@Override
	public ScheduleQuantumBaseDTO saveDC(ScheduleQuantumBaseDTO ursBO) throws Exception, BusinessException {
		LOG.info("Start DeclareCapacityServiceImpl:saveDC");
		Integer utgId = ursBO.getSellerUTGId();
		Date forDate = ursBO.getForDate();
		Integer latestRevisionNo = declareCapacityRepository.getLatestRevisionNoByUTG(utgId, forDate);

		//Revision no validation
		if (Objects.isNull(ursBO.getRevision()))
		{
			throw new BusinessException(bepc.getDcrevnonotnull());
		} else {
			if (Objects.isNull(latestRevisionNo) && ursBO.getRevision().intValue() != -1) {
				throw new BusinessException(bepc.getDcrevnominusone());
			}
			if (Objects.nonNull(latestRevisionNo)) {
				if (ursBO.getRevision().intValue() <= latestRevisionNo.intValue()) {
					throw new BusinessException(bepc.getDcrevnonotleseq());
				} else if (ursBO.getRevision().intValue() > (latestRevisionNo.intValue()+1)) {
					throw new BusinessException(bepc.getDcrevlatbyone());
				}
			}			
		}
		
		//Date validation for intra day and day ahead
        DateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date dateForDate = sdf.parse(sdf.format(forDate));
        Date dateIssuesDate = sdf.parse(sdf.format(new Date()));
        Date currentDate = sdf.parse(sdf.format(new Date()));
		if (currentDate.compareTo(dateIssuesDate) != 0)
		{
			throw new BusinessException(bepc.getDcissuedate());
		}
		Calendar c = Calendar.getInstance(); 
		c.setTime(new Date()); 
		c.add(Calendar.DATE, 1);
		Date newIssuesDate = sdf.parse(sdf.format(c.getTime()));

        int resultIntraday = dateIssuesDate.compareTo(dateForDate);
        int resultDayAhead = newIssuesDate.compareTo(dateForDate);
        
        if (!(resultIntraday == 0 || resultDayAhead == 0)) {
        	throw new BusinessException(bepc.getDccurrfordate());
        } 
		
        
        //Validate time block with current time block
		List<ScheduleQuantumDTO> dcDetailBOs = sortQuantumList(ursBO.getQuantumList());
		
		DateFormat df = new SimpleDateFormat("HH:mm");
		long currentms = 0;
		currentms = df.parse(df.format(new Date())).getTime(); 
		Time t = new Time(currentms);
		int maxTimeBlock = timeIntervalService.findMaxBlock().intValue();
		Time fromTime = timeIntervalService.findByBlock((maxTimeBlock-timeBlockLimts)).getTimeInterval();
		Time toTime = timeIntervalService.findByBlock(maxTimeBlock).getTimeInterval();
		
		if (resultIntraday == 0 || (t.equals(fromTime) || (t.before(toTime) && t.after(fromTime)))) {
			TimeInterval currentTimeBlockNo = getCurrentTimeBlock();
			ScheduleQuantumBaseDTO existDC = getDeclaredCapacityByUTG(forDate, utgId);
			if (Objects.nonNull(existDC)) {
				List<ScheduleQuantumDTO> quantumList = sortQuantumList(existDC.getQuantumList());
				boolean quantumChangedflg = validateChangedQuantumonTimeBlock(quantumList, dcDetailBOs, (currentTimeBlockNo.getBlockNumber()+timeBlockLimts));
				if (quantumChangedflg) {
					String msg = bepc.getDcquantbegtmblk() + (currentTimeBlockNo.getBlockNumber()+timeBlockLimts);
					throw new BusinessException(msg);
				}
			} 
//			else {
//				boolean quantumChangedflg = validateChangedQuantumonTimeBlock(dcDetailBOs, (currentTimeBlockNo.getBlockNumber()+timeBlockValidate));
//				if (quantumChangedflg) {
//					String msg = "You can not change the quantum before time block " + (currentTimeBlockNo.getBlockNumber()+timeBlockValidate);
//					throw new BusinessException(msg);
//				}
//			}
		}
		
		//Validation for 96 time blocks
		if (!validateQuantumonTimeBlock(dcDetailBOs)) {
			throw new BusinessException("All "+ maxTimeBlock +" Blocks are required");
		}
		
		Set<DeclareCapabilityDetails> dcDetailList = new HashSet<>();
		DeclareCapability dc = new DeclareCapability();
		if (utilitiesTraderGencoRepository.findById(utgId).isPresent()) {
			UtilitiesTraderGenco utg = utilitiesTraderGencoRepository.findById(utgId).get();
			dc.setUtilitiesTraderGenco(utg);
		}

		dc.setForDate(forDate);
		dc.setIssueDate(new Date());
		dc.setDataSource(ursBO.getDataSource());
		dc.setRevision(ursBO.getRevision());
		dc.setRemarks(ursBO.getRemarks());
		dc.setApprovedDate(ursBO.getApprovedDate());
		
		for (ScheduleQuantumDTO bqDTO : dcDetailBOs) {
			DeclareCapabilityDetails dcDetail = new DeclareCapabilityDetails();
			dcDetail.setQuantumOffBar(bqDTO.getOffBarQuantum());
			dcDetail.setQuantumOnBar(bqDTO.getOnBarQuantum());
			dcDetail.setQuantumOfPower(bqDTO.getSellerDcQuantum());
			dcDetail.setTimeIntervalId(bqDTO.getTimeBlock());
			dcDetail.setDeclareCapability(dc);
			dcDetailList.add(dcDetail);
		}
		dc.setCapabilityDetails(dcDetailList);
		declareCapacityRepository.save(dc);
		declareCapacityDetailsRepository.saveAll(dcDetailList);
		
		//Update existing Draft data
		Draft<ScheduleQuantumBaseDTO> existDraft = fetchDraftData(forDate, utgId);
		if (Objects.nonNull(existDraft)) {
			existDraft.setStatus("COMPLETED");
			draftRepository.save(existDraft);
		}
		LOG.info("End DeclareCapacityServiceImpl:saveDC");
		return ursBO;
	}
	
	/**
	 * This Method validate quantum value whether quantum changed before time block
	 * @param existQuantumList
	 * @param dcDetailBOs
	 * @param currentTimeBlockNo
	 * @return
	 */
	private boolean validateChangedQuantumonTimeBlock(List<ScheduleQuantumDTO> existQuantumList, List<ScheduleQuantumDTO> dcDetailBOs, int currentTimeBlockNo) {
		boolean flg = false;
		if (CollectionUtils.isNotEmpty(existQuantumList) && CollectionUtils.isNotEmpty(dcDetailBOs)) {
			for (ScheduleQuantumDTO scheduleQuantumDTO : existQuantumList) {
				if (scheduleQuantumDTO.getTimeBlock() < currentTimeBlockNo) {
					for (ScheduleQuantumDTO scheduleQuantumDTO2 : dcDetailBOs) {
						if (scheduleQuantumDTO2.getTimeBlock().equals(scheduleQuantumDTO.getTimeBlock())) {
							if (!(scheduleQuantumDTO.getOffBarQuantum().equals(scheduleQuantumDTO2.getOffBarQuantum()) && scheduleQuantumDTO.getOnBarQuantum().equals(scheduleQuantumDTO2.getOnBarQuantum()))) {
								flg = true;
								break;
							}
						}
					}
					if (flg) {
						break;
					}
				}
			}
		}
		return flg;
	}
	
	/**
	 * This Method validate quantum block number whether quantum time block has 96 blocks or not
	 * @param dcDetailBOs
	 * @return
	 * @throws BusinessException 
	 * @throws Exception 
	 */
	private boolean validateQuantumonTimeBlock(List<ScheduleQuantumDTO> dcDetailBOs) throws Exception, BusinessException {
		boolean flg = false;
		List<TimeInterval> timeIntervals = timeIntervalService.findAllTimeIntervals();
		int maxTimeBlock = timeIntervalService.findMaxBlock().intValue();
		Comparator<TimeInterval> timeBlockSorter = (a, b) -> new Integer(a.getBlockNumber()).compareTo(new Integer(b.getBlockNumber()));
		Collections.sort(timeIntervals, timeBlockSorter);
		
		if (CollectionUtils.isNotEmpty(dcDetailBOs)) {
			for (TimeInterval timeIntervalDTO : timeIntervals) {
				for (ScheduleQuantumDTO scheduleQuantumDTO : dcDetailBOs) {
					if (scheduleQuantumDTO.getTimeBlock().equals(new Integer(timeIntervalDTO.getBlockNumber()))) {
						flg = true;
						break;
					}
				}
				if (flg && timeIntervalDTO.getBlockNumber() != maxTimeBlock) {
					flg =false;
					continue;
				} else {
					break;
				}
			}
		}
		return flg;
	}
	
	/**
	 * This Method validate quantum value whether quantum blank/zero before time block
	 * @param dcDetailBOs
	 * @param currentTimeBlockNo
	 * @return
	 */
	private boolean validateChangedQuantumonTimeBlock(List<ScheduleQuantumDTO> dcDetailBOs, int currentTimeBlockNo) {
		boolean flg = false;
		for (ScheduleQuantumDTO scheduleQuantumDTO : dcDetailBOs) {
			if (scheduleQuantumDTO.getTimeBlock() < currentTimeBlockNo) {
				if (Objects.nonNull(scheduleQuantumDTO.getOffBarQuantum()) && scheduleQuantumDTO.getOffBarQuantum().intValue() !=0) {
					flg = true;
					break;
				}
			}
		}
		return flg;
	}
	
	/**
	 * This method returns the current time block number
	 * @return
	 * @throws ParseException
	 */
	@Override
	public TimeInterval getCurrentTimeBlock()  throws Exception, BusinessException {
		return timeIntervalService.getCurrentTimeBlock();
	}
	
	/**
	 * This Method for saving draft data for scheduling DC
	 * checking existing of data, if exist then update existing Draft
	 * Otherwise create new record on Draft table for scheduling DC
	 */
	@Override
	public Draft<ScheduleQuantumBaseDTO> saveDraft(DraftDTO<ScheduleQuantumBaseDTO> draftDTO)  throws Exception, BusinessException {
		LOG.info("Start DeclareCapacityServiceImpl:saveDraft");
		Draft<ScheduleQuantumBaseDTO> draft = new Draft<>();
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
				
		//Date validation for intra day and day ahead
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        Date dateForDate = df.parse(df.format(draftDTO.getJsonDTO().getForDate()));
        Date dateIssuesDate = sdf.parse(sdf.format(new Date()));
        
		Calendar c = Calendar.getInstance(); 
		c.setTime(dateIssuesDate); 
		c.add(Calendar.DATE, 1);
		Date newIssuesDate = df.parse(df.format(c.getTime()));

        Date currentDate = sdf.parse(sdf.format(new Date()));
		if (currentDate.compareTo(dateIssuesDate) != 0)
		{
			throw new BusinessException(bepc.getDcissuedate());
		}
		
        int resultIntraday = dateIssuesDate.compareTo(dateForDate);
        int resultDayAhead = newIssuesDate.compareTo(dateForDate);

        if (!(resultIntraday == 0 || resultDayAhead == 0)) {
        	throw new BusinessException(bepc.getDccurrfordate());
        } 
		
        //Validate time block with current time block
		List<ScheduleQuantumDTO> dcDetailBOs = sortQuantumList(draftDTO.getJsonDTO().getQuantumList());
		DateFormat dfTime = new SimpleDateFormat("HH:mm");
		long currentms = 0;
		currentms = dfTime.parse(dfTime.format(new Date())).getTime(); 
		Time t = new Time(currentms);
		int maxTimeBlock = timeIntervalService.findMaxBlock().intValue();
		Time fromTime = timeIntervalService.findByBlock((maxTimeBlock-timeBlockLimts)).getTimeInterval();
		Time toTime = timeIntervalService.findByBlock(maxTimeBlock).getTimeInterval();
		
		if (resultIntraday == 0 || (t.equals(fromTime) || (t.before(toTime) && t.after(fromTime)))) {
			TimeInterval currentTimeBlockNo = getCurrentTimeBlock();
			Draft<ScheduleQuantumBaseDTO> existDraft = fetchDraftData(dateForDate, draftDTO.getJsonDTO().getSellerUTGId());
			if (Objects.nonNull(existDraft)) {
				List<ScheduleQuantumDTO> quantumList = sortQuantumList(existDraft.getData().getQuantumList());
				boolean quantumChangedflg = validateChangedQuantumonTimeBlock(quantumList, dcDetailBOs, (currentTimeBlockNo.getBlockNumber()+timeBlockLimts));
				if (quantumChangedflg) {
					String msg = bepc.getDcquantbegtmblk() + (currentTimeBlockNo.getBlockNumber()+timeBlockLimts);
					throw new BusinessException(msg);
				}
			} 
//			else {
//				boolean quantumChangedflg = validateChangedQuantumonTimeBlock(dcDetailBOs, (currentTimeBlockNo.getBlockNumber()+timeBlockValidate));
//				if (quantumChangedflg) {
//					String msg = "You can not change the quantum before time block " + (currentTimeBlockNo.getBlockNumber()+timeBlockValidate);
//					throw new BusinessException(msg);
//				}
//			}
		}
		
		//Validation for 96 time blocks
		if (!validateQuantumonTimeBlock(dcDetailBOs)) {
			throw new BusinessException("All "+ maxTimeBlock +" Blocks are required");
		}
		
		Draft<ScheduleQuantumBaseDTO> existDraft = fetchDraftData(draftDTO.getJsonDTO().getForDate(), draftDTO.getJsonDTO().getSellerUTGId());
		if (Objects.nonNull(existDraft)) {
			existDraft.setCreatedBy(draftDTO.getCreatedBy());
			existDraft.setInsertTime(new Date());
			existDraft.setCurrentStage(draftDTO.getCurrentStage());
			existDraft.setStatus(draftDTO.getStatus());
			existDraft.setFunctionalityArea(draftDTO.getFunctionalityArea());
			if (Objects.nonNull(draftDTO.getJsonDTO())) {
				existDraft.setData(draftDTO.getJsonDTO());
			}
			draftRepository.save(existDraft);
			LOG.info("End DeclareCapacityServiceImpl:saveDraft existing Draft");
			return existDraft;
		} else {
			if (Objects.nonNull(draftDTO)) {
				draft.setCreatedBy(draftDTO.getCreatedBy());
				draft.setInsertTime(new Date());
				draft.setCurrentStage(draftDTO.getCurrentStage());
				draft.setStatus(draftDTO.getStatus());
				draft.setFunctionalityArea(draftDTO.getFunctionalityArea());
				if (draftDTO.getJsonDTO() != null) {
					draft.setData(draftDTO.getJsonDTO());
				}
				draftRepository.save(draft);
			}
			return draft;
		}
	}

	/**
	 * This method for fetching Scheduling Draft DC data based on UTGID and forDate
	 */
	@Override
	public Draft<ScheduleQuantumBaseDTO> fetchDraftData(Date forDate, int utgId) throws Exception, BusinessException {
		LOG.info("Start DeclareCapacityServiceImpl:fetchDraftData");
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String strForDate = sdf.format(forDate);
		
		//Date validation for intra day and day ahead
        Date dateForDate = sdf.parse(sdf.format(forDate));
        Date dateIssuesDate = sdf.parse(sdf.format(new Date()));
        
        Date currentDate = sdf.parse(sdf.format(new Date()));
		if (currentDate.compareTo(dateIssuesDate) != 0)
		{
			throw new BusinessException(bepc.getDcissuedate());
		}
		
		Calendar c = Calendar.getInstance(); 
		c.setTime(dateIssuesDate); 
		c.add(Calendar.DATE, 1);
		Date newIssuesDate = sdf.parse(sdf.format(c.getTime()));

        int resultIntraday = dateIssuesDate.compareTo(dateForDate);
        int resultDayAhead = newIssuesDate.compareTo(dateForDate);
        
        if (!(resultIntraday == 0 || resultDayAhead == 0)) {
        	throw new BusinessException(bepc.getDccurrfordate());
        } 
        
		List<Draft<ScheduleQuantumBaseDTO>> draftList =  draftRepository.findDraftByName(utgId, strForDate);
		ObjectMapper mapper = new ObjectMapper();
		List<Draft<ScheduleQuantumBaseDTO>> pojoDraftList = mapper.convertValue(
				draftList,
			    new TypeReference<List<Draft<ScheduleQuantumBaseDTO>>>() { });
		
		
		LOG.info("Start DeclareCapacityServiceImpl:fetchDraftData");
		return (CollectionUtils.isNotEmpty(pojoDraftList)) ? pojoDraftList.get(0) : null ;
	}
	
	/**
	 * This method is for initiate the add declare capacity screen
	 * If the is draft value, then it will show that
	 * Otherwise show the add declare capacity page with time interval only.
	 */
	@Override
	public ScheduleQuantumBaseDTO newDeclareCapacity(Date forDate, int utgId) throws Exception, BusinessException {
		LOG.info("Start DeclareCapacityServiceImpl:newDeclareCapacity");
		ScheduleQuantumBaseDTO declareCapacityBO = new ScheduleQuantumBaseDTO();
//		Draft<ScheduleQuantumBaseDTO> draft =  fetchDraftData(forDate, utgId);
		Integer latestRevisionNo = declareCapacityRepository.getLatestRevisionNoByUTG(utgId, forDate);
//		if (Objects.nonNull(draft)) {
//			ScheduleQuantumBaseDTO draftDTO = draft.getData();
//			if (Objects.isNull(latestRevisionNo))
//			{
//				draftDTO.setRevision(-1);
//			} else {
//				draftDTO = getDeclaredCapacityByUTG(forDate, utgId);
//				draftDTO.setRevision(latestRevisionNo+1);
//			}
//			return draftDTO;
//		} else {
			if (Objects.isNull(latestRevisionNo))
			{
			//	declareCapacityBO.setRevision(-1);
				List<ScheduleQuantumDTO> quantumList = new ArrayList<ScheduleQuantumDTO>();
				List<TimeInterval> timeIntervals = timeIntervalService.findAllTimeIntervals();
				for (TimeInterval timeInterval : timeIntervals) {
					ScheduleQuantumDTO scheduleQuantumDTO = new ScheduleQuantumDTO();
					scheduleQuantumDTO.setTimeBlock(timeInterval.getBlockNumber());
					scheduleQuantumDTO.setTime((timeInterval.getTimeInterval() + " - " + timeInterval.getToTime()));
					quantumList.add(scheduleQuantumDTO);
				}
				declareCapacityBO.setQuantumList(sortQuantumList(quantumList));
			} else {
				declareCapacityBO = getDeclaredCapacityByUTG(forDate, utgId);
				
			//	declareCapacityBO.setRevision(latestRevisionNo+1);
			}
//		}
		LOG.info("End DeclareCapacityServiceImpl:newDeclareCapacity");
		return declareCapacityBO;
	}
	
	/**
	 * This method is for showing all declare capacity for report purpose
	 */
	@Override
	public List<ScheduleQuantumBaseDTO> getAllDeclaredCapacity() throws Exception, BusinessException {
		LOG.info("Start DeclareCapacityServiceImpl:getAllDeclaredCapacity");
		List<DeclareCapability> dcList=  declareCapacityRepository.findAll();
		ScheduleQuantumBaseDTO dto = null;
		List<ScheduleQuantumBaseDTO> scheduleQuantumBaseList= new ArrayList<ScheduleQuantumBaseDTO>();
		if (CollectionUtils.isNotEmpty(dcList)) {
			for (DeclareCapability dc : dcList) {
				dto = convertDCToSchQuantumDTO(dc);
				Set<DeclareCapabilityDetails> capacityDetails = dc.getCapabilityDetails();
				if (CollectionUtils.isNotEmpty(capacityDetails)) {
					List<ScheduleQuantumDTO> bqDTOList = new ArrayList<>();
					for (DeclareCapabilityDetails dcDetail: capacityDetails) {
						ScheduleQuantumDTO bqDTO = convertDCDetailToQuantumDTO(dcDetail);
						bqDTOList.add(bqDTO);
					}
					
					dto.setQuantumList(sortQuantumList(bqDTOList));
				}
				scheduleQuantumBaseList.add(dto);
			}
		}
		LOG.info("End DeclareCapacityServiceImpl:getAllDeclaredCapacity");
		return scheduleQuantumBaseList;
		
	}
	
	/**
	 * This Method for converting DC entity to DTO
	 * @param dc
	 * @return
	 */
	private ScheduleQuantumBaseDTO convertDCToSchQuantumDTO(DeclareCapability dc ) {
		ScheduleQuantumBaseDTO dto = new ScheduleQuantumBaseDTO();
		dto.setForDate(dc.getForDate());
		dto.setIssueDate(dc.getIssueDate());
		dto.setSellerUTGId(dc.getUtilitiesTraderGenco().getUID());
		dto.setSellerEntity(dc.getUtilitiesTraderGenco().getName());
		dto.setRevision(dc.getRevision());
		dto.setApprovedDate(dc.getApprovedDate());
		return dto;
	}
	
	/**
	 * This Method for converting DC details to DTO 
	 * @param dcDetail
	 * @return
	 */
	private ScheduleQuantumDTO convertDCDetailToQuantumDTO(DeclareCapabilityDetails dcDetail) {
		ScheduleQuantumDTO bqDTO = new ScheduleQuantumDTO();
		bqDTO.setSellerDcQuantum(dcDetail.getQuantumOfPower());
		bqDTO.setOffBarQuantum(dcDetail.getQuantumOffBar());
		bqDTO.setOnBarQuantum(dcDetail.getQuantumOnBar());
		bqDTO.setTimeBlock(dcDetail.getTimeIntervalId());
		return bqDTO;
	}
	
	/**
	 * This method is giving all revision numbers for generator for a particular date
	 */
	@Override
	public List<Integer> getAllRevisionNo(Date forDate, int utgId) throws Exception, BusinessException {
		LOG.info("Start DeclareCapacityServiceImpl:getAllRevisionNo");
		List<Integer> revisionList = new ArrayList<Integer>();

		List<DeclareCapability> dcList = declareCapacityRepository.getDeclaredCapacityByUTG(utgId, forDate);
		if (CollectionUtils.isNotEmpty(dcList)) {
			for (DeclareCapability declareCapability : dcList) {
				revisionList.add(declareCapability.getRevision());
			}
		}
		LOG.info("End DeclareCapacityServiceImpl:getAllRevisionNo");
		return revisionList;
	}
	
	/**
	 * This method is giving all revision numbers for generator for a particular date and DC type
	 */
	@Override
	public List<Integer> getRevisionNoByDCType(Date forDate, int utgId, String dcType) throws Exception, BusinessException {
		LOG.info("Start DeclareCapacityServiceImpl:getRevisionNoByDCType");
		List<Integer> revisionList = new ArrayList<Integer>();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String strForDate = sdf.format(forDate);

		List<DeclareCapability> dcList = declareCapacityRepository.getDeclaredCapacityByUTG(utgId, forDate);
		if (CollectionUtils.isNotEmpty(dcList)) {
			for (DeclareCapability declareCapability : dcList) {
				String strIssueDate = sdf.format(declareCapability.getIssueDate());
				
				Date newIssuesDate = sdf.parse(sdf.format(declareCapability.getIssueDate()));
				
				Calendar c = Calendar.getInstance(); 
				c.setTime(newIssuesDate); 
				c.add(Calendar.DATE, 1);
				String newStrIssuesDate = sdf.format(c.getTime());
				
				if (dcType.equalsIgnoreCase("IntraDay") && strForDate.equals(strIssueDate)) {
					revisionList.add(declareCapability.getRevision());
				} else if (dcType.equalsIgnoreCase("DayAhead") && strForDate.equals(newStrIssuesDate)) {
					revisionList.add(declareCapability.getRevision());
				}
			}
		}
		LOG.info("End DeclareCapacityServiceImpl:getRevisionNoByDCType");
		return revisionList;
	}
	
	/**
	 * This Method providing Ex Bus Capacity for a particular Generator
	 */
	@Override
	public Integer getExBusCapacity(int utgId) throws Exception, BusinessException {
		return exBusCapacityService.getExBusCapacity(utgId);
	}
	
	
	@Override
	public List<ScheduleQuantumBaseDTO> getAllGenerators(SldcApproveBo sldcApproveBo)
			throws Exception, BusinessException {
		List<ScheduleQuantumBaseDTO> scheduleQuantumBaseList = new ArrayList<>();
		List<String> shortName = sldcApproveBo.getGenerationTypeShortName();
		List<String> sourceName = sldcApproveBo.getSourceName();
		List<Generation> generationList = generationRepository.getIdByShortName(shortName, sourceName);
		if (CollectionUtils.isNotEmpty(generationList)) {
			for (Generation gen : generationList) {
				ScheduleQuantumBaseDTO dto = getDeclaredCapacityByUTG(sldcApproveBo.getDate(),
						gen.getUtilitiesTraderGenco().getUID());
				if (Objects.nonNull(dto)) {
					UtilitiesTraderGenco name = utilitiesTraderGencoRepository.getById(gen.getUtilitiesTraderGenco().getUID());
					dto.setSellerEntity(name.getName());
					dto.setQuantumList(null);
					scheduleQuantumBaseList.add(dto);
				}
			}
		}

		return scheduleQuantumBaseList;
	}

	@Override
	public List<ScheduleQuantumBaseDTO> viewDcByGenerators(SldcApproveBo sldcApproveBo)
			throws Exception, BusinessException {
		List<ScheduleQuantumBaseDTO> scheduleQuantumBaseList = new ArrayList<>();
		List<String> shortName = sldcApproveBo.getGenerationTypeShortName();
		List<String> sourceName = sldcApproveBo.getSourceName();
		int revisionNo;
		int previousRevisionNo;
		List<Generation> generationList = generationRepository.getIdByShortName(shortName, sourceName);
		if (CollectionUtils.isNotEmpty(generationList)) {
			for (Generation gen : generationList) {
				if (sldcApproveBo.getRevisionNo() != null) {
					revisionNo = sldcApproveBo.getRevisionNo();
				} else {
					revisionNo = getLatestRevisionNoByUTG(sldcApproveBo.getDate(), gen.getUtilitiesTraderGenco().getUID());
				}
				previousRevisionNo = revisionNo - 1;
				ScheduleQuantumBaseDTO revisionNoDto =
						getDeclaredCapacityByUTG(sldcApproveBo.getDate(), gen.getUtilitiesTraderGenco().getUID(), revisionNo);
				revisionNoDto.setStatus("latest");
				if (Objects.nonNull(revisionNoDto)) {
					scheduleQuantumBaseList.add(revisionNoDto);
				}
				ScheduleQuantumBaseDTO previousRevisionNoDto = 
						getDeclaredCapacityByUTG(sldcApproveBo.getDate(), gen.getUtilitiesTraderGenco().getUID(), previousRevisionNo);
				if (Objects.nonNull(previousRevisionNoDto)) {
					scheduleQuantumBaseList.add(previousRevisionNoDto);
				}
			}
		}
		return scheduleQuantumBaseList.stream().sorted(Comparator.comparing(ScheduleQuantumBaseDTO::getSellerEntity)
				.thenComparing(ScheduleQuantumBaseDTO::getRevision)).collect(Collectors.toList());
	}

	@Override
	public ScheduleQuantumBaseDTO editDcBySldc(SldcApproveBo sldcApproveBo) throws Exception, BusinessException {
		return getDeclaredCapacityByUTG(sldcApproveBo.getDate(), sldcApproveBo.getUtgId(),
				sldcApproveBo.getRevisionNo());
	}
	
	@Override
	public String getScheduletype(int utgId, Date forDate, int revisionNo) throws Exception, BusinessException {
		String scheduleType = null;
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		List<DeclareCapability> dcList = declareCapacityRepository.getDeclaredCapacityLatestRevision(utgId, forDate, revisionNo);
		if (CollectionUtils.isNotEmpty(dcList)) {
			DeclareCapability is = dcList.get(0);
			String strIssueDate = sdf.format(is.getIssueDate());
			Date newIssuesDate = sdf.parse(sdf.format(is.getIssueDate()));
			
			Calendar c = Calendar.getInstance(); 
			c.setTime(newIssuesDate); 
			c.add(Calendar.DATE, 1);
			String newStrIssuesDate = sdf.format(c.getTime());
			
			String strForDate = sdf.format(forDate);
			
			if (strForDate.equals(strIssueDate)) {
				scheduleType = "IntraDay";
			} else if (strForDate.equals(newStrIssuesDate)) {
				scheduleType = "DayAhead";
			}
		}
		return scheduleType;
	}
	// Finding DC Report
	public boolean isValid(DeclareCapability declareCapability, String sellerType) throws Exception {
		String[] strs = sellerType.split("-");
		String generationType = strs[0];
		String energySource = (strs.length == 2) ? strs[1] : null;
		if (generationType.equals(ISGS))
			return isValidByGenerationType(declareCapability, generationType);
		return isValidByGenerationType(declareCapability, generationType) && isValidByEnergySource(declareCapability, energySource);
	}
	
	public boolean isValidByGenerationType(DeclareCapability declareCapability, String generationType) throws Exception {
		UtilitiesTraderGenco utg = declareCapability.getUtilitiesTraderGenco();
		Generation generation = generationRepository.findByUtg(utg);
		return generation.getGenerationTypeDetail().getGenerationTypeShortName().equals(generationType);
	}
	
	public boolean isValidByEnergySource(DeclareCapability declareCapability, String energySource) throws Exception {
		UtilitiesTraderGenco utg =  declareCapability.getUtilitiesTraderGenco();
		Generation generation = generationRepository.findByUtg(utg);
		return generation.getEnergySourceDetail().getSourceName().equals(energySource);
		
	}

	@Override
	public List<ScheduleQuantumBaseDTO> findAllDCReport(String sellerType, Date forDate, int revisionNo) throws Exception {
		List<DeclareCapability> declareCapabilities = declareCapacityRepository.getDeclareCapability(forDate, revisionNo);
		List<ScheduleQuantumBaseDTO> scheduleQuantumBaseDTOs = new ArrayList<>();
		
		for (DeclareCapability declareCapability: declareCapabilities)
			if (isValid(declareCapability, sellerType))
				scheduleQuantumBaseDTOs.add(transform(declareCapability));
		
		return scheduleQuantumBaseDTOs;
	}
	
	private ScheduleQuantumBaseDTO transform(DeclareCapability declareCapability) throws Exception{
		ScheduleQuantumBaseDTO scheduleQuantumBaseDTO = new ScheduleQuantumBaseDTO();
		List<ScheduleQuantumDTO> scheduleQuantumDTO = new ArrayList<>();
		
		for (DeclareCapabilityDetails declareCapabilityDetail: declareCapability.getCapabilityDetails()) {
			ScheduleQuantumDTO quantumDTO = new ScheduleQuantumDTO();
			quantumDTO.setTimeBlock(declareCapabilityDetail.getTimeIntervalId());
			quantumDTO.setQuantum(declareCapabilityDetail.getQuantumOfPower());
			scheduleQuantumDTO.add(quantumDTO);
		}
		
		Collections.sort(scheduleQuantumDTO, Comparator.comparing(ScheduleQuantumDTO::getTimeBlock));
		
		scheduleQuantumBaseDTO.setSellerEntity(declareCapability.getUtilitiesTraderGenco().getAliasName());
		scheduleQuantumBaseDTO.setSellerUTGId(declareCapability.getUtilitiesTraderGenco().getUID());
		scheduleQuantumBaseDTO.setQuantumList(scheduleQuantumDTO);
		
		return scheduleQuantumBaseDTO;
	}

	// fetching DC report on the basis of Seller UtgId
	@Override
	public ScheduleQuantumBaseDTO findDCReportBySeller(Date forDate, int revisionNo, int gencoUtgId) throws Exception {
		DeclareCapability declareCapability = declareCapacityRepository.getDeclaredCapacityByRevision(gencoUtgId, forDate, revisionNo);
		return transform(declareCapability);
	}
	
	//fetching DC report on the basis of custom date by DayWise
	public Map<Date, Map<String, Double>> findCustomDCReportByDayWise(Date fromDate, Date toDate) throws Exception {
		List<DeclareCapability> declareCapabilities = declareCapacityRepository.getDeclareCapacityByDateRange(fromDate, toDate);
		Map<Date, Map<String, Double>> dcMap = new HashMap<>();
		for (DeclareCapability declareCapability : declareCapabilities) {
			Set<DeclareCapabilityDetails> capabilityDetails = declareCapability.getCapabilityDetails();
			double quantumSum = 0.0;
			for(DeclareCapabilityDetails capabilityDetail : declareCapability.getCapabilityDetails())
				quantumSum += capabilityDetail.getQuantumOfPower();
			Map<String, Double> map = dcMap.get(declareCapability.getForDate());
			if (map == null) map = new HashMap<>();
			map.put(declareCapability.getUtilitiesTraderGenco().getName(), quantumSum);
			dcMap.put(declareCapability.getForDate(), map);
		}
		return dcMap;
	}
	//fetching DC report on the basis of custom date by BlockWise
	public Map<Date, Map<String, Double>> findCustomDCReportByBlockWise(Date fromDate, Date toDate) throws Exception{
		List<DeclareCapability> declareCapabilities = declareCapacityRepository.getDeclareCapacityByDateRange(fromDate, toDate);
		Map<Date, Map<String, Double>> dcMap = new HashMap<>();
		for (DeclareCapability declareCapability : declareCapabilities) {
			Set<DeclareCapabilityDetails> capabilityDetails = declareCapability.getCapabilityDetails();
			double quantumSum = 0.0;
			for(DeclareCapabilityDetails capabilityDetail : declareCapability.getCapabilityDetails()) {
				quantumSum += capabilityDetail.getQuantumOfPower();
			}
			Map<String, Double> map = dcMap.get(declareCapability.getForDate());
			map.put(declareCapability.getUtilitiesTraderGenco().getAliasName(), quantumSum);
			dcMap.put(declareCapability.getForDate(), map);
		}
		return dcMap;
	}
	
	// fetching Dc report for Custom Date Range 
		public Map<Date, Map<String, Double>> findCustomDCReport(String sellerType, Date fromDate, Date toDate, String format) throws Exception {
			if(format.equals("DayWise")) {
				return findCustomDCReportByDayWise(fromDate, toDate);
			}else {
				return  findCustomDCReportByBlockWise(toDate, toDate);
			}
			
		}
}