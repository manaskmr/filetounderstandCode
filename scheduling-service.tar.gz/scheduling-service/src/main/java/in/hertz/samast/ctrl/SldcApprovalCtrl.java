package in.hertz.samast.ctrl;

import java.util.List;
import java.util.Objects;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.hertz.samast.domain.InjectionScheduleBO;
import in.hertz.samast.domain.ScheduleQuantumBaseDTO;
import in.hertz.samast.domain.SldcApproveBo;
import in.hertz.samast.domain.WSResp;
import in.hertz.samast.domain.exception.BusinessException;
import in.hertz.samast.service.SldcApprovalService;

@RestController
@RequestMapping("/sldc_approve")
public class SldcApprovalCtrl {

	@Autowired
	private SldcApprovalService sldcApprovalService;
	
	@Value("${approved}")
	private String approved;
	
	@Value("${not.approve}")
	private String notApprove;
	
	@Value("${rejected}")
	private String rejected;
	
	@Value("${not.reject}")
	private String notReject;

	@PostMapping("/generators/approveDc")
	public WSResp<ScheduleQuantumBaseDTO> approveDcBySldc(
			@RequestBody ScheduleQuantumBaseDTO scheduleQuantumBaseDTO) throws Exception, BusinessException {
		boolean success = sldcApprovalService.approveDcBySldc(scheduleQuantumBaseDTO);

		if (success)
			return new WSResp<>(null, true, approved );
		else return new WSResp<>(null, false, notApprove);		

	}
	
	@PostMapping("/generators/rejectDc")
	public WSResp<ScheduleQuantumBaseDTO> rejectDcBySldc(
			@RequestBody ScheduleQuantumBaseDTO scheduleQuantumBaseDTO) throws Exception, BusinessException {
		ScheduleQuantumBaseDTO dc = sldcApprovalService.rejectDcBySldc(scheduleQuantumBaseDTO);
		if (Objects.nonNull(dc)) 
			return new WSResp<>(dc, true, rejected );
		else return new WSResp<>(dc, false, notReject );
			
	}
	
	@PostMapping("/sldcApproveInjectionSchedule")
	public WSResp<InjectionScheduleBO> sldcApproveInjectionSchedule(
			@RequestBody InjectionScheduleBO injectionScheduleBO) throws Exception, BusinessException {
		boolean success = sldcApprovalService.sldcApproveInjectionSchedule(injectionScheduleBO);

		if (success)
			return new WSResp<>(null, true, approved );
		else return new WSResp<>(null, false, notApprove );		

	}
	
	@PostMapping("/sldcRejectInjectionSchedule")
	public WSResp<InjectionScheduleBO> sldcRejectInjectionSchedule(
			@RequestBody InjectionScheduleBO injectionScheduleBO) throws Exception, BusinessException {
		InjectionScheduleBO re = sldcApprovalService.sldcRejectInjectionSchedule(injectionScheduleBO);
		if (Objects.nonNull(re)) 
			return new WSResp<>(re, true, rejected );
		else return new WSResp<>(re, false, notReject );
	}
}
