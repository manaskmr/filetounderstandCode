/**
 * 
 */
package in.hertz.samast.service;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import in.hertz.samast.dao.TimeIntervalRepository;
import in.hertz.samast.dao.UtilitiesTraderGencoRepository;
import in.hertz.samast.dao.UtilityShareDetailsRepository;
import in.hertz.samast.dao.UtilityShareRepository;
import in.hertz.samast.domain.BlockRangeQuantumsDTO;
import in.hertz.samast.domain.UtilityShareBO;
import in.hertz.samast.domain.exception.BusinessException;
import in.hertz.samast.entity.UtilitiesTraderGenco;
import in.hertz.samast.entity.UtilityShare;
import in.hertz.samast.entity.UtilityShareDetails;
import in.hertz.samast.util.UtilityShareType.ShareType;

/**
 * @author vikas
 *
 */
@Service
@Transactional
public class UtilityShareServiceImpl implements UtilityShareService {

	@Autowired
	private UtilitiesTraderGencoRepository utgDAO;

	@Autowired
	private UtilityShareRepository utilityShareDAO;

	@Autowired
	private TimeIntervalRepository timeIntervalDAO;
	
	@Autowired
	private UtilityShareDetailsRepository utilityShareDetailDAO;

	public static final String DISCOM_UTGS = "DISCOM_UTGS";
	public static final String PPC_UTGS = "PPC_UTGS";
	public static final String SHARE = "SHARE";
	public static final String UTG_TYPE = "UTG_TYPE";

	@Override
	public void addUtilityShare(List<UtilityShareBO> boList) throws BusinessException, Exception {
		boolean exists = false;
		StringBuilder msg = new StringBuilder();
		msg.append("Data Aleady exits for these : ");

		for (UtilityShareBO bo : boList) {
			Integer beneficiaryUtgId = bo.getDraweeUtgId();
			Integer utilityUtgId = bo.getInjectorUtgId();
			String type = bo.getType();
			Date fromDate = bo.getFromDate();
			Date toDate = bo.getToDate();
			List<BlockRangeQuantumsDTO> detailsDTO = bo.getDetails();

			UtilitiesTraderGenco beneficiaryUTG = utgDAO.getById(beneficiaryUtgId);
			UtilitiesTraderGenco utilityUTG = utgDAO.getById(utilityUtgId);

			ShareType shareType = ShareType.valueOf(type);
			List<UtilityShare> existShare = utilityShareDAO.findSharedForDateRange(beneficiaryUtgId, utilityUtgId,
					fromDate, toDate, shareType);
			if (existShare != null && !existShare.isEmpty()) {
				msg.append(utilityUTG.getName() + ", ");
				exists = true;
			} else {
				UtilityShare entity = new UtilityShare();
				entity.setBeneficiaryUtg(beneficiaryUTG);
				entity.setInjectorUtg(utilityUTG);
				entity.setFromDate(fromDate);
				entity.setToDate(toDate);
				entity.setShareType(shareType);
				utilityShareDAO.save(entity);
				Set<UtilityShareDetails> detailsSet = new HashSet<>();
				for (BlockRangeQuantumsDTO brqDTO : detailsDTO) {
					UtilityShareDetails detailEntity = new UtilityShareDetails();
					detailEntity.setFromBlock(timeIntervalDAO.findByBlock(brqDTO.getFromBlockId()));
					detailEntity.setToBlock(timeIntervalDAO.findByBlock(brqDTO.getToBlockId()));
					detailEntity.setShare(new BigDecimal(brqDTO.getQuantum().toString()));
					detailEntity.setRegulatedShare(entity);
					detailsSet.add(detailEntity);
				}
				entity.setShareDetails(detailsSet);
				utilityShareDAO.save(entity);
			}
		}
		if (exists) {
			throw new BusinessException(msg.toString());
		}
	}

	/**
	 * This method for getting Utility Share based on the utility share id
	 */
	@Override
	public UtilityShareBO findById(int utilityShareId) throws BusinessException, Exception {
		UtilityShareBO usBO = new UtilityShareBO();
		Optional<UtilityShare> us = utilityShareDAO.findById(utilityShareId);
		if (us.isPresent()) {
			usBO = transform(us.get());
		} else {
			usBO = null;
		}

		return usBO;
	}

	@Override
	public void editUtilityShare(List<UtilityShareBO> bos) throws BusinessException, ParseException {
		StringBuilder errorMsg = new StringBuilder();
		errorMsg.append("Data already exist for:");
		Boolean exists = false;

		for (UtilityShareBO bo : bos) {
			Integer beneficiaryUtgId = bo.getDraweeUtgId();
			Integer utilityUtgId = bo.getInjectorUtgId();
			Integer shareId = bo.getId();
			String type = bo.getType();
			Date fromDate = bo.getFromDate();
			Date toDate = bo.getToDate();
			List<BlockRangeQuantumsDTO> detailsDTO = bo.getDetails();

			ShareType shareType = ShareType.valueOf(type);
			List<UtilityShare> existShare = utilityShareDAO.findSharedForDateRange(beneficiaryUtgId, utilityUtgId,
					fromDate, toDate, shareType);

			if (existShare.size() > 1) {
				errorMsg.append("<br> Beneficiary: " + beneficiaryUtgId
						+ " Generator: " + utilityUtgId + " and For Date Range: "
						+ bo.getFromDate() + " - " + bo.getToDate() + " .");
				exists = true;
			} else if (existShare.size() == 1 && !existShare.get(0).getUID().equals(shareId)) {
				errorMsg.append("<br> Beneficiary: " + existShare.get(0).getBeneficiaryUtg().getName() + " Generator: "
						+ utilityUtgId + " and For Date Range: "
						+ existShare.get(0).getFromDate() + " to " + existShare.get(0).getToDate());
				exists = true;
			} else {
				UtilityShare entity = utilityShareDAO.findById(shareId).get();
				utilityShareDetailDAO.deleteByUtilityShare(entity.getUID());

				Set<UtilityShareDetails> detailsSet = new HashSet<>();
				for (BlockRangeQuantumsDTO brqDTO : detailsDTO) {
					UtilityShareDetails detailEntity = new UtilityShareDetails();
					detailEntity.setFromBlock(timeIntervalDAO.findById(brqDTO.getFromBlockId()).get());
					detailEntity.setToBlock(timeIntervalDAO.findById(brqDTO.getToBlockId()).get());
					detailEntity.setShare(new BigDecimal(brqDTO.getQuantum().toString()));
					detailEntity.setRegulatedShare(entity);
					detailsSet.add(detailEntity);
					utilityShareDetailDAO.save(detailEntity);
				}
				entity.setFromDate(fromDate);
				entity.setToDate(toDate);
				entity.setBeneficiaryUtg(utgDAO.findById(beneficiaryUtgId).get());
				entity.setShareDetails(detailsSet);
				utilityShareDAO.save(entity);
			}
		}
		if (exists) {
			throw new BusinessException(errorMsg.toString());
		}
	}

	@Override
	public List<UtilityShareBO> findInjectorShareBO(int utgId, Date forDate, ShareType shareType)
			throws ParseException, BusinessException {
		List<UtilityShareBO> shareBos = new ArrayList<>();
		List<UtilityShare> beneficiarySharesForDate = utilityShareDAO.findInjectorSharesForDate(utgId, forDate,
				shareType);
		if (CollectionUtils.isNotEmpty(beneficiarySharesForDate)) {
			for (UtilityShare utilityShare : beneficiarySharesForDate) {
				shareBos.add(transform(utilityShare));
			}
		}
		return shareBos;
	}

	@Override
	public void deleteUtilityShare(Integer utilityShareId) {
		utilityShareDAO.deleteById(utilityShareId);
	}

	private UtilityShareBO transform(UtilityShare utilityShare) {
		UtilityShareBO utilityShareBO = new UtilityShareBO();
		utilityShareBO.setId(utilityShare.getUID());
		utilityShareBO.setFromDate(utilityShare.getFromDate());
		utilityShareBO.setToDate(utilityShare.getToDate());
		utilityShareBO.setDraweeUtgId(utilityShare.getBeneficiaryUtg().getUID());
		utilityShareBO.setDraweeName(utilityShare.getBeneficiaryUtg().getName());
		utilityShareBO.setInjectorUtgId(utilityShare.getInjectorUtg().getUID());
		utilityShareBO.setInjectorName(utilityShare.getInjectorUtg().getName());
		utilityShareBO.setType(utilityShare.getShareType().name());
		for (UtilityShareDetails detailObj : utilityShare.getShareDetails()) {
			utilityShareBO.addDetail(transform(detailObj));
		}

		return utilityShareBO;

	}

	private BlockRangeQuantumsDTO transform(UtilityShareDetails detailObj) {
		BlockRangeQuantumsDTO detail = new BlockRangeQuantumsDTO();
		detail.setFromBlockId(detailObj.getFromBlock().getBlockNumber());
		detail.setToBlockId(detailObj.getToBlock().getBlockNumber());
		detail.setQuantum(detailObj.getShare().floatValue());
		detail.setId(detailObj.getUID());
		return detail;
	}


}
