/**
 * 
 */
package in.hertz.samast.service;

import java.util.Date;
import java.util.List;

import in.hertz.samast.domain.ForecastSubscriptionBO;
import in.hertz.samast.domain.ForecastSubscriptionUsagesBO;
import in.hertz.samast.domain.PSSDetailsDTO;
import in.hertz.samast.domain.exception.BusinessException;

/**
 * @author Bibhuti Parida
 *
 */
public interface ForecastSubscriptionService {

	public List<PSSDetailsDTO> getPSSListByQCAId(int qcaUtgId) throws Exception, BusinessException;
	public List<ForecastSubscriptionBO> getForecastSubscriptionListByPSSId(int pssUtgId) throws Exception, BusinessException;
	public ForecastSubscriptionBO saveForecastSubscription(ForecastSubscriptionBO forecastSubscriptionBO) throws Exception, BusinessException;
	public ForecastSubscriptionBO newFS( int pssUtgId, int noOfDays) throws Exception, BusinessException;
	public List<ForecastSubscriptionUsagesBO> getForecastSubscriptionDetailByPSSId(int pssUtgId, Date forDate) throws Exception, BusinessException;
	public List<ForecastSubscriptionBO> getForecastSubscriptionByPSSId(int pssUtgId) throws Exception, BusinessException;
	public ForecastSubscriptionUsagesBO updateForecastSubscription(ForecastSubscriptionUsagesBO fsBO) throws Exception, BusinessException;
}
