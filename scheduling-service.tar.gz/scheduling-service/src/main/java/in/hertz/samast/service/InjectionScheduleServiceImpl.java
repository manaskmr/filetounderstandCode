
package in.hertz.samast.service;

import java.sql.Time;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import in.hertz.samast.config.BusinessErrorPropertyConfig;
import in.hertz.samast.dao.ContractTypeDao;
import in.hertz.samast.dao.DeclareCapacityDetailsRepository;
import in.hertz.samast.dao.DeclareCapacityRepository;
import in.hertz.samast.dao.DraftRepository;
import in.hertz.samast.dao.InjectionScheduleDao;
import in.hertz.samast.dao.InjectionScheduleSummaryDetailRepository;
import in.hertz.samast.dao.InjectionScheduleSummaryRepository;
import in.hertz.samast.dao.PSSRepository;
import in.hertz.samast.dao.TimeIntervalRepository;
import in.hertz.samast.dao.UtilitiesTraderGencoRepository;
import in.hertz.samast.domain.DraftDTO;
import in.hertz.samast.domain.InjectionScheduleBO;
import in.hertz.samast.domain.InjectionScheduleContractTypeQuantumDto;
import in.hertz.samast.domain.InjectionScheduleDetailBO;
import in.hertz.samast.domain.InjectionScheduleQueryParamDto;
import in.hertz.samast.domain.InjectionScheduleSummaryBO;
import in.hertz.samast.domain.InjectionScheduleSummaryDto;
import in.hertz.samast.domain.PSSDetailsDTO;
import in.hertz.samast.domain.SldcApproveBo;
import in.hertz.samast.domain.exception.BusinessException;
import in.hertz.samast.entity.ContractDefination;
import in.hertz.samast.entity.ContractType;
import in.hertz.samast.entity.DeclareCapability;
import in.hertz.samast.entity.DeclareCapabilityDetails;
import in.hertz.samast.entity.Draft;
import in.hertz.samast.entity.InjectionSchedule;
import in.hertz.samast.entity.InjectionScheduleDetails;
import in.hertz.samast.entity.InjectionScheduleSummary;
import in.hertz.samast.entity.InjectionScheduleSummaryDetail;
import in.hertz.samast.entity.PSS;
import in.hertz.samast.entity.TimeInterval;
import in.hertz.samast.entity.UtilitiesTraderGenco;
import in.hertz.samast.util.FunctionalityArea;

/**
 * 
 * @author Bibhuti Parida
 * @author Dipu Kumar
 *
 */

@Configuration
@Service
@Transactional
@ComponentScan(basePackages = "in.hertz.samast.config")
public class InjectionScheduleServiceImpl implements InjectionScheduleService {

	private static final Logger LOG = LogManager.getLogger(InjectionScheduleServiceImpl.class);

	@Autowired
	private BusinessErrorPropertyConfig bepc;
	
	@Autowired
	private PSSRepository pssSRepository;
	
	@Autowired
	private DeclareCapacityRepository declareCapacityRepository;

	@Autowired
	private DeclareCapacityDetailsRepository declareCapacityDetailsRepository;
	
	@Autowired
	private InjectionScheduleSummaryRepository injectionScheduleSummaryRepository;
	
	@Autowired
	private InjectionScheduleSummaryDetailRepository injectionScheduleSummaryDetailRepository;
	
	@Autowired
	private TimeIntervalService timeIntervalService;
	
	@Autowired
	private ExBusCapacityService exBusCapacityService;
	
	@Autowired
	private DraftRepository<InjectionScheduleBO> draftRepository;
	
	@Autowired
	private DraftRepository<List<InjectionScheduleBO>> draftRepository2;
	
	@Autowired
	private UtilitiesTraderGencoRepository utilitiesTraderGencoRepository;
	
	@Autowired
	private InjectionScheduleDao injectionScheduleDao;
	
	@Autowired
	private ContractTypeDao contractTypeDao;
	
	@Autowired
	private ContractDefinitionService contractDefinitionService;

	@Value("${max.qca.intraday.revision}")
	private int maxQcaIntradayRevisiontime;
	
	@Value("${time.block.limits}")
	private int timeBlockLimts;
	
	@Autowired
	private TimeIntervalRepository timeIntervalDao;
		
	private static final String HH_mm = "HH:mm";
	private static String YYYY_MM_DD = "yyyy-MM-dd";
	
	@Override
	public List<PSSDetailsDTO> getPSSListByQCAId(int qcaUtgId) throws Exception, BusinessException {
		LOG.info("Start InjectionScheduleServiceImpl:getPSSListByQCAId");
		List<PSSDetailsDTO> pssBOList = null;
		List<PSS> pssList = pssSRepository.getPSSListByQCAId(qcaUtgId);
		if(CollectionUtils.isNotEmpty(pssList)) {
			pssBOList = new ArrayList<PSSDetailsDTO>();
			for (PSS pss : pssList) {
				PSSDetailsDTO pssDto = new PSSDetailsDTO();
				pssDto.setGridSubstation(pss.getGridSubstation());
				pssDto.setPssAddress(pss.getPssAddress());
				pssDto.setPssId(pss.getPssId());
				pssDto.setPssName(pss.getPssName());
				pssDto.setQcaUtgId(pss.getUtilitiesTraderGencoQCA().getUID());
				pssDto.setTotalInstalledCapacity(pss.getTotalInstalledCapacity());
				pssDto.setUtgId(pss.getUtilitiesTraderGenco().getUID());
				pssDto.setVoltageLevel(pss.getVoltageLevel());
				pssBOList.add(pssDto);
			}
		}
		LOG.info("End InjectionScheduleServiceImpl:getPSSListByQCAId");
		return pssBOList;
	}
	
	@Override
	public List<InjectionScheduleBO> getPSSSummary(Date forDate, int qcaUtgId) throws Exception, BusinessException {
		List<InjectionScheduleBO> injectionScheduleList = null;
		List<PSSDetailsDTO> pssList = getPSSListByQCAId(qcaUtgId);
		
		if (CollectionUtils.isNotEmpty(pssList)) {
			injectionScheduleList = new ArrayList<InjectionScheduleBO>();
			for (PSSDetailsDTO pssDetailsDTO : pssList) {
				InjectionScheduleBO isBO = getInjectionScheduleByUTG(forDate, pssDetailsDTO.getUtgId());
				if (Objects.nonNull(isBO)) {
					injectionScheduleList.add(isBO);
				}
			}	
		}
		
		return injectionScheduleList;
	}
	
	@Override
	public InjectionScheduleBO getInjectionScheduleByUTG(Date forDate, int utgId) throws Exception, BusinessException {
		LOG.info("Start InjectionScheduleServiceImpl:getInjectionScheduleByUTG");
		InjectionScheduleBO dto = null;
		
		int revisionNo = -1;
		Integer latestRevisionNo = injectionScheduleSummaryRepository.getLatestRevisionNoByUTG(utgId, forDate);
		if (Objects.nonNull(latestRevisionNo)) {
			revisionNo = latestRevisionNo.intValue();
			
			List<InjectionScheduleSummary> isList = injectionScheduleSummaryRepository.getInjectionScheduleSummaryLatestRevision(utgId, forDate, revisionNo);
			if (CollectionUtils.isNotEmpty(isList)) {
				InjectionScheduleSummary is = isList.get(0);
				dto = convertEntryInjectionScheduleBO(is);
				
				List<DeclareCapability> dcList = declareCapacityRepository.getDeclaredCapacityLatestRevision(utgId, forDate, revisionNo);
				DeclareCapability dc = dcList.get(0);
				Set<DeclareCapabilityDetails> dcdetailsList = dc.getCapabilityDetails();
				Set<InjectionScheduleSummaryDetail> isDetails = is.getInjectionScheduleSummaryDetail();
				if (CollectionUtils.isNotEmpty(isDetails)) {
					List<InjectionScheduleDetailBO> bqDTOList = new ArrayList<InjectionScheduleDetailBO>();
					for (InjectionScheduleSummaryDetail isDetail : isDetails) {
						InjectionScheduleDetailBO bqDTO = convertEntryInjectionScheduleDetailBO(isDetail, dcdetailsList);
						bqDTOList.add(bqDTO);
					}
					dto.setInjectionScheduleDetail(sortInjectionScheduleQuantumList(bqDTOList));
				}
			}
		}

		LOG.info("End InjectionScheduleServiceImpl:getInjectionScheduleByUTG");
		return dto;
	}
	
	/**
	 * This method retrieve the latest getInjection Schedule based on forDate, UtgId
	 * and revision number
	 */
	@Override
	public InjectionScheduleBO getInjectionScheduleByRevisionNo(Date forDate, int utgId, int revisionNo) throws Exception, BusinessException {
		LOG.info("Start InjectionScheduleServiceImpl:getInjectionScheduleByRevisionNo");
		InjectionScheduleBO dto = null;
			
		List<InjectionScheduleSummary> isList = injectionScheduleSummaryRepository.getInjectionScheduleSummaryLatestRevision(utgId, forDate, revisionNo);
		if (CollectionUtils.isNotEmpty(isList) ) {
			InjectionScheduleSummary is = isList.get(0);
			dto = convertEntryInjectionScheduleBO(is);
			
			List<DeclareCapability> dcList = declareCapacityRepository.getDeclaredCapacityLatestRevision(utgId, forDate, revisionNo);
			DeclareCapability dc = dcList.get(0);
			Set<DeclareCapabilityDetails> dcdetailsList = dc.getCapabilityDetails();
			Set<InjectionScheduleSummaryDetail> isDetails = is.getInjectionScheduleSummaryDetail();
			if (CollectionUtils.isNotEmpty(isDetails)) {
				List<InjectionScheduleDetailBO> bqDTOList = new ArrayList<InjectionScheduleDetailBO>();
				for (InjectionScheduleSummaryDetail isDetail : isDetails) {
					InjectionScheduleDetailBO bqDTO = convertEntryInjectionScheduleDetailBO(isDetail, dcdetailsList);
					bqDTOList.add(bqDTO);
				}
				dto.setInjectionScheduleDetail(sortInjectionScheduleQuantumList(bqDTOList));
			}
		}

		LOG.info("End InjectionScheduleServiceImpl:getInjectionScheduleByRevisionNo");
		return dto;
	}
	
	/**
	 * This method retrieve the latest getInjection Schedule based on forDate, UtgId
	 * and revision number
	 */
	@Override
	public InjectionScheduleBO getInjectionScheduleByRevisionNoScheduleType(Date forDate, int utgId, int revisionNo, String scheduleType) throws Exception, BusinessException {
		LOG.info("Start InjectionScheduleServiceImpl:getInjectionScheduleByRevisionNoScheduleType");
		InjectionScheduleBO dto = null;
			
		List<InjectionScheduleSummary> isList = injectionScheduleSummaryRepository.getInjectionScheduleSummaryLatestRevision(utgId, forDate, revisionNo);
		if (CollectionUtils.isNotEmpty(isList) ) {
			InjectionScheduleSummary is = isList.get(0);
			dto = convertEntryInjectionScheduleBO(is);
			Set<InjectionScheduleSummaryDetail> dayAheadisDetails = null;
			if (scheduleType.equalsIgnoreCase("IntraDay")) {
				List<Integer> dayAheadRevList = getRevisionNoByScheduleType(forDate, utgId, "DayAhead");
				if (CollectionUtils.isNotEmpty(dayAheadRevList)) {
					Integer dayAheadRevNo = Collections.max(dayAheadRevList);
					List<InjectionScheduleSummary> dayAheadisList = injectionScheduleSummaryRepository.getInjectionScheduleSummaryLatestRevision(utgId, forDate, dayAheadRevNo);
					if (CollectionUtils.isNotEmpty(dayAheadisList)) {
						dayAheadisDetails = dayAheadisList.get(0).getInjectionScheduleSummaryDetail();
					}
				}
			}
			
			List<DeclareCapability> dcList = declareCapacityRepository.getDeclaredCapacityLatestRevision(utgId, forDate, revisionNo);
			DeclareCapability dc = dcList.get(0);
			Set<DeclareCapabilityDetails> dcdetailsList = dc.getCapabilityDetails();
			Set<InjectionScheduleSummaryDetail> isDetails = is.getInjectionScheduleSummaryDetail();
			if (CollectionUtils.isNotEmpty(isDetails)) {
				List<InjectionScheduleDetailBO> bqDTOList = new ArrayList<InjectionScheduleDetailBO>();
				for (InjectionScheduleSummaryDetail isDetail : isDetails) {
					InjectionScheduleDetailBO bqDTO = convertEntryInjectionScheduleDetailBO(isDetail, dcdetailsList);
					if (scheduleType.equalsIgnoreCase("IntraDay") && CollectionUtils.isNotEmpty(dayAheadisDetails)) {
						bqDTO = setForDayAheadintoEntryInjectionScheduleDetailBO(bqDTO, dayAheadisDetails);
					}
					bqDTOList.add(bqDTO);
				}
				dto.setInjectionScheduleDetail(sortInjectionScheduleQuantumList(bqDTOList));
			}
		}

		LOG.info("End InjectionScheduleServiceImpl:getInjectionScheduleByRevisionNoScheduleType");
		return dto;
	}
	
	/**
	 * This method returns the current time block number
	 * @return
	 * @throws ParseException
	 */
	@Override
	public TimeInterval getCurrentTimeBlock()  throws Exception, BusinessException {
		return timeIntervalService.getCurrentTimeBlock();
	}
	
	/**
	 * This Method providing Ex Bus Capacity for a particular Generator
	 */
	@Override
	public Integer getExBusCapacity(int utgId) throws Exception, BusinessException {
		return exBusCapacityService.getExBusCapacity(utgId);
	}
	
	/**
	 * This method is giving all revision numbers for generator for a particular date and Schedule type
	 */
	@Override
	public List<Integer> getRevisionNoByScheduleType(Date forDate, int utgId, String scheduleType) throws Exception, BusinessException {
		LOG.info("Start InjectionScheduleServiceImpl:getRevisionNoByScheduleType");
		List<Integer> revisionList = new ArrayList<Integer>();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String strForDate = sdf.format(forDate);

		List<InjectionScheduleSummary> isList = injectionScheduleSummaryRepository.getInjectionScheduleSummaryByUTG(utgId, forDate);
		if (CollectionUtils.isNotEmpty(isList)) {
			for (InjectionScheduleSummary injectionSchedule : isList) {
				String strIssueDate = sdf.format(injectionSchedule.getIssueDate());
				
				Date newIssuesDate = sdf.parse(sdf.format(injectionSchedule.getIssueDate()));
				
				Calendar c = Calendar.getInstance(); 
				c.setTime(newIssuesDate); 
				c.add(Calendar.DATE, 1);
				String newStrIssuesDate = sdf.format(c.getTime());
				
				if (scheduleType.equalsIgnoreCase("IntraDay") && strForDate.equals(strIssueDate)) {
					revisionList.add(injectionSchedule.getRevision());
				} else if (scheduleType.equalsIgnoreCase("DayAhead") && strForDate.equals(newStrIssuesDate)) {
					revisionList.add(injectionSchedule.getRevision());
				}
			}
		}
		LOG.info("End InjectionScheduleServiceImpl:getRevisionNoByScheduleType");
		return revisionList;
	}
	
	/**
	 * This method is giving all revision numbers for generator for a particular date
	 */
	@Override
	public List<Integer> getAllRevisionNo(Date forDate, int utgId) throws Exception, BusinessException {
		LOG.info("Start InjectionScheduleServiceImpl:getAllRevisionNo");
		List<Integer> revisionList = new ArrayList<Integer>();

		List<InjectionScheduleSummary> isList = injectionScheduleSummaryRepository.getInjectionScheduleSummaryByUTG(utgId, forDate);
		if (CollectionUtils.isNotEmpty(isList)) {
			for (InjectionScheduleSummary injectionSchedule : isList) {
				revisionList.add(injectionSchedule.getRevision());
			}
		}
		LOG.info("End InjectionScheduleServiceImpl:getAllRevisionNo");
		return revisionList;
	}
	
	/**
	 * This method retrieve the latest revision number based on forDate, UtgId
	 */
	@Override
	public Integer getLatestRevisionNoByUTG(Date forDate, int utgId) throws Exception, BusinessException {
		LOG.info("Start InjectionScheduleServiceImpl:getAllRevisionNo");
		int revisionNo = -1;
		Integer latestRevisionNo = injectionScheduleSummaryRepository.getLatestRevisionNoByUTG(utgId, forDate);
		if (Objects.nonNull(latestRevisionNo)) {
			revisionNo = latestRevisionNo.intValue();
		}
		LOG.info("End InjectionScheduleServiceImpl:getAllRevisionNo");
		return revisionNo;
	}

	/**
	 * This Method for saving draft data for scheduling DC
	 * checking existing of data, if exist then update existing Draft
	 * Otherwise create new record on Draft table for injection scheduling 
	 */
	@Override
	public Draft<InjectionScheduleBO> saveDraft(DraftDTO<InjectionScheduleBO> draftDTO)  throws Exception, BusinessException {
		LOG.info("Start InjectionScheduleServiceImpl:saveDraft");
		Draft<InjectionScheduleBO> draft = new Draft<>();
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
				
		//Date validation for intra day and day ahead
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        Date dateForDate = df.parse(df.format(draftDTO.getJsonDTO().getForDate()));
        Date dateIssuesDate = df.parse(df.format(new Date()));
        
		Calendar c = Calendar.getInstance(); 
		c.setTime(new Date()); 
		c.add(Calendar.DATE, 1);
		Date newIssuesDate = df.parse(df.format(c.getTime()));

        Date currentDate = sdf.parse(sdf.format(new Date()));
		if (currentDate.compareTo(dateIssuesDate) != 0)
		{
			throw new BusinessException(bepc.getIsissuedate());
		}
		
        int resultIntraday = dateIssuesDate.compareTo(dateForDate);
        int resultDayAhead = newIssuesDate.compareTo(dateForDate);

        if (!(resultIntraday == 0 || resultDayAhead == 0)) {
        	throw new BusinessException(bepc.getIscurrfordate());
        } 
		
        //Validate time block with current time block
		List<InjectionScheduleDetailBO> isDetailBOs = sortInjectionScheduleQuantumList(draftDTO.getJsonDTO().getInjectionScheduleDetail());
		DateFormat dfTime = new SimpleDateFormat("HH:mm");
		long currentms = 0;
		currentms = dfTime.parse(dfTime.format(new Date())).getTime(); 
		Time t = new Time(currentms);
		int maxTimeBlock = timeIntervalService.findMaxBlock().intValue();
		Time fromTime = timeIntervalService.findByBlock((maxTimeBlock-timeBlockLimts)).getTimeInterval();
		Time toTime = timeIntervalService.findByBlock(maxTimeBlock).getTimeInterval();
		
		if (resultIntraday == 0 || (t.equals(fromTime) || (t.before(toTime) && t.after(fromTime)))) {
			TimeInterval currentTimeBlockNo = getCurrentTimeBlock();
			Draft<InjectionScheduleBO> existDraft = fetchDraftData(dateForDate, draftDTO.getJsonDTO().getInjectionUtgId());
			if (Objects.nonNull(existDraft)) {
				List<InjectionScheduleDetailBO> quantumList = sortInjectionScheduleQuantumList(existDraft.getData().getInjectionScheduleDetail());
				boolean quantumChangedflg = validateChangedQuantumonTimeBlock(quantumList, isDetailBOs, (currentTimeBlockNo.getBlockNumber()+timeBlockLimts));
				if (quantumChangedflg) {
					String msg = bepc.getIsquantbegtmblk() + (currentTimeBlockNo.getBlockNumber()+timeBlockLimts);
					throw new BusinessException(msg);
				}
			} 
//			else {
//				boolean quantumChangedflg = validateChangedQuantumonTimeBlock(dcDetailBOs, (currentTimeBlockNo.getBlockNumber()+timeBlockValidate));
//				if (quantumChangedflg) {
//					String msg = "You can not change the quantum before time block " + (currentTimeBlockNo.getBlockNumber()+timeBlockValidate);
//					throw new BusinessException(msg);
//				}
//			}
		}
		
		//Validation for 96 time blocks
		if (!validateQuantumonTimeBlock(isDetailBOs)) {
			throw new BusinessException("All "+ maxTimeBlock +" Blocks are required");
		}
		
		//Validate for the renewable stand-alone generators/QCA for intraday revisions with a gap of 1.5 hr each
		if (resultIntraday == 0) {
			Draft<InjectionScheduleBO> existDraft = fetchDraftData(dateForDate, draftDTO.getJsonDTO().getInjectionUtgId());
			if (Objects.nonNull(existDraft)) {
				long timeDiff = timeIntervalService.timeDifferent(existDraft.getData().getIssueDate());
				long diffMinutes = timeDiff / (60 * 1000); 
				if (diffMinutes < maxQcaIntradayRevisiontime) {
					throw new BusinessException(bepc.getIsintradaytimegap150());
				}
			}
		}
		
		Draft<InjectionScheduleBO> existDraft = fetchDraftData(draftDTO.getJsonDTO().getForDate(), draftDTO.getJsonDTO().getInjectionUtgId());
		if (Objects.nonNull(existDraft)) {
			existDraft.setCreatedBy(draftDTO.getCreatedBy());
			existDraft.setInsertTime(new Date());
			existDraft.setCurrentStage(draftDTO.getCurrentStage());
			existDraft.setStatus(draftDTO.getStatus());
			existDraft.setFunctionalityArea(draftDTO.getFunctionalityArea());
			if (Objects.nonNull(draftDTO.getJsonDTO())) {
				existDraft.setData(draftDTO.getJsonDTO());
			}
			draftRepository.save(existDraft);
			LOG.info("End InjectionScheduleServiceImpl:saveDraft existing Draft");
			return existDraft;
		} else {
			if (Objects.nonNull(draftDTO)) {
				draft.setCreatedBy(draftDTO.getCreatedBy());
				draft.setInsertTime(new Date());
				draft.setCurrentStage(draftDTO.getCurrentStage());
				draft.setStatus(draftDTO.getStatus());
				draft.setFunctionalityArea(draftDTO.getFunctionalityArea());
				if (draftDTO.getJsonDTO() != null) {
					draft.setData(draftDTO.getJsonDTO());
				}
				draftRepository.save(draft);
			}
			return draft;
		}
	}

	/**
	 * This method for fetching Scheduling Draft DC data based on UTGID and forDate
	 */
	@Override
	public Draft<InjectionScheduleBO> fetchDraftData(Date forDate, int utgId) throws Exception, BusinessException {
		LOG.info("Start InjectionScheduleServiceImpl:fetchDraftData");
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String strForDate = sdf.format(forDate);
		
		//Date validation for intra day and day ahead
        Date dateForDate = sdf.parse(sdf.format(forDate));
        Date dateIssuesDate = sdf.parse(sdf.format(new Date()));
        
        Date currentDate = sdf.parse(sdf.format(new Date()));
		if (currentDate.compareTo(dateIssuesDate) != 0)
		{
			throw new BusinessException(bepc.getIsissuedate());
		}
		
		Calendar c = Calendar.getInstance(); 
		c.setTime(dateIssuesDate); 
		c.add(Calendar.DATE, 1);
		Date newIssuesDate = sdf.parse(sdf.format(c.getTime()));

        int resultIntraday = dateIssuesDate.compareTo(dateForDate);
        int resultDayAhead = newIssuesDate.compareTo(dateForDate);
        
        if (!(resultIntraday == 0 || resultDayAhead == 0)) {
        	throw new BusinessException(bepc.getIscurrfordate());
        } 
        
		List<Draft<InjectionScheduleBO>> draftList =  draftRepository.findDraftForInjectionSchedule(utgId, strForDate);
		ObjectMapper mapper = new ObjectMapper();
		List<Draft<InjectionScheduleBO>> pojoDraftList = mapper.convertValue(
				draftList,
			    new TypeReference<List<Draft<InjectionScheduleBO>>>() { });
		
		
		LOG.info("Start InjectionScheduleServiceImpl:fetchDraftData");
		return (CollectionUtils.isNotEmpty(pojoDraftList)) ? pojoDraftList.get(0) : null ;
	}

	/**
	 * This method is for initiate the add Injection Schedule screen
	 * If the is draft value, then it will show that
	 * Otherwise show the add Injection Schedule page with time interval only.
	 */
	@Override
	public InjectionScheduleBO newInjectionSchedule(Date forDate, int utgId) throws Exception, BusinessException {
		LOG.info("Start InjectionScheduleServiceImpl:newInjectionSchedule");
		InjectionScheduleBO injectionScheduleBO = new InjectionScheduleBO();
//		Draft<InjectionScheduleBO> draft =  fetchDraftData(forDate, utgId);
		Integer latestRevisionNo = injectionScheduleSummaryRepository.getLatestRevisionNoByUTG(utgId, forDate);
//		if (Objects.nonNull(draft)) {
//			InjectionScheduleBO draftDTO = draft.getData();
//			if (Objects.isNull(latestRevisionNo))
//			{
//				draftDTO.setRevisionNumber(-1);
//			} else {
//				draftDTO = getInjectionScheduleByUTG(forDate, utgId);;
//				draftDTO.setRevisionNumber(latestRevisionNo+1);
//			}
//			return draftDTO;
//		} else {
			if (Objects.isNull(latestRevisionNo))
			{
				//injectionScheduleBO.setRevisionNumber(-1);
				List<InjectionScheduleDetailBO> quantumList = new ArrayList<InjectionScheduleDetailBO>();
				List<TimeInterval> timeIntervals = timeIntervalService.findAllTimeIntervals();
				for (TimeInterval timeInterval : timeIntervals) {
					InjectionScheduleDetailBO injectionScheduleDetailDTO = new InjectionScheduleDetailBO();
					injectionScheduleDetailDTO.setTimeIntervalId(timeInterval.getUID());
					quantumList.add(injectionScheduleDetailDTO);
				}
				injectionScheduleBO.setInjectionScheduleDetail(sortInjectionScheduleQuantumList(quantumList));
			} else {
				injectionScheduleBO = getInjectionScheduleByUTG(forDate, utgId);
				
				//injectionScheduleBO.setRevisionNumber(latestRevisionNo+1);
			}
//		}

		LOG.info("End InjectionScheduleServiceImpl:newInjectionSchedule");
		return injectionScheduleBO;
	}
	
	
	/**
	 * This Method for saving Injection Schedule data for scheduling Injection Schedule
	 * checking existing of data based revision no, if exist then give the error
	 * Otherwise create new record on Injection Schedule summary table increment 
	 * of one revision number for scheduling Injection Schedule summary
	 */
	@Override
	public InjectionScheduleBO saveInjectionSchedule(InjectionScheduleBO ursBO) throws Exception, BusinessException {
		LOG.info("Start InjectionScheduleServiceImpl:saveIS");
		Integer utgId = ursBO.getInjectionUtgId();
		Date forDate = ursBO.getForDate();
		Integer latestRevisionNo = injectionScheduleSummaryRepository.getLatestRevisionNoByUTG(utgId, forDate);

		//Revision no validation
		if (Objects.isNull(ursBO.getRevisionNumber()))
		{
			throw new BusinessException(bepc.getIsrevnonotnull());
		} else {
			if (Objects.isNull(latestRevisionNo) && ursBO.getRevisionNumber() != -1) {
				throw new BusinessException(bepc.getIsrevnominusone());
			}
			if (Objects.nonNull(latestRevisionNo)) {
				if (ursBO.getRevisionNumber() <= latestRevisionNo.intValue()) {
					throw new BusinessException(bepc.getIsrevnonotleseq());
				} else if (ursBO.getRevisionNumber() > (latestRevisionNo.intValue()+1)) {
					throw new BusinessException(bepc.getIsrevlatbyone());
				}
			}			
		}
		
		//Date validation for intra day and day ahead
        DateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date dateForDate = sdf.parse(sdf.format(forDate));
        Date dateIssuesDate = sdf.parse(sdf.format(new Date()));
        Date currentDate = sdf.parse(sdf.format(new Date()));
		if (currentDate.compareTo(dateIssuesDate) != 0)
		{
			throw new BusinessException(bepc.getIsissuedate());
		}
		Calendar c = Calendar.getInstance(); 
		c.setTime(new Date()); 
		c.add(Calendar.DATE, 1);
		Date newIssuesDate = sdf.parse(sdf.format(c.getTime()));

        int resultIntraday = dateIssuesDate.compareTo(dateForDate);
        int resultDayAhead = newIssuesDate.compareTo(dateForDate);
        
        if (!(resultIntraday == 0 || resultDayAhead == 0)) {
        	throw new BusinessException(bepc.getIscurrfordate());
        } 
		
        
        //Validate time block with current time block
		List<InjectionScheduleDetailBO> isDetailBOs = sortInjectionScheduleQuantumList(ursBO.getInjectionScheduleDetail());
		
		DateFormat df = new SimpleDateFormat("HH:mm");
		long currentms = 0;
		currentms = df.parse(df.format(new Date())).getTime(); 
		Time t = new Time(currentms);
		int maxTimeBlock = timeIntervalService.findMaxBlock().intValue();
		Time fromTime = timeIntervalService.findByBlock((maxTimeBlock-timeBlockLimts)).getTimeInterval();
		Time toTime = timeIntervalService.findByBlock(maxTimeBlock).getTimeInterval();
		
		if (resultIntraday == 0 || (t.equals(fromTime) || (t.before(toTime) && t.after(fromTime)))) {
			TimeInterval currentTimeBlockNo = getCurrentTimeBlock();
			InjectionScheduleBO existIS = getInjectionScheduleByUTG(forDate, utgId);
			if (Objects.nonNull(existIS)) {
				List<InjectionScheduleDetailBO> quantumList = sortInjectionScheduleQuantumList(existIS.getInjectionScheduleDetail());
				boolean quantumChangedflg = validateChangedQuantumonTimeBlock(quantumList, isDetailBOs, (currentTimeBlockNo.getBlockNumber()+timeBlockLimts));
				if (quantumChangedflg) {
					String msg = bepc.getIsquantbegtmblk() + (currentTimeBlockNo.getBlockNumber()+timeBlockLimts);
					throw new BusinessException(msg);
				}
			} 
//			else {
//				boolean quantumChangedflg = validateChangedQuantumonTimeBlock(dcDetailBOs, (currentTimeBlockNo.getBlockNumber()+timeBlockValidate));
//				if (quantumChangedflg) {
//					String msg = "You can not change the quantum before time block " + (currentTimeBlockNo.getBlockNumber()+timeBlockValidate);
//					throw new BusinessException(msg);
//				}
//			}
		}
		
		//Validation for 96 time blocks
		if (!validateQuantumonTimeBlock(isDetailBOs)) {
			throw new BusinessException("All "+ maxTimeBlock +" Blocks are required");
		}
		
		//Validate for the renewable stand-alone generators/QCA for intraday revisions with a gap of 1.5 hr each
		if (resultIntraday == 0) {
			InjectionScheduleBO existIS = getInjectionScheduleByUTG(forDate, utgId);
			if (Objects.nonNull(existIS)) {
				long timeDiff = timeIntervalService.timeDifferent(existIS.getIssueDate());
				long diffMinutes = timeDiff / (60 * 1000); 
				if (diffMinutes < maxQcaIntradayRevisiontime) {
					throw new BusinessException(bepc.getIsintradaytimegap150());
				}
			}
		}
		
		//Saveing injection schedule quantum
		Set<InjectionScheduleSummaryDetail> isDetailList = new HashSet<>();
		InjectionScheduleSummary is = new InjectionScheduleSummary();
		if (utilitiesTraderGencoRepository.findById(utgId).isPresent()) {
			UtilitiesTraderGenco utg = utilitiesTraderGencoRepository.findById(utgId).get();
			is.setInjectorUTG(utg);
		}

		is.setForDate(forDate);
		is.setIssueDate(new Date());
		is.setRevision(ursBO.getRevisionNumber());
		is.setRemarks(ursBO.getRemarks());
		
		for (InjectionScheduleDetailBO bqDTO : isDetailBOs) {
			InjectionScheduleSummaryDetail isDetail = new InjectionScheduleSummaryDetail();
			isDetail.setQuantum(bqDTO.getQuantum());
			isDetail.setTimeInterval(timeIntervalService.findByBlock(bqDTO.getTimeIntervalId()));
			isDetail.setInjectionScheduleSummary(is);
			isDetailList.add(isDetail);
		}
		is.setInjectionScheduleSummaryDetail(isDetailList);
		injectionScheduleSummaryRepository.save(is);
		injectionScheduleSummaryDetailRepository.saveAll(isDetailList);
		
		//Saveing injection schedule available capapacity in DC data
		Set<DeclareCapabilityDetails> dcDetailList = new HashSet<>();
		DeclareCapability dc = new DeclareCapability();
		if (utilitiesTraderGencoRepository.findById(utgId).isPresent()) {
			UtilitiesTraderGenco utg = utilitiesTraderGencoRepository.findById(utgId).get();
			dc.setUtilitiesTraderGenco(utg);
		}

		dc.setForDate(forDate);
		dc.setIssueDate(new Date());
		dc.setRevision(ursBO.getRevisionNumber());
		dc.setRemarks(ursBO.getRemarks());
		
		for (InjectionScheduleDetailBO bqDTO : isDetailBOs) {
			DeclareCapabilityDetails dcDetail = new DeclareCapabilityDetails();
			dcDetail.setQuantumOffBar(0.0f);
			dcDetail.setQuantumOnBar(bqDTO.getAvailableCapacity());
			dcDetail.setQuantumOfPower(bqDTO.getAvailableCapacity());
			dcDetail.setTimeIntervalId(bqDTO.getTimeIntervalId());
			dcDetail.setDeclareCapability(dc);
			dcDetailList.add(dcDetail);
		}
		dc.setCapabilityDetails(dcDetailList);
		declareCapacityRepository.save(dc);
		declareCapacityDetailsRepository.saveAll(dcDetailList);
		
		
		//Update existing Draft data
		Draft<InjectionScheduleBO> existDraft = fetchDraftData(forDate, utgId);
		if (Objects.nonNull(existDraft)) {
			existDraft.setStatus("COMPLETED");
			draftRepository.save(existDraft);
		}
		LOG.info("End InjectionScheduleServiceImpl:saveIS");
		return ursBO;
	}
	
	/**
	 * This method for sorting quantum list based on time interval id
	 * @param isQuantumList
	 * @return
	 */
	private List<InjectionScheduleDetailBO> sortInjectionScheduleQuantumList(List<InjectionScheduleDetailBO> isQuantumList) {
		if (CollectionUtils.isNotEmpty(isQuantumList)) {
			Comparator<InjectionScheduleDetailBO> timeBlockSorter = (a, b) -> a.getTimeIntervalId().compareTo(b.getTimeIntervalId());
			Collections.sort(isQuantumList, timeBlockSorter);
		}
		return isQuantumList;
	}
	
	/**
	 * This Method for converting Injection Schedule entity to DTO
	 * @param is
	 * @return
	 */
	private InjectionScheduleBO convertEntryInjectionScheduleBO(InjectionScheduleSummary is) {
		InjectionScheduleBO dto = new InjectionScheduleBO();
		dto.setForDate(is.getForDate());
		dto.setIssueDate(is.getIssueDate());
		dto.setInjectionUtgId(is.getInjectorUTG().getUID());
		dto.setInjectionName(is.getInjectorUTG().getName());
		dto.setRevisionNumber(is.getRevision());
		dto.setApprovedDate(is.getApprovedDate());
		return dto;
	}
	
	/**
	 * This Method for converting Injection Schedule detail entity to DTO
	 * @param is
	 * @return
	 */
	private InjectionScheduleDetailBO convertEntryInjectionScheduleDetailBO(InjectionScheduleSummaryDetail is, Set<DeclareCapabilityDetails> dcdetailsList) {
		InjectionScheduleDetailBO dto = new InjectionScheduleDetailBO();
		dto.setQuantum(is.getQuantum());
		dto.setTimeIntervalId(is.getTimeInterval().getBlockNumber());
		dto.setInjectionScheduleUID(is.getId());
		if (CollectionUtils.isNotEmpty(dcdetailsList)) {
			DeclareCapabilityDetails dcDetails = dcdetailsList.stream().filter(c -> c.getTimeIntervalId() == is.getTimeInterval().getUID().intValue()).collect(Collectors.toList()).get(0);;
			if (Objects.nonNull(dcDetails)) {
				dto.setAvailableCapacity(dcDetails.getQuantumOnBar());
			}
		}
		return dto;
	}	
	
	/**
	 * This Method for converting Injection Schedule detail entity to DTO
	 * @param is
	 * @return
	 */
	private InjectionScheduleDetailBO setForDayAheadintoEntryInjectionScheduleDetailBO(InjectionScheduleDetailBO dto, Set<InjectionScheduleSummaryDetail> dayAheadisDetails) {
		if (CollectionUtils.isNotEmpty(dayAheadisDetails)) {
			InjectionScheduleSummaryDetail issDetails = dayAheadisDetails.stream().filter(c -> c.getTimeInterval().getUID().equals(dto.getTimeIntervalId())).collect(Collectors.toList()).get(0);;
			if (Objects.nonNull(issDetails)) {
				dto.setDayAheadSchedule(issDetails.getQuantum());
			}
		}
		return dto;
	}	
	
	/**
	 * This Method validate quantum value whether quantum changed before time block
	 * @param existQuantumList
	 * @param dcDetailBOs
	 * @param currentTimeBlockNo
	 * @return
	 */
	private boolean validateChangedQuantumonTimeBlock(List<InjectionScheduleDetailBO> existQuantumList, List<InjectionScheduleDetailBO> isDetailBOs, int currentTimeBlockNo) {
		boolean flg = false;
		if (CollectionUtils.isNotEmpty(existQuantumList) && CollectionUtils.isNotEmpty(isDetailBOs)) {
			for (InjectionScheduleDetailBO scheduleQuantumDTO : existQuantumList) {
				if (scheduleQuantumDTO.getTimeIntervalId().intValue() < currentTimeBlockNo) {
					for (InjectionScheduleDetailBO scheduleQuantumDTO2 : isDetailBOs) {
						if (scheduleQuantumDTO2.getTimeIntervalId().equals(scheduleQuantumDTO.getTimeIntervalId())) {
							if (!(scheduleQuantumDTO.getAvailableCapacity().equals(scheduleQuantumDTO2.getAvailableCapacity()) && scheduleQuantumDTO.getQuantum().equals(scheduleQuantumDTO2.getQuantum()))) {
								flg = true;
								break;
							}
						}
					}
					if (flg) {
						break;
					}
				}
			}
		}
		return flg;
	}
	
	/**
	 * This Method validate quantum block number whether quantum time block has 96 blocks or not
	 * @param isDetailBOs
	 * @return
	 * @throws BusinessException 
	 * @throws Exception 
	 */
	private boolean validateQuantumonTimeBlock(List<InjectionScheduleDetailBO> isDetailBOs) throws Exception, BusinessException {
		boolean flg = false;
		List<TimeInterval> timeIntervals = timeIntervalService.findAllTimeIntervals();
		int maxTimeBlock = timeIntervalService.findMaxBlock().intValue();
		Comparator<TimeInterval> timeBlockSorter = (a, b) -> Integer.valueOf(a.getBlockNumber()).compareTo(Integer.valueOf(b.getBlockNumber()));
		Collections.sort(timeIntervals, timeBlockSorter);
		
		if (CollectionUtils.isNotEmpty(isDetailBOs)) {
			for (TimeInterval timeIntervalDTO : timeIntervals) {
				for (InjectionScheduleDetailBO injectionScheduleDetailBO : isDetailBOs) {
					if (injectionScheduleDetailBO.getTimeIntervalId().equals(Integer.valueOf(timeIntervalDTO.getBlockNumber()))) {
						flg = true;
						break;
					}
				}
				if (flg && timeIntervalDTO.getBlockNumber() != maxTimeBlock) {
					flg =false;
					continue;
				} else {
					break;
				}
			}
		}
		return flg;
	}

	@Override
	public InjectionSchedule makeInjectionSchedule(InjectionScheduleBO injectionScheduleBO) throws BusinessException, Exception {
		InjectionSchedule injectionSchedule = new InjectionSchedule();
		Set<InjectionScheduleDetails> injectionScheduleDetails = new HashSet<>();
		
		for (InjectionScheduleDetailBO injectionScheduleDetailBO: injectionScheduleBO.getInjectionScheduleDetail()) {
			InjectionScheduleDetails injectionScheduleDetail = new InjectionScheduleDetails();
			injectionScheduleDetail.setInjectionSchedule(injectionSchedule);
			injectionScheduleDetail.setTimeIntervalId(injectionScheduleDetailBO.getTimeIntervalId());
			injectionScheduleDetail.setSchQuantum(injectionScheduleDetailBO.getQuantum().floatValue());
			injectionScheduleDetails.add(injectionScheduleDetail);
		}
		
		injectionSchedule.setForDate(injectionScheduleBO.getForDate());
		injectionSchedule.setIssueDate(injectionScheduleBO.getIssueDate());
		injectionSchedule.setRevision(injectionScheduleBO.getRevisionNumber());
		
		UtilitiesTraderGenco injectingEntity = utilitiesTraderGencoRepository.findById(injectionScheduleBO.getInjectionUtgId()).get();
		UtilitiesTraderGenco drawingEntity = utilitiesTraderGencoRepository.findById(injectionScheduleBO.getDraweeUtgId()).get();
		injectionSchedule.setInjectingEntity(injectingEntity);
		injectionSchedule.setDrawingEntity(drawingEntity);
		
		ContractType contractType = contractTypeDao.getByShortName(injectionScheduleBO.getContractName());
		ContractDefination contractDefination = contractDefinitionService.findContractDefinition(
				injectionScheduleBO.getInjectionUtgId(),
				injectionScheduleBO.getDraweeUtgId(),
				injectionScheduleBO.getForDate());
		
		injectionSchedule.setContractType(contractType);
		injectionSchedule.setContractDefination(contractDefination);
		
		injectionSchedule.setInjectionScheduleDetails(injectionScheduleDetails);
		
		return injectionSchedule;
	}
	
	@Override
	public InjectionScheduleSummary makeInjectionScheduleSummary(InjectionScheduleBO injectionScheduleBO) throws BusinessException, Exception {
		InjectionScheduleSummary injectionScheduleSummary = new InjectionScheduleSummary();
		Set<InjectionScheduleSummaryDetail> injectionScheduleSummaryDetails = new HashSet<>();
		
		for (InjectionScheduleDetailBO injectionScheduleDetailBO: injectionScheduleBO.getInjectionScheduleDetail()) {
			InjectionScheduleSummaryDetail injectionScheduleSummaryDetail = new InjectionScheduleSummaryDetail();
			TimeInterval timeInterval = timeIntervalDao.findById(injectionScheduleDetailBO.getTimeIntervalId()).get();
			injectionScheduleSummaryDetail.setInjectionScheduleSummary(injectionScheduleSummary);
			injectionScheduleSummaryDetail.setTimeInterval(timeInterval);
			injectionScheduleSummaryDetail.setQuantum(injectionScheduleDetailBO.getQuantum());
			injectionScheduleSummaryDetails.add(injectionScheduleSummaryDetail);
		}
		
		Integer injectorUtgId = injectionScheduleBO.getInjectionUtgId();
		UtilitiesTraderGenco injectorUtg = utilitiesTraderGencoRepository.findById(injectorUtgId).get();

		injectionScheduleSummary.setForDate(injectionScheduleBO.getForDate());
		injectionScheduleSummary.setIssueDate(injectionScheduleBO.getIssueDate());
		injectionScheduleSummary.setRevision(injectionScheduleBO.getRevisionNumber());
		injectionScheduleSummary.setInjectorUTG(injectorUtg);
		injectionScheduleSummary.setInjectionScheduleSummaryDetail(injectionScheduleSummaryDetails);
		
		return injectionScheduleSummary;
	}

	@Override
	public boolean saveInjectionScheduleData(List<InjectionScheduleBO> injectionScheduleBOs) throws BusinessException, Exception {
		if (injectionScheduleBOs.size() < 2) return false;
		
		for (int i = 0; i < injectionScheduleBOs.size() - 1; i++) {
			InjectionScheduleBO injectionScheduleBO = injectionScheduleBOs.get(i);
			InjectionSchedule injectionSchedule = makeInjectionSchedule(injectionScheduleBO);
			if (injectionScheduleDao.save(injectionSchedule) == null) return false;
		}
		InjectionScheduleBO injectionScheduleBO = injectionScheduleBOs.get(injectionScheduleBOs.size() - 1);
		InjectionScheduleSummary injectionScheduleSummary = makeInjectionScheduleSummary(injectionScheduleBO);
		if (injectionScheduleSummaryRepository.save(injectionScheduleSummary) == null) return false;
		
		return true;
	}
	
	@Override
	public boolean saveInjectionScheduleDataAsDraft(List<InjectionScheduleBO> injectionScheduleBOs) throws BusinessException, Exception {
		for (InjectionScheduleBO injectionScheduleBO: injectionScheduleBOs) {
			Draft<InjectionScheduleBO> draft = new Draft<>();
			draft.setCreatedBy(null);
			draft.setInsertTime(Date.from(Instant.now()));
			draft.setFunctionalityArea(FunctionalityArea.INJ_SCH_OA);
			draft.setData(injectionScheduleBO);
			if (draftRepository.save(draft) == null) return false;
		}
		return true;
	}
	
	@Override
	public List<Draft<InjectionScheduleBO>> findDraftedInjectionSchedule(int gencoUtgId, Date forDate, int revision) throws BusinessException, Exception {
		SimpleDateFormat sdf = new SimpleDateFormat(YYYY_MM_DD);
		return draftRepository.findDraftedInjectionSchedule(gencoUtgId, sdf.format(forDate), revision);
	}
	
	@Override
	public Integer findLatestRevision(int gencoUtgId, Date date, String schType) throws BusinessException, Exception {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		if (schType.equalsIgnoreCase("DayAhead"))
			calendar.add(Calendar.DATE, 1);
		Date forDate = calendar.getTime();
		return injectionScheduleDao.findLatestRevision(gencoUtgId, forDate);
	}
	
	@Override
	public List<InjectionScheduleSummaryBO> getInjectionSummaryListByQCAId(int qcaUtgId, Date forDate) throws Exception, BusinessException {
		List<InjectionScheduleSummaryBO> isSummaryBOList = null;
		List<PSS> pssList = pssSRepository.getPSSListByQCAId(qcaUtgId);
		if(CollectionUtils.isNotEmpty(pssList)) {
			isSummaryBOList = new ArrayList<InjectionScheduleSummaryBO>();
			for (PSS pss : pssList) {
				InjectionScheduleSummaryBO isSummaryBO = new InjectionScheduleSummaryBO();
				isSummaryBO.setQcaUtgId(qcaUtgId);
				isSummaryBO.setPssUtgId(pss.getUtilitiesTraderGenco().getUID());
				isSummaryBO.setPssName(pss.getUtilitiesTraderGenco().getName());
				List<Integer> IntraList = getRevisionNoByScheduleType(forDate, pss.getUtilitiesTraderGenco().getUID(), "IntraDay");
				List<Integer> dayAheadList = getRevisionNoByScheduleType(forDate, pss.getUtilitiesTraderGenco().getUID(), "DayAhead");
				if(CollectionUtils.isNotEmpty(IntraList)) {
					isSummaryBO.setIntradayRevNo(Collections.max(IntraList));
				} else {
					isSummaryBO.setIntradayRevNo(null);
				}
				if(CollectionUtils.isNotEmpty(dayAheadList)) {
					isSummaryBO.setDayAheadRevNo(Collections.max(dayAheadList));
				} else {
					isSummaryBO.setDayAheadRevNo(null);
				}
				isSummaryBOList.add(isSummaryBO);
			}
		}
		return isSummaryBOList;
	}

	public List<InjectionScheduleBO> getLatestRevisionDetailsBySourceName(SldcApproveBo sldcApproveBo) throws Exception, BusinessException {
		List<InjectionScheduleBO> injectionScheduleBOList = new ArrayList<>();
		List<String> sourceName = sldcApproveBo.getSourceName();
		List<PSS> pssList = pssSRepository.getPSSListBySourceName(sourceName);
		if (CollectionUtils.isNotEmpty(pssList)) {
			for (PSS pss : pssList) {
				InjectionScheduleBO bo = getInjectionScheduleByUTG(sldcApproveBo.getDate(),
						pss.getUtilitiesTraderGenco().getUID());
				if (Objects.nonNull(bo)) {
					bo.setEntityName(pss.getUtilitiesTraderGenco().getName());
					bo.setInjectionScheduleDetail(null);
					injectionScheduleBOList.add(bo);
				}
			}
		}
		return injectionScheduleBOList;
		}

	@Override
	public InjectionScheduleBO editInjectionScheduleByRevisionNoAndUtgId(SldcApproveBo sldcApproveBo) throws Exception, BusinessException {
		String scheduleType = "IntraDay";
		return getInjectionScheduleByRevisionNoScheduleType(sldcApproveBo.getDate(),
				sldcApproveBo.getUtgId(), sldcApproveBo.getRevisionNo(), scheduleType);
	}

	@Override
	public List<InjectionScheduleBO> viewInjectionScheduleBySourceNameUtgIdsAndQcaUtgIds(SldcApproveBo sldcApproveBo) throws Exception, BusinessException {
		List<InjectionScheduleBO> injectionScheduleBOList = new ArrayList<>();
		List<String> sourceName = sldcApproveBo.getSourceName();
		List<Integer> utgIds = sldcApproveBo.getUtgIds();
		List<Integer> qcaUtgIds = sldcApproveBo.getQcaUtgIds();
		String scheduleType = "IntraDay";
		int revisionNo;
		List<PSS> pssList = pssSRepository.getPSSListBySourceNameAndUtgId(sourceName, utgIds);
		if (CollectionUtils.isNotEmpty(pssList)) {
			for (PSS pss : pssList) {
				if (sldcApproveBo.getRevisionNo() != null) {
					revisionNo = sldcApproveBo.getRevisionNo();
				} else {
					revisionNo = getLatestRevisionNoByUTG(sldcApproveBo.getDate(),
							pss.getUtilitiesTraderGenco().getUID());
				}
				InjectionScheduleBO bo = getInjectionScheduleByRevisionNoScheduleType(sldcApproveBo.getDate(),
						pss.getUtilitiesTraderGenco().getUID(), revisionNo, scheduleType);
				if (Objects.nonNull(bo)) {
					injectionScheduleBOList.add(bo);

				}

			}
		}
		
		return injectionScheduleBOList;
	}
	
	@Override
	public List<InjectionScheduleBO> viewInjectionScheduleByUtgIdAndRevisionNo(SldcApproveBo sldcApproveBo)
			throws Exception, BusinessException {
		List<InjectionScheduleBO> injectionScheduleBOList = new ArrayList<>();
		List<String> sourceName = sldcApproveBo.getSourceName();
		List<Integer> utgIds = sldcApproveBo.getUtgIds();
		String scheduleType = "IntraDay";
		int revisionNo;
		List<PSS> pssList = pssSRepository.getPSSListBySourceNameAndUtgId(sourceName, utgIds);
		if (CollectionUtils.isNotEmpty(pssList)) {
			for (PSS pss : pssList) {
				if (sldcApproveBo.getRevisionNo() != null) {
					revisionNo = sldcApproveBo.getRevisionNo();
				} else {
					revisionNo = getLatestRevisionNoByUTG(sldcApproveBo.getDate(),
							pss.getUtilitiesTraderGenco().getUID());
				}
				InjectionScheduleBO bo = getInjectionScheduleByRevisionNoScheduleType(sldcApproveBo.getDate(),
						pss.getUtilitiesTraderGenco().getUID(), revisionNo, scheduleType);
				if (Objects.nonNull(bo)) {
					injectionScheduleBOList.add(bo);

				}

			}
		}
		
		return injectionScheduleBOList;
	}
	
	@Override
	public String getScheduletype(int utgId, Date forDate, int revisionNo) throws Exception, BusinessException {
		String scheduleType = null;
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		List<InjectionScheduleSummary> isList = injectionScheduleSummaryRepository.getInjectionScheduleSummaryLatestRevision(utgId, forDate, revisionNo);
		if (CollectionUtils.isNotEmpty(isList)) {
			InjectionScheduleSummary is = isList.get(0);
			String strIssueDate = sdf.format(is.getIssueDate());
			Date newIssuesDate = sdf.parse(sdf.format(is.getIssueDate()));
			
			Calendar c = Calendar.getInstance(); 
			c.setTime(newIssuesDate); 
			c.add(Calendar.DATE, 1);
			String newStrIssuesDate = sdf.format(c.getTime());
			
			String strForDate = sdf.format(forDate);
			
			if (strForDate.equals(strIssueDate)) {
				scheduleType = "IntraDay";
			} else if (strForDate.equals(newStrIssuesDate)) {
				scheduleType = "DayAhead";
			}
		}
		return scheduleType;
	}


	private String convertTimeToString(Time time) {

		SimpleDateFormat sdf = new SimpleDateFormat(HH_mm);
		String strTime = sdf.format(time);
		return strTime;
	}
	
   private Map<String,List> createInjecctionScheduleContractTypeQuantumDto1(List<Object[]> listOfObjectArrys) {
	
		
		List<InjectionScheduleContractTypeQuantumDto>listInjectionScheduleContractTypeQuantumDto = new ArrayList<>();
		Map<String,List> map = new LinkedHashMap<>();
		
		
		InjectionScheduleContractTypeQuantumDto injectionScheduleContractTypeQuantumDto =  null;
		
		String scheduledTime = null;
		String toTime = null;
		String shortName = null;
		String blockNumber = null;
		double quantum = 0.00d;

		for(Object[] arr :listOfObjectArrys) {
			for(int i=0;i<arr.length;i++) {
				if(blockNumber==null || (blockNumber!=null && Integer.valueOf(blockNumber)!=Integer.parseInt(String.valueOf(arr[0])))) {
					if(injectionScheduleContractTypeQuantumDto!=null) {
						listInjectionScheduleContractTypeQuantumDto.add(injectionScheduleContractTypeQuantumDto);						
					}
					injectionScheduleContractTypeQuantumDto = new InjectionScheduleContractTypeQuantumDto();
				}			
				blockNumber = String.valueOf(arr[0]);
				scheduledTime = convertTimeToString((Time)arr[1]);
				toTime =  convertTimeToString((Time)arr[2]);
				shortName = (String)arr[4];
				quantum = (double)(arr[7]);
				
				injectionScheduleContractTypeQuantumDto.setBlockNumber(blockNumber);
				injectionScheduleContractTypeQuantumDto.setScheduledTime(scheduledTime);
				injectionScheduleContractTypeQuantumDto.setToTime(toTime);
				injectionScheduleContractTypeQuantumDto.setContractType(shortName);
				
				if(shortName.equalsIgnoreCase("LTOA")) {
					injectionScheduleContractTypeQuantumDto.setLtoaQuantum(roundOff(quantum,2));
				} else if(shortName.equalsIgnoreCase("MTOA")) {
					injectionScheduleContractTypeQuantumDto.setMtoaQuantum(roundOff(quantum,2));
				} else if(shortName.equalsIgnoreCase("STOA")) {
					injectionScheduleContractTypeQuantumDto.setStoaQuantum(roundOff(quantum,2));
				} else {
					
				}
			}
		}
		
		if(listOfObjectArrys!=null && listOfObjectArrys.size()>0) {
			listInjectionScheduleContractTypeQuantumDto.add(injectionScheduleContractTypeQuantumDto);
		}
		List<InjectionScheduleSummaryDto> listinjectionScheduleSummaryDto = null;
		if(listInjectionScheduleContractTypeQuantumDto!=null && listInjectionScheduleContractTypeQuantumDto.size()>0) {
			listinjectionScheduleSummaryDto = calculateSummarizationTotalContractWise(listInjectionScheduleContractTypeQuantumDto);
		}
		
		map.put("Contract Wise Quantum", listInjectionScheduleContractTypeQuantumDto);
		map.put("Summarized Quantum", listinjectionScheduleSummaryDto);
		
		return map;
	}
   
   private List<InjectionScheduleSummaryDto> calculateSummarizationTotalContractWise(List<InjectionScheduleContractTypeQuantumDto> lisInjectionScheduleContractTypeQuantumDto ) {
	   
	   
	      List<InjectionScheduleSummaryDto> listInjectionScheduleSummaryDto = new ArrayList<>();
	      
	      if(lisInjectionScheduleContractTypeQuantumDto!=null) {
	    	  listInjectionScheduleSummaryDto.add(getInjectionScheduleSummaryFromContractDetails(lisInjectionScheduleContractTypeQuantumDto, "Sum"));
	    	  listInjectionScheduleSummaryDto.add(getInjectionScheduleSummaryFromContractDetails(lisInjectionScheduleContractTypeQuantumDto, "Max"));
	    	  listInjectionScheduleSummaryDto.add(getInjectionScheduleSummaryFromContractDetails(lisInjectionScheduleContractTypeQuantumDto, "Min"));
	    	  listInjectionScheduleSummaryDto.add(getInjectionScheduleSummaryFromContractDetails(lisInjectionScheduleContractTypeQuantumDto, "Average"));
	      }
	   
	      return listInjectionScheduleSummaryDto;
	
	}
	
	private double roundOff(double value, int digits) {
	    double scale = Math.pow(10, digits);
	    return Math.round(value * scale) / scale;
	}
    
    public InjectionScheduleSummaryDto getInjectionScheduleSummaryFromContractDetails(List<InjectionScheduleContractTypeQuantumDto> lisInjectionScheduleContractTypeQuantumDto,String summarizeOperation) {
    	
    	double ltaQuantumTotal = 0.00000;
		double mtoaQuantum = 0.00;
		double stoaQuantum = 0.00;
		double exchangeQuantum = 0.00;
		double discomQuantum = 0.00;
		double totalQuantum = 0.00;
		
		InjectionScheduleSummaryDto injectionScheduleSummaryDto = new InjectionScheduleSummaryDto();
    	
    	switch(summarizeOperation){  
    	
    	  case "Sum":      			
    			ltaQuantumTotal =lisInjectionScheduleContractTypeQuantumDto
    							.stream()
    							.collect(Collectors.summarizingDouble(InjectionScheduleContractTypeQuantumDto::getLtoaQuantum))
    							.getSum();
    			mtoaQuantum = lisInjectionScheduleContractTypeQuantumDto
    							.stream()
    							.collect(Collectors.summarizingDouble(InjectionScheduleContractTypeQuantumDto::getMtoaQuantum))
    							.getSum();
    			
    			stoaQuantum = lisInjectionScheduleContractTypeQuantumDto
    							.stream()
    							.collect(Collectors.summarizingDouble(InjectionScheduleContractTypeQuantumDto::getStoaQuantum))
    							.getSum();
    			exchangeQuantum = lisInjectionScheduleContractTypeQuantumDto
    							.stream()
    							.collect(Collectors.summarizingDouble(InjectionScheduleContractTypeQuantumDto::getExchangeQuantum))
    							.getSum();
    			
    			discomQuantum = lisInjectionScheduleContractTypeQuantumDto
    							.stream()
    							.collect(Collectors.summarizingDouble(InjectionScheduleContractTypeQuantumDto::getDiscomQuantum))
    							.getSum();
    			injectionScheduleSummaryDto.setSummarizationText("Total MWhr");
    			break;
    		  
    	  case "Max" :

				ltaQuantumTotal = lisInjectionScheduleContractTypeQuantumDto.stream()
						.collect(Collectors.summarizingDouble(InjectionScheduleContractTypeQuantumDto::getLtoaQuantum))
						.getMax();

				mtoaQuantum = lisInjectionScheduleContractTypeQuantumDto.stream()
						.collect(Collectors.summarizingDouble(InjectionScheduleContractTypeQuantumDto::getMtoaQuantum))
						.getMax();

				stoaQuantum = lisInjectionScheduleContractTypeQuantumDto.stream()
						.collect(Collectors.summarizingDouble(InjectionScheduleContractTypeQuantumDto::getStoaQuantum))
						.getMax();

				exchangeQuantum = lisInjectionScheduleContractTypeQuantumDto.stream()
						.collect(Collectors
								.summarizingDouble(InjectionScheduleContractTypeQuantumDto::getExchangeQuantum))
						.getMax();

				discomQuantum = lisInjectionScheduleContractTypeQuantumDto.stream()
						.collect(
								Collectors.summarizingDouble(InjectionScheduleContractTypeQuantumDto::getDiscomQuantum))
						.getMax();				
				injectionScheduleSummaryDto.setSummarizationText("Maximum (MW)");
				break;
    		  
    		  
    	  case "Min" :
    		  
				ltaQuantumTotal = lisInjectionScheduleContractTypeQuantumDto.stream()
						.collect(Collectors.summarizingDouble(InjectionScheduleContractTypeQuantumDto::getLtoaQuantum))
						.getMin();

				mtoaQuantum = lisInjectionScheduleContractTypeQuantumDto.stream()
						.collect(Collectors.summarizingDouble(InjectionScheduleContractTypeQuantumDto::getMtoaQuantum))
						.getMin();

				stoaQuantum = lisInjectionScheduleContractTypeQuantumDto.stream()
						.collect(Collectors.summarizingDouble(InjectionScheduleContractTypeQuantumDto::getStoaQuantum))
						.getMin();

				exchangeQuantum = lisInjectionScheduleContractTypeQuantumDto.stream()
						.collect(Collectors
								.summarizingDouble(InjectionScheduleContractTypeQuantumDto::getExchangeQuantum))
						.getMin();

				discomQuantum = lisInjectionScheduleContractTypeQuantumDto.stream()
						.collect(
								Collectors.summarizingDouble(InjectionScheduleContractTypeQuantumDto::getDiscomQuantum))
						.getMin();
				injectionScheduleSummaryDto.setSummarizationText("Minimum (MW)");
				break;
    	  case "Average" :
    		  
				ltaQuantumTotal = lisInjectionScheduleContractTypeQuantumDto.stream()
						.collect(Collectors.summarizingDouble(InjectionScheduleContractTypeQuantumDto::getLtoaQuantum))
						.getAverage();

				mtoaQuantum = lisInjectionScheduleContractTypeQuantumDto.stream()
						.collect(Collectors.summarizingDouble(InjectionScheduleContractTypeQuantumDto::getMtoaQuantum))
						.getAverage();

				stoaQuantum = lisInjectionScheduleContractTypeQuantumDto.stream()
						.collect(Collectors.summarizingDouble(InjectionScheduleContractTypeQuantumDto::getStoaQuantum))
						.getAverage();

				exchangeQuantum = lisInjectionScheduleContractTypeQuantumDto.stream()
						.collect(Collectors
								.summarizingDouble(InjectionScheduleContractTypeQuantumDto::getExchangeQuantum))
						.getAverage();

				discomQuantum = lisInjectionScheduleContractTypeQuantumDto.stream()
						.collect(
								Collectors.summarizingDouble(InjectionScheduleContractTypeQuantumDto::getDiscomQuantum))
						.getAverage();
				injectionScheduleSummaryDto.setSummarizationText("Average (MW)");
				break;
    		 
    	}
    	
    	totalQuantum = ltaQuantumTotal + mtoaQuantum + stoaQuantum + exchangeQuantum + discomQuantum;
		
    	injectionScheduleSummaryDto.setLtaQuantumTotal(ltaQuantumTotal);
		injectionScheduleSummaryDto.setMtoaQuantumTotal(mtoaQuantum);
		injectionScheduleSummaryDto.setStoaQuantumTotal(stoaQuantum);
		injectionScheduleSummaryDto.setExchangeQuantumTotal(exchangeQuantum);
		injectionScheduleSummaryDto.setTotalQuantum(totalQuantum);
    	
	
    	return  injectionScheduleSummaryDto;
    }

	

	@Override
	public Map<String, List> getInjectionScheduleContractTypeQuantums1(
			InjectionScheduleQueryParamDto injectionScheduleQueryParamDto) throws BusinessException, Exception {

		
		return createInjecctionScheduleContractTypeQuantumDto1(injectionScheduleDao.findInjectionScheduleByQueryParams(injectionScheduleQueryParamDto));
		
	}

}
