package in.hertz.samast.dao;

import java.util.List;

import in.hertz.samast.domain.ContractConfigurationSearchDto;
import in.hertz.samast.domain.Page;
import in.hertz.samast.entity.ContractDefination;

public interface CustomConfigurationContractDao {
	
	
	List<ContractDefination> findContractDefinitionByMultiPleParams(ContractConfigurationSearchDto contractConfigurationSearchDto, int pageNo, int pageSize);
	Page<List<ContractDefination>> findPagedContractDefinitionByMultiPleParams(
			ContractConfigurationSearchDto contractConfigurationSearchDto,
			int pageNo, int pageSize);
	
}
