package in.hertz.samast.errorhandling;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import in.hertz.samast.domain.WSResp;
import in.hertz.samast.domain.exception.BusinessException;

@ControllerAdvice
public class RestResponseEntityExceptionHandler extends ResponseEntityExceptionHandler {

	private static final Logger LOG = LogManager.getLogger(RestResponseEntityExceptionHandler.class);

	@ExceptionHandler(value = { BusinessException.class, Exception.class })
	protected ResponseEntity<Object> handleConflict(Exception ex, ServletWebRequest request) {

		Throwable cause = ex.getCause();
		WSResp<String> bodyOfResponse = null;
		HttpStatus httpStatus = null;
		if (cause instanceof BusinessException) {
			bodyOfResponse = new WSResp<>(cause.getMessage());
			httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;
			LOG.error(request, cause);
		} else {
			bodyOfResponse = new WSResp<>(ex.getMessage());
			httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;
			LOG.error(request, ex);
		}

		return handleExceptionInternal(ex, bodyOfResponse, new HttpHeaders(), httpStatus, request);
	}
}
