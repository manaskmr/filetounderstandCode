package in.hertz.samast.service;

import in.hertz.samast.entity.ContractDefination;
import in.hertz.samast.domain.InjectionScheduleBO;
import in.hertz.samast.domain.exception.BusinessException;

import java.util.Date;
import java.util.List;

public interface ContractDefinitionService {

	public List<InjectionScheduleBO> findAllContractDefinition(int injectorUtgId, Date forDate) throws BusinessException, Exception;
	
	public ContractDefination findContractDefinition(int injectorUtgId, int draweeUtgId, Date forDate) throws BusinessException, Exception;
}
