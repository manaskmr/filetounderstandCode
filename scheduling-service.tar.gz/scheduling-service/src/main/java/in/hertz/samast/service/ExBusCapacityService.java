package in.hertz.samast.service;

import java.util.List;

import in.hertz.samast.domain.ExBusCapacityBO;
import in.hertz.samast.domain.GenerationUnitBO;
import in.hertz.samast.domain.exception.BusinessException;

/**
 * 
 * @author Bibhuti Parida
 * This is service interface for implementation of ExBus Capacity
 *
 */
public interface ExBusCapacityService {

	public Integer getExBusCapacity(int utgId) throws Exception, BusinessException;
	public List<ExBusCapacityBO> getAllExBusCapacity() throws Exception, BusinessException;
	public List<ExBusCapacityBO> updateAllExBusCapacity(List<ExBusCapacityBO> exBusBoList) throws Exception, BusinessException;
	public List<ExBusCapacityBO> getExBusCapacityByGenType(int genTypeId) throws Exception, BusinessException;
	public List<GenerationUnitBO> getAllGenType() throws Exception, BusinessException;
}
