package in.hertz.samast.service;


import java.util.Date;
import java.util.List;
import java.util.Map;

import in.hertz.samast.domain.DraftDTO;
import in.hertz.samast.domain.ScheduleQuantumBaseDTO;
import in.hertz.samast.domain.SldcApproveBo;
import in.hertz.samast.domain.exception.BusinessException;
import in.hertz.samast.entity.Draft;
import in.hertz.samast.entity.TimeInterval;

/**
 * 
 * @author Bibhuti Parida
 * This is service interface for implementation of declare Capacity
 *
 */
public interface DeclareCapacityService {

	public ScheduleQuantumBaseDTO getDeclaredCapacityByUTG(Date forDate, 
			int utgId) throws Exception, BusinessException;
	
	public ScheduleQuantumBaseDTO getDeclaredCapacityByUTG(Date forDate, 
			int utgId, int revsionNo) throws Exception, BusinessException;
	
	public ScheduleQuantumBaseDTO saveDC(ScheduleQuantumBaseDTO ursBO) 
			throws Exception, BusinessException;
	
	public Draft<ScheduleQuantumBaseDTO> fetchDraftData(Date forDate, int utgId) 
			throws Exception, BusinessException;
	
	public Draft<ScheduleQuantumBaseDTO> saveDraft(DraftDTO<ScheduleQuantumBaseDTO> draftDTO)  
			throws Exception, BusinessException;
	
	public ScheduleQuantumBaseDTO newDeclareCapacity(Date forDate, int utgId)
			throws Exception, BusinessException;
	
	public List<ScheduleQuantumBaseDTO> getAllDeclaredCapacity() 
			throws Exception, BusinessException;
	
	public TimeInterval getCurrentTimeBlock() throws Exception, BusinessException;
	
	public List<Integer> getAllRevisionNo(Date forDate, int utgId) throws Exception, BusinessException;
	
	public Integer getLatestRevisionNoByUTG(Date forDate, int utgId) throws Exception, BusinessException;
	
	public Integer getExBusCapacity(int utgId) throws Exception, BusinessException;
	
	public List<Integer> getRevisionNoByDCType(Date forDate, int utgId, String dcType) throws Exception, BusinessException;
	
	public List<ScheduleQuantumBaseDTO> getAllGenerators(SldcApproveBo sldcApproveBo) 
			throws Exception, BusinessException;

	public List<ScheduleQuantumBaseDTO> viewDcByGenerators(SldcApproveBo sldcApproveBo) 
			throws Exception, BusinessException;
	
	public ScheduleQuantumBaseDTO editDcBySldc(SldcApproveBo sldcApproveBo) 
			throws Exception, BusinessException;
	
	public String getScheduletype(int utgId, Date forDate, int revisionNo) throws Exception, BusinessException;

	public List<ScheduleQuantumBaseDTO> findAllDCReport(String sellerType, Date forDate, int revisionNo) throws Exception;

	public ScheduleQuantumBaseDTO findDCReportBySeller(Date forDate, int revisionNo, int gencoUtgId) throws Exception;

	public Map<Date, Map<String, Double>> findCustomDCReport(String sellerType, Date fromDate, Date toDate,
			String format) throws Exception;

	public List<ScheduleQuantumBaseDTO> getDeclaredCapacityByUTGAndDate(Date fromDate, Date toDate, String format, int utgId);


	



}
