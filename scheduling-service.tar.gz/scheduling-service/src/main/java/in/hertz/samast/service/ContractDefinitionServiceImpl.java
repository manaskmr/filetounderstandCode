package in.hertz.samast.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import in.hertz.samast.dao.ContractDefinitionDao;
import in.hertz.samast.domain.InjectionScheduleBO;
import in.hertz.samast.domain.InjectionScheduleDetailBO;
import in.hertz.samast.domain.exception.BusinessException;
import in.hertz.samast.entity.ContractDefination;
import in.hertz.samast.entity.ContractQuantum;

@Service
public class ContractDefinitionServiceImpl implements ContractDefinitionService {

	@Autowired
	private ContractDefinitionDao contractDefinitionDao;
	
	@Override
	public List<InjectionScheduleBO> findAllContractDefinition(int injectorUtgId, Date forDate) throws BusinessException, Exception {
		List<ContractDefination> contractDefinations = contractDefinitionDao.findAllContractDefinition(injectorUtgId, forDate);
		List<InjectionScheduleBO> injectionScheduleBOs = new ArrayList<>();
		
		for (ContractDefination contractDefination: contractDefinations) {
			InjectionScheduleBO injectionScheduleBO = new InjectionScheduleBO();
			List<InjectionScheduleDetailBO> injectionScheduleDetailBOs = new ArrayList<>();
			
			for (ContractQuantum contractQuantum: contractDefination.getContractQuantums()) {
				int fromBlock = contractQuantum.getFromBlock();
				int toBlock = contractQuantum.getToBlock();
				double quantum = contractQuantum.getQuantum().doubleValue();
				for (int blockNumber = fromBlock; blockNumber <= toBlock; blockNumber++) {
					InjectionScheduleDetailBO injectionScheduleDetailBO = new InjectionScheduleDetailBO();
					injectionScheduleDetailBO.setTimeIntervalId(blockNumber);
					injectionScheduleDetailBO.setQuantum(BigDecimal.valueOf(quantum));
					injectionScheduleDetailBOs.add(injectionScheduleDetailBO);
				}
			}
			
			injectionScheduleBO.setContractUID(contractDefination.getContractTypeUid().getUID());
			injectionScheduleBO.setContractName(contractDefination.getContractTypeUid().getShortName());
			injectionScheduleBO.setIssueDate(contractDefination.getIssueDate());
			injectionScheduleBO.setForDate(forDate);
			injectionScheduleBO.setApplicantName(contractDefination.getApplicantName());
			injectionScheduleBO.setApprovedDate(contractDefination.getApprovalDate());
			injectionScheduleBO.setApprovalNumber(contractDefination.getAcceptanceNumber());
			
			injectionScheduleBO.setInjectionUtgId(contractDefination.getInjector().getUID());
			injectionScheduleBO.setInjectionName(contractDefination.getInjectorName());
			injectionScheduleBO.setDraweeUtgId(contractDefination.getDrawee().getUID());
			injectionScheduleBO.setDraweeName(contractDefination.getDraweeName());
			injectionScheduleBO.setInjectionScheduleDetail(injectionScheduleDetailBOs);
			
			injectionScheduleBOs.add(injectionScheduleBO);
		}
		
		Comparator<InjectionScheduleBO> comparator = (a, b) -> a.getContractUID().compareTo(b.getContractUID());
		Collections.sort(injectionScheduleBOs, comparator);
		
		return injectionScheduleBOs;
	}

	@Override
	public ContractDefination findContractDefinition(int injectorUtgId, int draweeUtgId, Date forDate) throws BusinessException, Exception {
		return contractDefinitionDao.findContractDefinition(injectorUtgId, draweeUtgId, forDate);
	}
}
