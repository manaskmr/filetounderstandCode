
package in.hertz.samast.service;

import java.util.Date;
import java.util.List;
import java.util.Map;

import in.hertz.samast.domain.DraftDTO;
import in.hertz.samast.domain.InjectionScheduleBO;
import in.hertz.samast.domain.InjectionScheduleQueryParamDto;
import in.hertz.samast.domain.InjectionScheduleSummaryBO;
import in.hertz.samast.domain.PSSDetailsDTO;
import in.hertz.samast.domain.SldcApproveBo;
import in.hertz.samast.domain.exception.BusinessException;
import in.hertz.samast.entity.Draft;
import in.hertz.samast.entity.InjectionSchedule;
import in.hertz.samast.entity.InjectionScheduleSummary;
import in.hertz.samast.entity.TimeInterval;

/**
 * 
 * @author Bibhuti Parida
 * @author Dipu Kumar
 * 
 */
public interface InjectionScheduleService {

	public List<PSSDetailsDTO> getPSSListByQCAId(int qcaUtgId) throws Exception, BusinessException;

	public List<InjectionScheduleBO> getPSSSummary(Date forDate, int qcaUtgId) throws Exception, BusinessException;

	public InjectionScheduleBO getInjectionScheduleByUTG(Date forDate, int utgId) throws Exception, BusinessException;

	public InjectionScheduleBO getInjectionScheduleByRevisionNo(Date forDate, int utgId, int revsionNo)
			throws Exception, BusinessException;

	public TimeInterval getCurrentTimeBlock() throws Exception, BusinessException;

	public Integer getExBusCapacity(int utgId) throws Exception, BusinessException;

	public List<Integer> getRevisionNoByScheduleType(Date forDate, int utgId, String scheduleType)
			throws Exception, BusinessException;

	public List<Integer> getAllRevisionNo(Date forDate, int utgId) throws Exception, BusinessException;

	public Integer getLatestRevisionNoByUTG(Date forDate, int utgId) throws Exception, BusinessException;

	public Draft<InjectionScheduleBO> saveDraft(DraftDTO<InjectionScheduleBO> draftDTO)
			throws Exception, BusinessException;

	public Draft<InjectionScheduleBO> fetchDraftData(Date forDate, int utgId) throws Exception, BusinessException;

	public InjectionScheduleBO newInjectionSchedule(Date forDate, int utgId) throws Exception, BusinessException;

	public InjectionScheduleBO saveInjectionSchedule(InjectionScheduleBO ursBO) throws Exception, BusinessException;
	
	public InjectionSchedule makeInjectionSchedule(InjectionScheduleBO injectionScheduleBO) throws BusinessException, Exception;
	
	public InjectionScheduleSummary makeInjectionScheduleSummary(InjectionScheduleBO injectionScheduleBO) throws BusinessException, Exception;
	
	public boolean saveInjectionScheduleData(List<InjectionScheduleBO> injectionScheduleBOs) throws BusinessException, Exception;
	
	public boolean saveInjectionScheduleDataAsDraft(List<InjectionScheduleBO> injectionScheduleBOs) throws BusinessException, Exception;
	
	public Integer findLatestRevision(int utgId, Date date, String schType) throws BusinessException, Exception;
	
	public List<Draft<InjectionScheduleBO>> findDraftedInjectionSchedule(int gencoUtgId, Date forDate,int revision) throws BusinessException, Exception;

	public List<InjectionScheduleSummaryBO> getInjectionSummaryListByQCAId(int qcaUtgId, Date forDate) throws Exception, BusinessException;

	public List<InjectionScheduleBO> viewInjectionScheduleBySourceNameUtgIdsAndQcaUtgIds(SldcApproveBo sldcApproveBo) throws Exception, BusinessException;

	public InjectionScheduleBO getInjectionScheduleByRevisionNoScheduleType(Date forDate, int utgId, int revisionNo, String scheduleType) throws Exception, BusinessException;

	public String getScheduletype(int utgId, Date forDate, int revisionNo) throws Exception, BusinessException;

	public List<InjectionScheduleBO> viewInjectionScheduleByUtgIdAndRevisionNo(SldcApproveBo sldcApproveBo) throws Exception, BusinessException;

	public List<InjectionScheduleBO> getLatestRevisionDetailsBySourceName(SldcApproveBo sldcApproveBo) 
			throws Exception, BusinessException;

	public InjectionScheduleBO editInjectionScheduleByRevisionNoAndUtgId(SldcApproveBo sldcApproveBo) 
			throws Exception, BusinessException;


	public Map<String, List> getInjectionScheduleContractTypeQuantums1(InjectionScheduleQueryParamDto injectionScheduleQueryParamDto) throws BusinessException,Exception;

}
