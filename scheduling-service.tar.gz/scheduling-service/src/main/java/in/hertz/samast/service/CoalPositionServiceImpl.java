package in.hertz.samast.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import javax.transaction.Transactional;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import in.hertz.samast.config.BusinessErrorPropertyConfig;
import in.hertz.samast.dao.CoalPositionDao;
import in.hertz.samast.dao.DraftRepository;
import in.hertz.samast.dao.UtilitiesTraderGencoRepository;
import in.hertz.samast.domain.CoalPositionBO;
import in.hertz.samast.domain.DraftDTO;
import in.hertz.samast.domain.exception.BusinessException;
import in.hertz.samast.entity.Draft;
import in.hertz.samast.entity.TimeInterval;
import in.hertz.samast.entity.UtilitiesTraderGenco;
import in.hertz.samast.entity.coalposition.CoalPosition;
import in.hertz.samast.util.EPMDateUtils;


@Service
@Transactional
@ComponentScan(basePackages = "in.hertz.samast.config")
public class CoalPositionServiceImpl implements CoalPositionService {

	@Autowired
	private CoalPositionDao coalPositionDao;
	
	@Autowired
	private UtilitiesTraderGencoRepository utilitiesTraderGencoRepository;

	@Autowired
	private DraftRepository<CoalPositionBO> draftRepoistoryDao;
	
	@Autowired
	private TimeIntervalService timeIntervalService;
	
	@Autowired
	private BusinessErrorPropertyConfig bepc;

	private static final String DATE_FORMAT_YEAR_MONTH_DAY = "yyyy-MM-dd";
	
	private static final String TWELVEAM = "00:00 a";
	private static final String ONEAM = "01:00 a";
	
	private final ObjectMapper mapper = new ObjectMapper(); 
	
	/**
	 * This method initiate add new coal position
	 */
	@Override
	public CoalPositionBO newCoalPosition(Date forDate, int utgId) throws BusinessException {
		Draft<CoalPositionBO> coalPosDraft = getDraftedCoalPositionByDateAndUtgId(forDate, utgId);
		if (Objects.nonNull(coalPosDraft)) {
			return coalPosDraft.getData();
		} else {
			return new CoalPositionBO();
		}
	}
	
	/**
	 * This method save the coal position
	 */
	@Override
	public CoalPositionBO saveCoalPosition(CoalPositionBO coalPositionBO) throws BusinessException, ParseException {

//		if (!checkIssueTimeIsBetweenTheLimits()) {
//			throw new BusinessException("The issue time should be within 12.00 AM and 01:00 AM");
//		}
		
//		if (!checkInputDateIsEqualToPreviousDate(coalPositionBO.getForDate())) {
//			throw new BusinessException("The input date should be equal to the the day previous to the current date.");
//		}
		
		CoalPositionBO existCoalPos = getCoalPositionByDate(coalPositionBO.getForDate(), coalPositionBO.getUtgId());
		
		if (Objects.nonNull(existCoalPos)) {
			throw new BusinessException(bepc.getCoalpofordate());
		}
		
		CoalPosition  coalPosition = convertCoalPositionBO(new CoalPosition(), coalPositionBO);
		CoalPosition  coalPositionNew = coalPositionDao.save(coalPosition);
		
		//Update existing Draft data
		Draft<CoalPositionBO> existDraft = getDraftedCoalPositionByDateAndUtgId(coalPositionBO.getForDate(), coalPositionBO.getUtgId());
		if (Objects.nonNull(existDraft)) {
			existDraft.setStatus("COMPLETED");
			draftRepoistoryDao.save(existDraft);
		}
		
		return Objects.nonNull(coalPositionNew) ? coalPositionBO : null;
	}

	/**
	 * This method retrieves all coal position
	 */
	@Override
	public List<CoalPositionBO> getAllCoalPositions() throws BusinessException {
		List<CoalPositionBO> coalPosBOList = null;
		List<CoalPosition> coalPosList = coalPositionDao.findAll();
		if(CollectionUtils.isNotEmpty(coalPosList)) {
			coalPosBOList = new ArrayList<CoalPositionBO>();
			for (CoalPosition coalPosition : coalPosList) {
				CoalPositionBO coalPositionBO = convertCoalPositionBO(coalPosition);
				coalPosBOList.add(coalPositionBO);
			}
		}
		return coalPosBOList;
	}
	
	/**
	 * This method gets coal position based on date and utgid
	 */
	@Override
	public CoalPositionBO getCoalPositionByDate(Date date, int utgId) throws BusinessException, ParseException {
//		if (!checkIssueTimeIsBetweenTheLimits()) {
//		throw new BusinessException("The issue time should be within 12.00 AM and 01:00 AM");
//	}
	
//	if (!checkInputDateIsEqualToPreviousDate(date)) {
//		throw new BusinessException("The input date should be equal to the the day previous to the current date.");
//	}
		CoalPosition coalPosition = coalPositionDao.findCoalPositionByDate(date, utgId);
		CoalPositionBO coalPositionBO = null;
		if(Objects.nonNull(coalPosition)) {
			coalPositionBO = convertCoalPositionBO(coalPosition);
		}
		return coalPositionBO;
	}

	/**
	 * This method converting entity to DTO
	 * @param coalPosition
	 * @return
	 */
	private CoalPositionBO convertCoalPositionBO(CoalPosition coalPosition) {
		CoalPositionBO coalPositionBO = new CoalPositionBO();
		
		coalPositionBO.setCoalPositionId(coalPosition.getCoalPositionId());
		coalPositionBO.setIssueDate(coalPosition.getIssueDate());
		coalPositionBO.setForDate(coalPosition.getDate());
		coalPositionBO.setGeneratorName(coalPosition.getUtilitiesTraderGenco().getName());
		coalPositionBO.setOpeningBalance(coalPosition.getOpeningBalance());
		coalPositionBO.setCoalReceived(coalPosition.getCoalReceived());
		coalPositionBO.setCoalConsumed(coalPosition.getCoalConsumed());
		coalPositionBO.setClosingBalance(coalPosition.getClosingBalance());
		coalPositionBO.setStockSufficient(Objects.nonNull(coalPosition.getStockSufficient()) ? coalPosition.getStockSufficient() : 0);
		coalPositionBO.setUtgId(coalPosition.getUtilitiesTraderGenco().getUID());
		
		return coalPositionBO;
	}
	
	/**
	 * This method converting DTO to entity
	 * @param coalPosition
	 * @return
	 */
	private CoalPosition convertCoalPositionBO(CoalPosition coalPosition, CoalPositionBO coalPositionBO) {
		coalPosition.setClosingBalance(coalPositionBO.getClosingBalance());
		coalPosition.setCoalConsumed(coalPositionBO.getCoalConsumed());
		coalPosition.setCoalReceived(coalPositionBO.getCoalReceived());
		coalPosition.setOpeningBalance(coalPositionBO.getOpeningBalance());
		coalPosition.setStockSufficient(coalPositionBO.getStockSufficient());
		coalPosition.setIssueDate(new Date());
		coalPosition.setDate(coalPositionBO.getForDate());
		UtilitiesTraderGenco utilitiesTraderGenco = utilitiesTraderGencoRepository.getById(coalPositionBO.getUtgId());
		coalPosition.setUtilitiesTraderGenco(utilitiesTraderGenco);
		
		return coalPosition;
	}
	
	/**
	 * This method is updating coal position
	 */
	@Override
	public CoalPositionBO updateCoalPosition(CoalPositionBO coalPositionBO)  throws BusinessException, ParseException {
//		if (!checkIssueTimeIsBetweenTheLimits()) {
//			throw new BusinessException("The issue time should be within 12.00 AM and 01:00 AM");
//		}
		
//		if (!checkInputDateIsEqualToPreviousDate(coalPositionBO.getForDate())) {
//			throw new BusinessException("The input date should be equal to the the day previous to the current date.");
//		}
		CoalPosition coalPosition = coalPositionDao.findCoalPositionByDate(coalPositionBO.getForDate(), coalPositionBO.getUtgId());
        Optional<CoalPosition> opCoalPosition = coalPositionDao.findById(coalPositionBO.getCoalPositionId());
		
		if(Objects.nonNull(coalPosition)) {
			coalPosition = convertCoalPositionBO(coalPosition, coalPositionBO);
			coalPositionDao.save(coalPosition);
			coalPositionBO = convertCoalPositionBO(coalPosition);

		} else {
			coalPositionBO = null;
		}
		return coalPositionBO;
	}


	/**
	 * This method ensures that coal position is updated only between 12 AM and 1 AM on a particular day. If not, throws exception
	 * @return
	 * @throws ParseException
	 */
	private boolean checkIssueTimeIsBetweenTheLimits() throws ParseException {
		SimpleDateFormat parser = new SimpleDateFormat("hh:mm");
		Date twelveAm = parser.parse(TWELVEAM);
		Date oneAm = parser.parse(ONEAM);
		String time = parser.format(new Date());
	    Date userDate = parser.parse(time);

	    if (!(userDate.after(twelveAm) && userDate.before(oneAm))) {
	       return false;
	    } else {
	    	return true;
	    }
	}
	
	/**
	 * This method ensures that coal position is allowed to be updated for the previous day.
	 * @param forDate
	 * @return
	 * @throws ParseException
	 */
	private boolean checkInputDateIsEqualToPreviousDate(Date forDate) throws ParseException {
		SimpleDateFormat formatter  =  new SimpleDateFormat(DATE_FORMAT_YEAR_MONTH_DAY);
		String date = formatter.format(forDate);
		Date d1 = formatter.parse(date);
		Date prevDate = EPMDateUtils.getPreviousDate();
		
		if((d1.compareTo(prevDate)==0) ){
			return true;
		} 
		return false;
	}
	
	/**
	 * This method save the coal position in draft
	 */
	@Override
	public Draft<CoalPositionBO> saveAsDraft(DraftDTO<CoalPositionBO> draftDTO) throws BusinessException, ParseException{
		Draft<CoalPositionBO> draft = null;
		SimpleDateFormat sdf =new SimpleDateFormat(DATE_FORMAT_YEAR_MONTH_DAY);
		String strdate = sdf.format(draftDTO.getJsonDTO().getForDate());
		
//		if (!checkIssueTimeIsBetweenTheLimits()) {
//			throw new BusinessException("The issue time should be within 12.00 AM and 01:00 AM");
//		}
		
//		if (!checkInputDateIsEqualToPreviousDate(draftDTO.getJsonDTO().getForDate())) {
//			throw new BusinessException("The input date should be equal to the the day previous to the current date.");
//		}
		
		List<Draft<CoalPositionBO>> listDraft = draftRepoistoryDao.findDraftByDate(draftDTO.getJsonDTO().getUtgId(), strdate);
		Draft<CoalPositionBO> existDraft = null;
		
		if(CollectionUtils.isNotEmpty(listDraft)) {
			existDraft = listDraft.get(0);
			
			existDraft.setCreatedBy(draftDTO.getCreatedBy());
			existDraft.setInsertTime(new Date());
			existDraft.setCurrentStage(draftDTO.getCurrentStage());
			existDraft.setStatus(draftDTO.getStatus());
			existDraft.setFunctionalityArea(draftDTO.getFunctionalityArea());
			if (Objects.nonNull(draftDTO.getJsonDTO())) {
				existDraft.setData(draftDTO.getJsonDTO());
			}
			draftRepoistoryDao.save(existDraft);
			return existDraft;
		} else {	
			if (Objects.nonNull(draftDTO)) {
				draft = new Draft<>();
				draft.setCreatedBy(draftDTO.getCreatedBy());
				draft.setInsertTime(new Date());
				draft.setCurrentStage(draftDTO.getCurrentStage());
				draft.setStatus(draftDTO.getStatus());
				draft.setFunctionalityArea(draftDTO.getFunctionalityArea());
				if (draftDTO.getJsonDTO() != null) {
					draft.setData(draftDTO.getJsonDTO());
				}
				draftRepoistoryDao.save(draft);
			}
		}
		return draft;
	}
	
	
	/**
	 * This method retrieves draft data of coal position
	 */
	@Override
	public Draft<CoalPositionBO> getDraftedCoalPositionByDateAndUtgId(Date forDate, int utgId)
			throws BusinessException {
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
		String strForDate = sdf.format(forDate);
		List<Draft<CoalPositionBO>> listDraft = draftRepoistoryDao.findDraftByDate(utgId, strForDate);

		List<Draft<CoalPositionBO>> pojoDraftList = mapper.convertValue(listDraft,
				new TypeReference<List<Draft<CoalPositionBO>>>() {
				});

		return (CollectionUtils.isNotEmpty(pojoDraftList)) ? pojoDraftList.get(0) : null;
	}
	
	/**
	 * This method returns the current time block number
	 * @return
	 * @throws ParseException
	 */
	@Override
	public TimeInterval getCurrentTimeBlock()  throws Exception, BusinessException {
		return timeIntervalService.getCurrentTimeBlock();
	}
}