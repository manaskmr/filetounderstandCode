package in.hertz.samast.service;

import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;

import javax.transaction.Transactional;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.hertz.samast.dao.DeclareCapacityDetailsRepository;
import in.hertz.samast.dao.DeclareCapacityRepository;
import in.hertz.samast.dao.InjectionScheduleSummaryDetailRepository;
import in.hertz.samast.dao.InjectionScheduleSummaryRepository;
import in.hertz.samast.dao.PSSRepository;
import in.hertz.samast.dao.UtilitiesTraderGencoRepository;
import in.hertz.samast.domain.InjectionScheduleBO;
import in.hertz.samast.domain.InjectionScheduleDetailBO;
import in.hertz.samast.domain.ScheduleQuantumBaseDTO;
import in.hertz.samast.domain.ScheduleQuantumDTO;
import in.hertz.samast.domain.exception.BusinessException;
import in.hertz.samast.entity.DeclareCapability;
import in.hertz.samast.entity.DeclareCapabilityDetails;
import in.hertz.samast.entity.InjectionScheduleSummary;
import in.hertz.samast.entity.InjectionScheduleSummaryDetail;
import in.hertz.samast.entity.UtilitiesTraderGenco;

@Service(value = "sldcApprovalService")
@Transactional
public class SldcApprovalServiceImpl implements SldcApprovalService {

	@Autowired
	private UtilitiesTraderGencoRepository utilitiesTraderGencoRepository;

	@Autowired
	private DeclareCapacityService declareCapacityService;
	
	@Autowired
	private InjectionScheduleService injectionScheduleService;

	@Autowired
	private DeclareCapacityRepository declareCapacityRepository;

	@Autowired
	private DeclareCapacityDetailsRepository declareCapacityDetailsRepository;
	
	@Autowired
	private InjectionScheduleSummaryRepository injectionScheduleSummaryRepository;
	
	@Autowired
	private InjectionScheduleSummaryDetailRepository injectionScheduleSummaryDetailRepository;

	@Autowired
	private TimeIntervalService timeIntervalService;
	
	@Autowired
	private PSSRepository pSSRepository;
	
	@Autowired
	private InjectionScheduleServiceImpl injectionScheduleServiceImpl;

	@Override
	public boolean approveDcBySldc(ScheduleQuantumBaseDTO ursBO) throws Exception, BusinessException {
		boolean status = false;
		int noOfTimeBlock;
		Integer utgId = ursBO.getSellerUTGId();
		Date forDate = ursBO.getForDate();
		int revisionNo = ursBO.getRevision();
		int latestRevisionNo = declareCapacityService.getLatestRevisionNoByUTG(forDate, utgId);
		ScheduleQuantumBaseDTO dcOfLatest = declareCapacityService.getDeclaredCapacityByUTG(forDate, utgId, revisionNo);
		List<ScheduleQuantumDTO> dcOfLatestDetails = sortQuantumList(dcOfLatest.getQuantumList());
		List<ScheduleQuantumDTO> dcDetailBOs = sortQuantumList(ursBO.getQuantumList());
		Set<DeclareCapabilityDetails> dcDetailList = new HashSet<>();
		DeclareCapability dc = new DeclareCapability();
		if (utilitiesTraderGencoRepository.findById(utgId).isPresent()) {
			UtilitiesTraderGenco utg = utilitiesTraderGencoRepository.findById(utgId).get();
			dc.setUtilitiesTraderGenco(utg);
		}

		dc.setApprovedDate(new Date());
		dc.setForDate(forDate);
		dc.setIssueDate(dcOfLatest.getIssueDate());
		dc.setDataSource(dcOfLatest.getDataSource());

		noOfTimeBlock = timeIntervalService.findMaxBlock();
		for (int i = 0; i < noOfTimeBlock; i++) {
			if ((dcOfLatestDetails.get(i).getOffBarQuantum().doubleValue() != dcDetailBOs.get(i).getOffBarQuantum()
					.doubleValue())
					|| (dcOfLatestDetails.get(i).getOnBarQuantum().doubleValue() != dcDetailBOs.get(i).getOnBarQuantum()
							.doubleValue())) {
				for (ScheduleQuantumDTO bqDTO : dcDetailBOs) {
					DeclareCapabilityDetails dcDetail = new DeclareCapabilityDetails();
					dcDetail.setQuantumOffBar(bqDTO.getOffBarQuantum());
					dcDetail.setQuantumOnBar(bqDTO.getOnBarQuantum());
					dcDetail.setQuantumOfPower(bqDTO.getSellerDcQuantum());
					dcDetail.setTimeIntervalId(bqDTO.getTimeBlock());
					dcDetail.setDeclareCapability(dc);
					dcDetailList.add(dcDetail);
				}
				dc.setCapabilityDetails(dcDetailList);
				dc.setRevision(++latestRevisionNo);
				declareCapacityRepository.save(dc);
				declareCapacityDetailsRepository.saveAll(dcDetailList);
				status = true;
				break;
			}
		}
		return status;
	}

	private List<ScheduleQuantumDTO> sortQuantumList(List<ScheduleQuantumDTO> dcQuantumList) {
		if (Objects.nonNull(dcQuantumList) && !dcQuantumList.isEmpty()) {
			Comparator<ScheduleQuantumDTO> timeBlockSorter = (a, b) -> a.getTimeBlock().compareTo(b.getTimeBlock());
			Collections.sort(dcQuantumList, timeBlockSorter);
		}
		return dcQuantumList;
	}

	@Override
	public ScheduleQuantumBaseDTO rejectDcBySldc(ScheduleQuantumBaseDTO ursBO) throws Exception, BusinessException {
		if (Objects.nonNull(ursBO.getRemarks())) {
			DeclareCapability dc = declareCapacityRepository.getDeclaredCapacityByRevision(ursBO.getSellerUTGId(),
					ursBO.getForDate(), ursBO.getRevision());
			if (Objects.nonNull(dc)) {
				dc.setRemarks(ursBO.getRemarks());
				declareCapacityRepository.save(dc);
			}
		}
		return ursBO;
	}

	@Override
	public boolean sldcApproveInjectionSchedule(InjectionScheduleBO ursBO) throws Exception, BusinessException {
		boolean status = false;
		int noOfTimeBlock;
		Integer utgId = ursBO.getInjectionUtgId();
		Date forDate = ursBO.getForDate();
		int revisionNo = ursBO.getRevisionNumber();
		int latestRevisionNo = injectionScheduleService.getLatestRevisionNoByUTG(forDate, utgId);
		InjectionScheduleBO reOfLatest = injectionScheduleService.getInjectionScheduleByRevisionNo(forDate, utgId,
				revisionNo);
		ScheduleQuantumBaseDTO dcOfLatest = declareCapacityService.getDeclaredCapacityByUTG(forDate, utgId, revisionNo);
		List<ScheduleQuantumDTO> dcOfLatestDetails = sortQuantumList(dcOfLatest.getQuantumList());
		
		
		List<InjectionScheduleDetailBO> reOfLatestDetails = sortInjectionScheduleQuantumList(
				reOfLatest.getInjectionScheduleDetail());
		List<InjectionScheduleDetailBO> reDetailBOs = sortInjectionScheduleQuantumList(
				ursBO.getInjectionScheduleDetail());
		Set<InjectionScheduleSummaryDetail> injectionScheduleSummaryDetailSet = new HashSet<>();
		InjectionScheduleSummary injectionScheduleSummary = new InjectionScheduleSummary();
		Set<DeclareCapabilityDetails> dcDetailList = new HashSet<>();
		DeclareCapability dc = new DeclareCapability();
		if (utilitiesTraderGencoRepository.findById(utgId).isPresent()) {
			UtilitiesTraderGenco utg = utilitiesTraderGencoRepository.findById(utgId).get();
			injectionScheduleSummary.setInjectorUTG(utg);
			dc.setUtilitiesTraderGenco(utg);
		}
		injectionScheduleSummary.setApprovedDate(new Date());
		dc.setApprovedDate(new Date());
		injectionScheduleSummary.setForDate(forDate);
		dc.setForDate(forDate);
		injectionScheduleSummary.setIssueDate(reOfLatest.getIssueDate());
		dc.setIssueDate(reOfLatest.getIssueDate());
		injectionScheduleSummary.setRemarks(ursBO.getRemarks());
		dc.setRemarks(ursBO.getRemarks());
		
		noOfTimeBlock = timeIntervalService.findMaxBlock();
		for (int i = 0; i < noOfTimeBlock; i++) {
			if (reOfLatestDetails.get(i).getQuantum().doubleValue() != reDetailBOs.get(i).getQuantum().doubleValue()){
				for (InjectionScheduleDetailBO bqDTO : reDetailBOs) {
					InjectionScheduleSummaryDetail injectionScheduleSummaryDetail = new InjectionScheduleSummaryDetail();
					injectionScheduleSummaryDetail.setQuantum(bqDTO.getQuantum());
					injectionScheduleSummaryDetail
							.setTimeInterval(timeIntervalService.findByBlock(bqDTO.getTimeIntervalId()));
					injectionScheduleSummaryDetail.setInjectionScheduleSummary(injectionScheduleSummary);
					injectionScheduleSummaryDetailSet.add(injectionScheduleSummaryDetail);
					
					DeclareCapabilityDetails dcDetail = new DeclareCapabilityDetails();
					dcDetail.setQuantumOffBar(0.0f);
					dcDetail.setQuantumOnBar(bqDTO.getAvailableCapacity());
					dcDetail.setQuantumOfPower(bqDTO.getAvailableCapacity());
					dcDetail.setTimeIntervalId(bqDTO.getTimeIntervalId());
					dcDetail.setDeclareCapability(dc);
					dcDetailList.add(dcDetail);
				}
				int rivisionNo = latestRevisionNo+1;
				dc.setRevision(rivisionNo);
				dc.setCapabilityDetails(dcDetailList);
				declareCapacityRepository.save(dc);
				declareCapacityDetailsRepository.saveAll(dcDetailList);
				
				injectionScheduleSummary.setInjectionScheduleSummaryDetail(injectionScheduleSummaryDetailSet);
				injectionScheduleSummary.setRevision(rivisionNo);
				injectionScheduleSummaryRepository.save(injectionScheduleSummary);
				injectionScheduleSummaryDetailRepository.saveAll(injectionScheduleSummaryDetailSet);
				status = true;
				break;
			}
		}

		return status;
	}

	private List<InjectionScheduleDetailBO> sortInjectionScheduleQuantumList(
			List<InjectionScheduleDetailBO> isQuantumList) {
		if (CollectionUtils.isNotEmpty(isQuantumList)) {
			Comparator<InjectionScheduleDetailBO> timeBlockSorter = (a, b) -> a.getTimeIntervalId()
					.compareTo(b.getTimeIntervalId());
			Collections.sort(isQuantumList, timeBlockSorter);
		}
		return isQuantumList;
	}

	@Override
	public InjectionScheduleBO sldcRejectInjectionSchedule(InjectionScheduleBO ursBO) throws Exception, BusinessException {
		if (Objects.nonNull(ursBO.getRemarks())) {
			List<InjectionScheduleSummary> isSummary = injectionScheduleSummaryRepository
					.getInjectionScheduleSummaryLatestRevision(ursBO.getInjectionUtgId(), ursBO.getForDate(),
							ursBO.getRevisionNumber());
			if (CollectionUtils.isNotEmpty(isSummary)) {
				InjectionScheduleSummary is = isSummary.get(0);

				is.setRemarks(ursBO.getRemarks());
				injectionScheduleSummaryRepository.save(is);
			}
			
			if (Objects.nonNull(ursBO.getRemarks())) {
				DeclareCapability dc = declareCapacityRepository.getDeclaredCapacityByRevision(ursBO.getInjectionUtgId(),
						ursBO.getForDate(), ursBO.getRevisionNumber());
				if (Objects.nonNull(dc)) {
					dc.setRemarks(ursBO.getRemarks());
					declareCapacityRepository.save(dc);
				}
			}
		}

		return ursBO;
	}
	
	

}
