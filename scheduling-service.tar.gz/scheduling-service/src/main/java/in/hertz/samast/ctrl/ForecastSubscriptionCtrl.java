/**
 * 
 */
package in.hertz.samast.ctrl;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Objects;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.hertz.samast.config.ForecastSubscriptionExcelExporter;
import in.hertz.samast.domain.ForecastSubscriptionBO;
import in.hertz.samast.domain.ForecastSubscriptionUsagesBO;
import in.hertz.samast.domain.PSSDetailsDTO;
import in.hertz.samast.domain.WSResp;
import in.hertz.samast.domain.exception.BusinessException;
import in.hertz.samast.service.ForecastSubscriptionService;

/**
 * @author Bibhuti Parida
 *
 */
@RestController
@RequestMapping("/forecast-subscription")
public class ForecastSubscriptionCtrl {
	
	@Autowired
	private ForecastSubscriptionService forecastSubscriptionService;
	
	@GetMapping("/pssByQCAId/{qcaUtgId}")
	public ResponseEntity<WSResp<List<PSSDetailsDTO>>> getPSSListByQCAId(@PathVariable("qcaUtgId") int qcaUtgId)
			throws Exception, BusinessException {
		List<PSSDetailsDTO> pssBOList = forecastSubscriptionService.getPSSListByQCAId(qcaUtgId);

		if (CollectionUtils.isNotEmpty(pssBOList)) {
			return new ResponseEntity<WSResp<List<PSSDetailsDTO>>>(
					new WSResp<List<PSSDetailsDTO>>(pssBOList, true, "PSS Data Fetched Successfully!"), HttpStatus.OK);
		} else {
			return new ResponseEntity<WSResp<List<PSSDetailsDTO>>>(
					new WSResp<List<PSSDetailsDTO>>(pssBOList , false, "PSS not found for QCA"),
					HttpStatus.OK);
		}
	}
	
	@GetMapping("/forecastSubscriptionListByPSSId/{pssUtgId}")
	public ResponseEntity<WSResp<List<ForecastSubscriptionBO>>> getForecastSubscriptionListByPSSId(@PathVariable("pssUtgId") int pssUtgId)
			throws Exception, BusinessException {
		List<ForecastSubscriptionBO> forecastSubscriptionBOList = forecastSubscriptionService.getForecastSubscriptionListByPSSId(pssUtgId);

		if (CollectionUtils.isNotEmpty(forecastSubscriptionBOList)) {
			return new ResponseEntity<WSResp<List<ForecastSubscriptionBO>>>(
					new WSResp<List<ForecastSubscriptionBO>>(forecastSubscriptionBOList, true, "Forecast Subscription Data Fetched Successfully!"), HttpStatus.OK);
		} else {
			return new ResponseEntity<WSResp<List<ForecastSubscriptionBO>>>(
					new WSResp<List<ForecastSubscriptionBO>>(forecastSubscriptionBOList , false, "Forecast Subscription not found for PSS Utg ID"),
					HttpStatus.OK);
		}
	}
	
	@GetMapping("/forecastSubscriptionByPSSId/{pssUtgId}")
	public ResponseEntity<WSResp<List<ForecastSubscriptionBO>>> getForecastSubscriptionByPSSId(@PathVariable("pssUtgId") int pssUtgId)
			throws Exception, BusinessException {
		List<ForecastSubscriptionBO> forecastSubscriptionBOList = forecastSubscriptionService.getForecastSubscriptionByPSSId(pssUtgId);

		if (CollectionUtils.isNotEmpty(forecastSubscriptionBOList)) {
			return new ResponseEntity<WSResp<List<ForecastSubscriptionBO>>>(
					new WSResp<List<ForecastSubscriptionBO>>(forecastSubscriptionBOList, true, "Forecast Subscription Data Fetched Successfully!"), HttpStatus.OK);
		} else {
			return new ResponseEntity<WSResp<List<ForecastSubscriptionBO>>>(
					new WSResp<List<ForecastSubscriptionBO>>(forecastSubscriptionBOList , false, "Forecast Subscription not found for PSS Utg ID"),
					HttpStatus.OK);
		}
	}
	
	@GetMapping("/forecastSubscriptionDetailByPSSId/{pssUtgId}/{forDate}")
	public ResponseEntity<WSResp<List<ForecastSubscriptionUsagesBO>>> getForecastSubscriptionDetailByPSSId(@PathVariable("pssUtgId") int pssUtgId,
			@PathVariable("forDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date forDate)
			throws Exception, BusinessException {
		List<ForecastSubscriptionUsagesBO> fsUsagesBOList = forecastSubscriptionService.getForecastSubscriptionDetailByPSSId(pssUtgId, forDate);

		if (CollectionUtils.isNotEmpty(fsUsagesBOList)) {
			return new ResponseEntity<WSResp<List<ForecastSubscriptionUsagesBO>>>(
					new WSResp<List<ForecastSubscriptionUsagesBO>>(fsUsagesBOList, true, "Forecast Subscription usages Data Fetched Successfully!"), HttpStatus.OK);
		} else {
			return new ResponseEntity<WSResp<List<ForecastSubscriptionUsagesBO>>>(
					new WSResp<List<ForecastSubscriptionUsagesBO>>(fsUsagesBOList , false, "Forecast Subscription usages not found for PSS Utg ID"),
					HttpStatus.OK);
		}
	}
	
	@PostMapping("/saveForecastSubscription")
	public ResponseEntity<WSResp<ForecastSubscriptionBO>> saveForecastSubscription(@RequestBody ForecastSubscriptionBO fsBO)
			throws Exception, BusinessException {
		ForecastSubscriptionBO forecastSubscriptionBO = forecastSubscriptionService.saveForecastSubscription(fsBO);

		if (Objects.nonNull(forecastSubscriptionBO)) {
			return new ResponseEntity<WSResp<ForecastSubscriptionBO>>(
					new WSResp<ForecastSubscriptionBO>(forecastSubscriptionBO, true, "Forecast Subscription Data saved Successfully!"), HttpStatus.OK);
		} else {
			return new ResponseEntity<WSResp<ForecastSubscriptionBO>>(
					new WSResp<ForecastSubscriptionBO>(forecastSubscriptionBO , false, "Forecast Subscription not saved"),
					HttpStatus.OK);
		}
	}

	@GetMapping("/newFS/{pssUtgId}/{noOfDays}")
	public ResponseEntity<WSResp<ForecastSubscriptionBO>> newFS(@PathVariable("pssUtgId") int pssUtgId, @PathVariable("noOfDays") int noOfDays)
			throws Exception, BusinessException {
		ForecastSubscriptionBO forecastSubscriptionBO = forecastSubscriptionService.newFS(pssUtgId, noOfDays);

		if (Objects.nonNull(forecastSubscriptionBO)) {
			return new ResponseEntity<WSResp<ForecastSubscriptionBO>>(
					new WSResp<ForecastSubscriptionBO>(forecastSubscriptionBO, true, "Forecast Subscription Data Fetched Successfully!"), HttpStatus.OK);
		} else {
			return new ResponseEntity<WSResp<ForecastSubscriptionBO>>(
					new WSResp<ForecastSubscriptionBO>(forecastSubscriptionBO , false, "Forecast Subscription not found for PSS ID"),
					HttpStatus.OK);
		}
	}
	
	@PostMapping("/updateForecastSubscriptionUsages")
	public ResponseEntity<WSResp<ForecastSubscriptionUsagesBO>> updateForecastSubscription(@RequestBody ForecastSubscriptionUsagesBO fsuBO)
			throws Exception, BusinessException {
		ForecastSubscriptionUsagesBO fsUsagesBO = forecastSubscriptionService.updateForecastSubscription(fsuBO);

		if (Objects.nonNull(fsUsagesBO)) {
			return new ResponseEntity<WSResp<ForecastSubscriptionUsagesBO>>(
					new WSResp<ForecastSubscriptionUsagesBO>(fsUsagesBO, true, "Forecast Subscription Usages Data updated Successfully!"), HttpStatus.OK);
		} else {
			return new ResponseEntity<WSResp<ForecastSubscriptionUsagesBO>>(
					new WSResp<ForecastSubscriptionUsagesBO>(fsUsagesBO , false, "Forecast Subscription usages not updated"),
					HttpStatus.OK);
		}
	}
	
    @GetMapping("/export/excel/{pssUtgId}/{forDate}")
    public void exportToExcel(HttpServletResponse response, @PathVariable("pssUtgId") int pssUtgId,
			@PathVariable("forDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date forDate) throws Exception, BusinessException  {
        response.setContentType("application/octet-stream");
        DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH:mm:ss");
        String currentDateTime = dateFormatter.format(new Date());
         
        String headerKey = "Content-Disposition";
        String headerValue = "attachment; filename=forcastSubscription_" + currentDateTime + ".xlsx";
        response.setHeader(headerKey, headerValue);
        List<ForecastSubscriptionUsagesBO> fsUsagesBOList = forecastSubscriptionService.getForecastSubscriptionDetailByPSSId(pssUtgId, forDate);
        ForecastSubscriptionExcelExporter excelExporter = new ForecastSubscriptionExcelExporter(fsUsagesBOList);
         
        excelExporter.export(response);    
    } 
}
