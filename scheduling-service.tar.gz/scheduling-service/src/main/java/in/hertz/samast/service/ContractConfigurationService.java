package in.hertz.samast.service;

import java.util.List;
import java.util.Map;

import in.hertz.samast.domain.ContractConfigurationSearchDto;
import in.hertz.samast.domain.ContractDefinitionDto;
import in.hertz.samast.domain.Page;
import in.hertz.samast.domain.UtilityTraderGencoDTO;
import in.hertz.samast.domain.exception.BusinessException;

public interface ContractConfigurationService {
	
	public boolean addConfigurationContract(ContractDefinitionDto configurationDto) throws BusinessException, Exception;
	public List<ContractDefinitionDto>viewAllContractConfigurationDto() throws BusinessException, Exception;
	
	public List<ContractDefinitionDto> findAllContractDefinitionByParams(
			ContractConfigurationSearchDto contractConfigurationSearchDto, int pageNo, int pageSize) throws BusinessException, Exception;
	
	public Page<List<ContractDefinitionDto>> findAllPagedContractDefinitionByParams (
			ContractConfigurationSearchDto contractConfigurationSearchDto, int pageNo, int pageSize) throws BusinessException, Exception;
	public boolean saveAsDraft(ContractDefinitionDto ContractDefinitionDto)throws BusinessException;
	
	public ContractDefinitionDto getDraftContractConfiguration(String approvalNo) throws BusinessException, Exception;
	
	public List<UtilityTraderGencoDTO> getAllInjectingEntities();
	
	public Map<String,Object>getContractDefinationsBySearchCriteria(String criteria,Integer pageNo, Integer pageSize)  throws BusinessException, Exception ;
	
}
