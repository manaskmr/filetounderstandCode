package in.hertz.samast.dao;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import in.hertz.samast.domain.CoalPositionBO;
import in.hertz.samast.domain.ContractDefinitionDto;
import in.hertz.samast.domain.InjectionScheduleBO;
import in.hertz.samast.domain.ScheduleQuantumBaseDTO;
import in.hertz.samast.entity.Draft;

/**
 * 
 * @author Bibhuti Parida
 * This is Draft Repository interface which manages draft table data for scheduling services
 *
 * @param <T>
 */

@Repository
public interface DraftRepository<T> extends JpaRepository<Draft<T>, Integer> {

	@Query("SELECT a FROM Draft a " + "WHERE a.functionalityArea = 'Scheduling_DC' and a.status = 'NEW' and function('JSON_EXTRACT', a.data, '$.sellerUTGId') = ?1 and function('JSON_EXTRACT', a.data, '$.forDate') = ?2")
	public List<Draft<ScheduleQuantumBaseDTO>> findDraftByName(int utgId, String forDate); 
	
	@Query("SELECT dt FROM Draft dt " + "WHERE dt.functionalityArea='Scheduling_CoalPoistion' and dt.status = 'NEW' and function('JSON_EXTRACT', dt.data, '$.utgId') = ?1 and function('JSON_EXTRACT', dt.data, '$.forDate') = ?2")
	public List<Draft<CoalPositionBO>> findDraftByDate(int utgId, String forDate);
	
	
	@Query(nativeQuery = true, value = "select * from draft dt where json_extract(dt.data, '$.acceptanceNumber') = :approvalNumber order by dt.insert_tm limit 1")
	public Draft<ContractDefinitionDto> findDraftByApprovalNumber(@Param("approvalNumber") String approvalNumber);
	
	@Query("SELECT a FROM Draft a " + "WHERE a.functionalityArea = 'Injection_Scheduling_QCA' and a.status = 'NEW' and function('JSON_EXTRACT', a.data, '$.injectionUtgId') = ?1 and function('JSON_EXTRACT', a.data, '$.forDate') = ?2")
	public List<Draft<InjectionScheduleBO>> findDraftForInjectionSchedule(int utgId, String forDate); 
	
	@Query("select dt from Draft dt where DATE(dt.insertTime) = :sdate and dt.functionalityArea='Scheduling_Contract'")
	List<Draft<ContractDefinitionDto>> findContractConfigurationDraftByDate(@Param("sdate") Date sdate);
	
	@Query("SELECT a FROM Draft a WHERE a.functionalityArea = 'INJECTION_SCHEDULE_OA' AND json_extract(a.data, '$.injectionUtgId') = :gencoUtgId AND json_extract(a.data, '$.forDate') = :forDate AND json_extract(a.data, '$.revisionNumber') = :revision")
	public List<Draft<InjectionScheduleBO>> findDraftedInjectionSchedule(@Param("gencoUtgId") int gencoUtgId, @Param("forDate") String forDate, @Param("revision") int revision) throws Exception;
}
