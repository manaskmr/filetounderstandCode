package in.hertz.samast.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import in.hertz.samast.entity.TimeInterval;

/**
 * 
 * @author Bibhuti Parida
 * This is Time Interval Repository interface which manages time_interval table data for scheduling services
 *
 */
@Repository
public interface TimeIntervalRepository extends JpaRepository<TimeInterval, Integer> {

	@Query("SELECT tm FROM TimeInterval tm where tm.blockNumber = :blockNo")
	public TimeInterval findByBlock(@Param("blockNo") int blockNo) throws Exception;
	
	@Query("SELECT max(tm.blockNumber) FROM TimeInterval tm")
	public Integer findMaxBlock() throws Exception;
}
