/**
 * 
 */
package in.hertz.samast.dao;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import in.hertz.samast.entity.InjectionScheduleSummary;

/**
 * 
 * @author Bibhuti Parida
 * This is Injection Schedule Summary Repository interface which manages injection_schedule_summary table data for scheduling services
 *
 */
@Repository
public interface InjectionScheduleSummaryRepository extends JpaRepository<InjectionScheduleSummary, Integer> {

	
	@Query("SELECT iss FROM InjectionScheduleSummary iss where iss.forDate = :forDate and iss.injectorUTG.UID = :utgId")
	public List<InjectionScheduleSummary> getInjectionScheduleSummaryByUTG(@Param("utgId") int utgId, 
			@Param("forDate") Date forDate) throws Exception;
	
	@Query("SELECT iss FROM InjectionScheduleSummary iss where iss.forDate = :forDate and iss.injectorUTG.UID = :utgId and iss.revision = :revisionNo")
	public List<InjectionScheduleSummary> getInjectionScheduleSummaryLatestRevision(@Param("utgId") int utgId, 
			@Param("forDate") Date forDate, @Param("revisionNo") int revisionNo) throws Exception;
	
	@Query("SELECT max(iss.revision) FROM InjectionScheduleSummary iss where iss.forDate = :forDate and iss.injectorUTG.UID = :utgId")
	public Integer getLatestRevisionNoByUTG(@Param("utgId") int utgId, 
			@Param("forDate") Date forDate) throws Exception;
	
	
}
