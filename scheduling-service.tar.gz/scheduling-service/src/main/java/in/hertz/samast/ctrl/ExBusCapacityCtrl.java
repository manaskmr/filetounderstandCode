/**
 * 
 */
package in.hertz.samast.ctrl;

import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.hertz.samast.domain.ExBusCapacityBO;
import in.hertz.samast.domain.GenerationUnitBO;
import in.hertz.samast.domain.WSResp;
import in.hertz.samast.domain.exception.BusinessException;
import in.hertz.samast.service.ExBusCapacityService;

/**
 * @author Bibhuti Parida
 *
 */
@RestController
@RequestMapping("/sldc-config-exbus")
public class ExBusCapacityCtrl {
	

	@Autowired
	private ExBusCapacityService exBusCapacityService;
	
	@GetMapping("/findAll")
	public ResponseEntity<WSResp<List<ExBusCapacityBO>>> getAllExBusCapacity()
			throws Exception, BusinessException {
		List<ExBusCapacityBO> exBusBOList = exBusCapacityService.getAllExBusCapacity();

		if (CollectionUtils.isNotEmpty(exBusBOList)) {
			return new ResponseEntity<WSResp<List<ExBusCapacityBO>>>(
					new WSResp<List<ExBusCapacityBO>>(exBusBOList, true, "Ex-Bus Capacity Data Fetched Successfully!"), HttpStatus.OK);
		} else {
			return new ResponseEntity<WSResp<List<ExBusCapacityBO>>>(
					new WSResp<List<ExBusCapacityBO>>(exBusBOList , false, "Ex-Bus Capacity not found"),
					HttpStatus.OK);
		}
	}
	
	@PostMapping("/updateAll")
	public ResponseEntity<WSResp<List<ExBusCapacityBO>>> update66AllExBusCapacity(@RequestBody List<ExBusCapacityBO> exBusList)
			throws Exception, BusinessException {
		List<ExBusCapacityBO> exBusBOList = exBusCapacityService.updateAllExBusCapacity(exBusList);

		if (CollectionUtils.isNotEmpty(exBusBOList)) {
			return new ResponseEntity<WSResp<List<ExBusCapacityBO>>>(
					new WSResp<List<ExBusCapacityBO>>(exBusBOList, true, "Ex-Bus Capacity Data updated Successfully!"), HttpStatus.OK);
		} else {
			return new ResponseEntity<WSResp<List<ExBusCapacityBO>>>(
					new WSResp<List<ExBusCapacityBO>>(exBusBOList , false, "Ex-Bus Capacity not updated"),
					HttpStatus.OK);
		}
	}	

	@GetMapping("/findByGenType/{genTypeId}")
	public ResponseEntity<WSResp<List<ExBusCapacityBO>>> getExBusCapacityByGenType(@PathVariable("genTypeId") int genTypeId)
			throws Exception, BusinessException {
		List<ExBusCapacityBO> exBusBOList = exBusCapacityService.getExBusCapacityByGenType(genTypeId);

		if (CollectionUtils.isNotEmpty(exBusBOList)) {
			return new ResponseEntity<WSResp<List<ExBusCapacityBO>>>(
					new WSResp<List<ExBusCapacityBO>>(exBusBOList, true, "Ex-Bus Capacity Data Fetched Successfully!"), HttpStatus.OK);
		} else {
			return new ResponseEntity<WSResp<List<ExBusCapacityBO>>>(
					new WSResp<List<ExBusCapacityBO>>(exBusBOList , false, "Ex-Bus Capacity not found"),
					HttpStatus.OK);
		}
	}

	@GetMapping("/findAllGenType")
	public ResponseEntity<WSResp<List<GenerationUnitBO>>> getAllGenType()
			throws Exception, BusinessException {
		List<GenerationUnitBO> exBusBOList = exBusCapacityService.getAllGenType();

		if (CollectionUtils.isNotEmpty(exBusBOList)) {
			return new ResponseEntity<WSResp<List<GenerationUnitBO>>>(
					new WSResp<List<GenerationUnitBO>>(exBusBOList, true, "Generation Type Data Fetched Successfully!"), HttpStatus.OK);
		} else {
			return new ResponseEntity<WSResp<List<GenerationUnitBO>>>(
					new WSResp<List<GenerationUnitBO>>(exBusBOList , false, "Generation Type not found"),
					HttpStatus.OK);
		}
	}
}
