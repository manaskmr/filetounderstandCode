package in.hertz.samast.config;

import in.hertz.samast.config.YamlPropertySourceFactory;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Component
@EnableConfigurationProperties
@ConfigurationProperties(prefix = "yaml")
@PropertySource(factory = YamlPropertySourceFactory.class, value = "classpath:application-business-err.yaml")
public class BusinessErrorPropertyConfig {

	private String dccurrfordate;
	private String dcissuedate;
	private String dcrevnonotnull;
	private String dcrevnominusone;
	private String dcrevnonotleseq;
	private String dcrevlatbyone;
	private String dcquantbegtmblk;
	private String coalpofordate;
	private String iscurrfordate;
	private String isissuedate;
	private String isrevnonotnull;
	private String isrevnominusone;
	private String isrevnonotleseq;
	private String isrevlatbyone;
	private String isquantbegtmblk;
	private String isintradaytimegap150;
}
