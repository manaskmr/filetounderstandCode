package in.hertz.samast.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import in.hertz.samast.entity.DeclareCapabilityDetails;

/**
 * 
 * @author Bibhuti Parida
 * This is Declare Capacity Details Repository interface which manages declare_capability_details table data for scheduling services
 *
 */
@Repository
public interface DeclareCapacityDetailsRepository extends JpaRepository<DeclareCapabilityDetails, Integer> {

}
