package in.hertz.samast.service;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import ch.qos.logback.classic.Logger;
import in.hertz.samast.domain.ContractDefinitionDto;
import in.hertz.samast.domain.ContractQuantumDto;
import in.hertz.samast.domain.exception.BusinessException;

@Service
public class ExcelFileExporterServiceImpl  implements ExcelFileExporterService{
	
	private final static String[] headers = {"Action","Issue Date","Applicant Name","Injecting Utility","Drawing Utility","From Date","TO Date","Schedule"};
	private static final Logger LOGGER = (Logger) LoggerFactory.getLogger(ExcelFileExporterServiceImpl.class);
	private static final String SHEET_NAME = "ContractDefinition";
	@Override
	public ByteArrayInputStream contractConfigurationByParamtersListToExcelFile  (
		List<ContractDefinitionDto> listContractDefinitionDto) throws BusinessException,Exception{

		ByteArrayOutputStream outputStream = null;
		try(Workbook workbook =  createReportHeaderInExcel()) {
		Sheet sheet =  workbook.getSheet(SHEET_NAME);
		
		for(int i=0;i<headers.length;i++) {
			((org.apache.poi.ss.usermodel.Sheet) sheet).autoSizeColumn(i);
		}
		
		int rowIndex = 1;
		int columnIndex = 1;
		for(ContractDefinitionDto contractDefinitionDto : listContractDefinitionDto) {
				Row dataRow = (sheet).createRow(rowIndex++);
				columnIndex = 1;
				dataRow.createCell(columnIndex++).setCellValue(contractDefinitionDto.getIssueDate() + " " + contractDefinitionDto.getAcceptanceNumber());
				dataRow.createCell(columnIndex++).setCellValue(contractDefinitionDto.getApplicantName());
				dataRow.createCell(columnIndex++).setCellValue(contractDefinitionDto.getInjectorName());
				dataRow.createCell(columnIndex++).setCellValue(contractDefinitionDto.getDraweeName());
				dataRow.createCell(columnIndex++).setCellValue(contractDefinitionDto.getFromDate());
				dataRow.createCell(columnIndex++).setCellValue(contractDefinitionDto.getToDate());
				List<ContractQuantumDto> listContractQuantumDto = contractDefinitionDto.getListcontractQuantumDto();
				StringBuilder schedule = new StringBuilder();
				
				for(ContractQuantumDto contractQuantumDto : listContractQuantumDto) {
					schedule.append(contractQuantumDto.getSchedule()[0].getStartSchedule() + "-" + contractQuantumDto.getSchedule()[1].getStartSchedule() + " " + contractQuantumDto.getQuantum())
							.append("\n");
				}
				dataRow.createCell(columnIndex++).setCellValue(schedule.toString());
		}
		
		for(int i=0;i<headers.length;i++) {
			((org.apache.poi.ss.usermodel.Sheet) sheet).autoSizeColumn(i);
		}
		
		outputStream = new  ByteArrayOutputStream();
		workbook.write(outputStream);
		}catch(Exception e) {
			throw new BusinessException(e.getMessage());
		}
		return new ByteArrayInputStream(outputStream.toByteArray());
	}
	
	private Workbook createReportHeaderInExcel() {
		Workbook workbook = new XSSFWorkbook();
			Sheet sheet = (Sheet) workbook.createSheet(SHEET_NAME);
			
			Row row = sheet.createRow(0);
			
	        CellStyle headerCellStyle = workbook.createCellStyle();
	        headerCellStyle.setFillForegroundColor(IndexedColors.AQUA.getIndex());
	        headerCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
	        
	        for(int i=0;i<headers.length;i++) {
	        	Cell cell = row.createCell(i);
	 	        cell.setCellValue(headers[i]);
	 	        cell.setCellStyle(headerCellStyle);
	        }
	        return workbook;
		
	}

}
