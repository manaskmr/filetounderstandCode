package in.hertz.samast.dao;

import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import in.hertz.samast.entity.DeclareCapability;

/**
 * 
 * @author Bibhuti Parida
 * This is Declare Capacity Repository interface which manages declare_capability table data for scheduling services
 *
 */
@Repository
public interface DeclareCapacityRepository extends JpaRepository<DeclareCapability, Integer> {

	@Query("SELECT dc FROM DeclareCapability dc where dc.forDate = :forDate and dc.utilitiesTraderGenco.UID = :utgId")
	public List<DeclareCapability> getDeclaredCapacityByUTG(@Param("utgId") int utgId, 
			@Param("forDate") Date forDate) throws Exception;
	
	@Query("SELECT dc FROM DeclareCapability dc where dc.forDate = :forDate and dc.utilitiesTraderGenco.UID = :utgId and dc.revision = :revisionNo")
	public List<DeclareCapability> getDeclaredCapacityLatestRevision(@Param("utgId") int utgId, 
			@Param("forDate") Date forDate, @Param("revisionNo") int revisionNo) throws Exception;
	
	@Query("SELECT max(dc.revision) FROM DeclareCapability dc where dc.forDate = :forDate and dc.utilitiesTraderGenco.UID = :utgId")
	public Integer getLatestRevisionNoByUTG(@Param("utgId") int utgId, 
			@Param("forDate") Date forDate) throws Exception;
	
	@Query("SELECT dc FROM DeclareCapability dc where dc.forDate = :forDate and dc.utilitiesTraderGenco.UID = :utgId and dc.revision = :revisionNo")
	public DeclareCapability getDeclaredCapacityByRevision(@Param("utgId") int utgId, 
			@Param("forDate") Date forDate, @Param("revisionNo") int revisionNo) throws SQLException;
	
	@Query("SELECT dc FROM DeclareCapability dc WHERE dc.forDate = :forDate AND dc.revision = :revisionNo")
	public List<DeclareCapability> getDeclareCapability(@Param("forDate") Date forDate, @Param("revisionNo") int revisionNo) throws Exception;
	
	@Query("SELECT dc FROM DeclareCapability dc where dc.forDate = :forDate and dc.revision = :revisionNo and dc.utilitiesTraderGenco.UID = :gencoUtgId")
	public DeclareCapability getDeclaredCapacityByRevision(@Param("forDate") Date forDate, @Param("revisionNo") int revisionNo, @Param("gencoUtgId") int gencoUtgId) throws SQLException;
	
	@Query("SELECT dc FROM DeclareCapability  dc  WHERE dc.forDate BETWEEN :fromDate AND :toDate")
	public List<DeclareCapability> getDeclareCapacityByDateRange(@Param("fromDate") Date fromDate, @Param("toDate") Date toDate) throws Exception;

	@Query("SELECT dc FROM DeclareCapability dc where dc.forDate = :forDate and dc.utilitiesTraderGenco.UID = :utgId")
	public List<DeclareCapability> getDeclaredCapacityByUtgDate(@Param("forDate") Date forDate, @Param("utgId") int utgId);
}
