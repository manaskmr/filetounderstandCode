/**
 * 
 */
package in.hertz.samast.service;

import java.sql.Time;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.hertz.samast.dao.TimeIntervalRepository;
import in.hertz.samast.domain.exception.BusinessException;
import in.hertz.samast.entity.TimeInterval;

/**
 * @author Bibhuti Parida
 *
 */
@Service
@Transactional
public class TimeIntervalServiceImpl implements TimeIntervalService {

	@Autowired
	private TimeIntervalRepository timeIntervalRepository;
	
	/**
	 * This method returns the current time block number
	 * @return
	 */
	@Override
	public TimeInterval getCurrentTimeBlock()  throws Exception, BusinessException {
		DateFormat sdf = new SimpleDateFormat("HH:mm");
		long currentms = 0;
		currentms = sdf.parse(sdf.format(new Date())).getTime(); 
		Time t = new Time(currentms);
		List<TimeInterval> timeIntervalList = timeIntervalRepository.findAll();
        for (TimeInterval ti : timeIntervalList) {
            Time toTime = ti.getToTime();
            Time fromTime = ti.getTimeInterval();
            if (t.equals(fromTime) || (t.before(toTime) && t.after(fromTime))) {
                return ti;
            }

        }
		return null;
	}
	
	@Override
	public List<TimeInterval> findAllTimeIntervals() throws Exception, BusinessException {
		return timeIntervalRepository.findAll();
	}
	
	@Override
    public TimeInterval findByBlock(int block) throws Exception, BusinessException {
        return timeIntervalRepository.findByBlock(block);
    }
	
    @Override
    public TimeInterval findTimeBlock(String time) throws Exception, BusinessException {
        List<TimeInterval> timeIntervalList = timeIntervalRepository.findAll();
        Time t = Time.valueOf(time);
        for (TimeInterval ti : timeIntervalList) {
            Time toTime = ti.getToTime();
            Time fromTime = ti.getTimeInterval();
            if (t.equals(fromTime) || (t.before(toTime) && t.after(fromTime))) {
                return ti;
            }
        }
        return null;
    }
    
    @Override
    public TimeInterval findTimeIntervalByFromTime(String fromTime) throws Exception, BusinessException {

        List<TimeInterval> timeIntervalList = timeIntervalRepository.findAll();
        Time t = Time.valueOf(fromTime);
        for (TimeInterval ti : timeIntervalList) {

            Time fromTime1 = ti.getTimeInterval();
            if (t.equals(fromTime1)) {
                return ti;
            }
        }
        return null;
    }
    
    @Override
    public TimeInterval findTimeIntervalByToTime(String toTime) throws Exception, BusinessException {

        List<TimeInterval> timeIntervalList = timeIntervalRepository.findAll();
        Time t = Time.valueOf(toTime);
        for (TimeInterval ti : timeIntervalList) {
            Time toTime1 = ti.getToTime();
            if (t.equals(toTime1)) {
                return ti;
            }
        }
        return null;
    }
    
    @Override
    public TimeInterval findTimeIntervalByBetweenTime(String betweenTime) throws Exception, BusinessException {
        List<TimeInterval> timeIntervalList = timeIntervalRepository.findAll();
        Time t = Time.valueOf(betweenTime);
        for (TimeInterval ti : timeIntervalList) {
            Time toTime1 = ti.getToTime();
            Time fromTime = ti.getTimeInterval();
            if ((t.after(fromTime) && t.before(toTime1)) || t.equals(fromTime)) {
                return ti;
            }
        }
        return null;
    }
    
    @Override
	public TimeInterval findTimeIntervalByBetweenTimeZone(String betweenTime) throws Exception, BusinessException {
		List<TimeInterval> timeIntervalList = timeIntervalRepository.findAll();
        String[] time = betweenTime.trim().split("T");
		betweenTime=time[1];
		String[] timez=betweenTime.trim().split("I");
		betweenTime=timez[0];
        Time t = Time.valueOf(betweenTime);
        for (TimeInterval ti : timeIntervalList) {
            Time toTime1 = ti.getToTime();
            Time fromTime = ti.getTimeInterval();
            if ((t.after(fromTime) && t.before(toTime1)) || t.equals(fromTime)) {
                return ti;
            }
        }
		return null;
	}
    
	@Override
    public Integer findMaxBlock() throws Exception, BusinessException {
        return timeIntervalRepository.findMaxBlock();
    }
	
	@Override
	public long timeDifferent(Date existDate) throws Exception, BusinessException {
		SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
		Time existTime = new Time(sdf.parse(sdf.format(existDate)).getTime());
		Time currentTime = new Time(sdf.parse(sdf.format(new Date())).getTime());
		long diff = currentTime.getTime() - existTime.getTime();
		return diff;
	}
}
