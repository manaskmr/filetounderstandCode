package in.hertz.samast.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import in.hertz.samast.entity.UtilitiesTraderGenco;

/**
 * 
 * @author Bibhuti Parida
 * This is Utilities TraderGenco Repository interface which manages utilities_trader_genco table data for scheduling services
 *
 */
@Repository
public interface UtilitiesTraderGencoRepository extends JpaRepository<UtilitiesTraderGenco,Integer>{
	
	@Query("SELECT utg FROM UtilitiesTraderGenco utg WHERE utg.name = :name")
	public UtilitiesTraderGenco getByName(@Param("name") String name);
}
