/**
 * 
 */
package in.hertz.samast.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.Set;

import javax.transaction.Transactional;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Service;

import in.hertz.samast.config.BusinessErrorPropertyConfig;
import in.hertz.samast.dao.ForecastSubscriptionRepository;
import in.hertz.samast.dao.ForecastSubscriptionUsagesRepository;
import in.hertz.samast.dao.PSSRepository;
import in.hertz.samast.dao.UtilitiesTraderGencoRepository;
import in.hertz.samast.domain.ForecastSubscriptionBO;
import in.hertz.samast.domain.ForecastSubscriptionUsagesBO;
import in.hertz.samast.domain.PSSDetailsDTO;
import in.hertz.samast.domain.exception.BusinessException;
import in.hertz.samast.entity.ForecastSubscription;
import in.hertz.samast.entity.ForecastSubscriptionUsages;
import in.hertz.samast.entity.PSS;

/**
 * @author Bibhuti Parida
 *
 */
@Configuration
@Service
@Transactional
@ComponentScan(basePackages = "in.hertz.samast.config")
public class ForecastSubscriptionServiceImpl implements ForecastSubscriptionService {
	
	private static final Logger LOG = LogManager.getLogger(ForecastSubscriptionServiceImpl.class);
	
	@Autowired
	private BusinessErrorPropertyConfig bepc;
	
	@Autowired
	private ForecastSubscriptionRepository forecastSubscriptionRepository;

	@Autowired
	private ForecastSubscriptionUsagesRepository forecastSubscriptionUsagesRepository;
	
	@Autowired
	private UtilitiesTraderGencoRepository utilitiesTraderGencoRepository;
	
	@Autowired
	private PSSRepository pssSRepository;
	
	@Value("${cost.of.forecasting.service.day}")
	private BigDecimal forecastServiceCostDay;
	
	@Value("${gst.value}")
	private BigDecimal gstPercentage;
	
	@Override
	public List<PSSDetailsDTO> getPSSListByQCAId(int qcaUtgId) throws Exception, BusinessException {
		LOG.info("Start ForecastSubscriptionServiceImpl : getPSSListByQCAId");
		List<PSSDetailsDTO> pssBOList = null;
		List<PSS> pssList = pssSRepository.getPSSListByQCAId(qcaUtgId);
		if(CollectionUtils.isNotEmpty(pssList)) {
			pssBOList = new ArrayList<PSSDetailsDTO>();
			for (PSS pss : pssList) {
				PSSDetailsDTO pssDto = new PSSDetailsDTO();
				pssDto.setGridSubstation(pss.getGridSubstation());
				pssDto.setPssAddress(pss.getPssAddress());
				pssDto.setPssId(pss.getPssId());
				pssDto.setPssName(pss.getPssName());
				pssDto.setQcaUtgId(pss.getUtilitiesTraderGencoQCA().getUID());
				pssDto.setTotalInstalledCapacity(pss.getTotalInstalledCapacity());
				pssDto.setUtgId(pss.getUtilitiesTraderGenco().getUID());
				pssDto.setVoltageLevel(pss.getVoltageLevel());
				pssBOList.add(pssDto);
			}
		}
		LOG.info("End ForecastSubscriptionServiceImpl : getPSSListByQCAId");
		return pssBOList;
	}
	
	/**
	 * This method for retrieve details of forecast subscription based on pss id
	 */
	@Override
	public List<ForecastSubscriptionBO> getForecastSubscriptionListByPSSId(int pssUtgId) throws Exception, BusinessException {
		List<ForecastSubscriptionBO> fsBOList = null;
		List<ForecastSubscription> fsEntityList = forecastSubscriptionRepository.findByPSSId(pssUtgId);
		if (CollectionUtils.isNotEmpty(fsEntityList)) {
			fsBOList = new ArrayList<ForecastSubscriptionBO>();
			for (ForecastSubscription forecastSubscription : fsEntityList) {
				ForecastSubscriptionBO fsBO = convertEntityToForecastSubscriptionBO(forecastSubscription);
				Set<ForecastSubscriptionUsages> fsUsagesList = forecastSubscription.getForecastSubscriptionUsages();
				List<ForecastSubscriptionUsagesBO> fsUsagesBOList = null;
				if(CollectionUtils.isNotEmpty(fsUsagesList)) {
					fsUsagesBOList = new ArrayList<ForecastSubscriptionUsagesBO>();
					for (ForecastSubscriptionUsages forecastSubscriptionUsages : fsUsagesList) {
						ForecastSubscriptionUsagesBO forecastSubscriptionUsagesBO = convertEntityToForecastSubscriptionUsagesBO(forecastSubscriptionUsages);
						fsUsagesBOList.add(forecastSubscriptionUsagesBO);
					}	
					fsBO.setForecastSubscriptionUsages(fsUsagesBOList);
				}
				fsBOList.add(fsBO);
			}
		}
		return fsBOList;
	}
	
	/**
	 * This method for retrieve details of forecast subscription based on pss id
	 */
	@Override
	public List<ForecastSubscriptionBO> getForecastSubscriptionByPSSId(int pssUtgId) throws Exception, BusinessException {
		List<ForecastSubscriptionBO> fsBOList = null;
		List<ForecastSubscription> fsEntityList = forecastSubscriptionRepository.findByPSSId(pssUtgId);
		if (CollectionUtils.isNotEmpty(fsEntityList)) {
			fsBOList = new ArrayList<ForecastSubscriptionBO>();
			for (ForecastSubscription forecastSubscription : fsEntityList) {
				ForecastSubscriptionBO fsBO = convertEntityToForecastSubscriptionBO(forecastSubscription);
				fsBOList.add(fsBO);
			}
		}
		return fsBOList;
	}
	
	/**
	 * This method for retrieve details of forecast subscription based on pss id
	 */
	@Override
	public List<ForecastSubscriptionUsagesBO> getForecastSubscriptionDetailByPSSId(int pssUtgId, Date forDate) throws Exception, BusinessException {
		List<ForecastSubscriptionUsagesBO> fsUsagesBOList = null;
		List<ForecastSubscriptionUsages> fsUsagesList = forecastSubscriptionUsagesRepository.findByPSSId(pssUtgId, forDate);
		if(CollectionUtils.isNotEmpty(fsUsagesList)) {
			fsUsagesBOList = new ArrayList<ForecastSubscriptionUsagesBO>();
			for (ForecastSubscriptionUsages forecastSubscriptionUsages : fsUsagesList) {
				ForecastSubscriptionUsagesBO forecastSubscriptionUsagesBO = convertEntityToForecastSubscriptionUsagesBO(forecastSubscriptionUsages);
				fsUsagesBOList.add(forecastSubscriptionUsagesBO);
			}					
		}
		return fsUsagesBOList;
	}
	
	/**
	 * This method for submit the new forecast subscription
	 */
	@Override
	public ForecastSubscriptionUsagesBO updateForecastSubscription(ForecastSubscriptionUsagesBO fsBO) throws Exception, BusinessException {
		List<ForecastSubscriptionBO> fsBOlist = getForecastSubscriptionByPSSId(fsBO.getPssUtgid());
		ForecastSubscriptionBO newfsBO = null;
		if (CollectionUtils.isNotEmpty(fsBOlist)) {
			for (ForecastSubscriptionBO forecastSubscriptionBO : fsBOlist) {
				if (forecastSubscriptionBO.getRemainingDays() < forecastSubscriptionBO.getNoOfDays()) {
					newfsBO = forecastSubscriptionBO;
					break;
				}
			}
			if (Objects.isNull(newfsBO)) {
				newfsBO = fsBOlist.get(0);
			}
		}
		
		if (Objects.nonNull(newfsBO)) {
			ForecastSubscription fs = updateForecastSubscription(newfsBO);
			
			ForecastSubscriptionUsages fsu = new ForecastSubscriptionUsages();
			fsu.setForDate(fsBO.getForDate());
			fsu.setForecastSubscription(fs);
			fsu.setDebitedAmt(forecastServiceCostDay);
			fsu.setViewedDate(new Date());
			fsu.setUtilitiesTraderGencoPSS(utilitiesTraderGencoRepository.getById(fsBO.getPssUtgid()));
			fsu.setUtilitiesTraderGencoViewer(Objects.nonNull(fsBO.getViewerUtgId()) ? utilitiesTraderGencoRepository.getById(fsBO.getViewerUtgId()) : null);
			fsu.setBalance(forecastServiceCostDay.multiply(new BigDecimal(newfsBO.getRemainingDays()-1)));
			forecastSubscriptionUsagesRepository.save(fsu);
			
			fsBO = convertEntityToForecastSubscriptionUsagesBO(fsu);
		} else {
			return null;
		}
		return fsBO;
	}
	
	private ForecastSubscription updateForecastSubscription(ForecastSubscriptionBO newfsBO) {
		ForecastSubscription fs = new ForecastSubscription();
		fs.setUID(newfsBO.getUID());
		fs.setForecastServiceCost(newfsBO.getForecastServiceCost());
		fs.setForecastServiceCostDay(newfsBO.getForecastServiceCostDay());
		fs.setGstValue(newfsBO.getGstValue());
		fs.setNoOfDays(newfsBO.getNoOfDays());
		fs.setUtilitiesTraderGencoPSS(utilitiesTraderGencoRepository.getById(newfsBO.getPssUtgId()));
		fs.setUtilitiesTraderGencoQCA(Objects.nonNull(newfsBO.getQcaUtgId()) ? utilitiesTraderGencoRepository.getById(newfsBO.getQcaUtgId()) : null);
		fs.setRegistrationNo(newfsBO.getRegistrationNo());
		fs.setRtgsNo(newfsBO.getRtgsNo());
		fs.setSubscriptionDate(new Date());
		fs.setTotalAmt(newfsBO.getTotalAmt());
		fs.setRemainingDays(newfsBO.getRemainingDays()-1);
		forecastSubscriptionRepository.save(fs);
		return fs;
	}
	
	/**
	 * This method for submit the new forecast subscription
	 */
	@Override
	public ForecastSubscriptionBO saveForecastSubscription(ForecastSubscriptionBO fsBO) throws Exception, BusinessException {
		if (Objects.nonNull(fsBO)) {
			ForecastSubscription fs = new ForecastSubscription();
			fs.setForecastServiceCost(fsBO.getForecastServiceCost());
			fs.setForecastServiceCostDay(fsBO.getForecastServiceCostDay());
			fs.setGstValue(fsBO.getGstValue());
			fs.setNoOfDays(fsBO.getNoOfDays());
			fs.setUtilitiesTraderGencoPSS(utilitiesTraderGencoRepository.getById(fsBO.getPssUtgId()));
			fs.setUtilitiesTraderGencoQCA(Objects.nonNull(fsBO.getQcaUtgId()) ? utilitiesTraderGencoRepository.getById(fsBO.getQcaUtgId()) : null);
			fs.setRegistrationNo(fsBO.getRegistrationNo());
			fs.setRtgsNo(fsBO.getRtgsNo());
			fs.setStatus("SUBMITTED");
			fs.setSubscriptionDate(new Date());
			fs.setTotalAmt(fsBO.getTotalAmt());
			fs.setRemainingDays(fsBO.getNoOfDays());
			forecastSubscriptionRepository.save(fs);
			fsBO = convertEntityToForecastSubscriptionBO(fs);
		} else {
			return null;
		}
		return fsBO;
	}
	
	/**
	 * This method for initiating forecast subscription with total and GST calculation
	 */
	@Override
	public ForecastSubscriptionBO newFS(int pssUtgId, int noOfDays) throws Exception, BusinessException {
		ForecastSubscriptionBO fsBO = new ForecastSubscriptionBO();
		BigDecimal forecastServiceCost = forecastServiceCostDay.multiply(new BigDecimal(noOfDays));
		BigDecimal gstValue = forecastServiceCost.multiply(gstPercentage).divide(new BigDecimal(100));
		BigDecimal totalAmt = forecastServiceCost.add(gstValue);
		fsBO.setPssUtgId(pssUtgId);
		fsBO.setNoOfDays(noOfDays);
		fsBO.setForecastServiceCostDay(forecastServiceCostDay);
		fsBO.setForecastServiceCost(forecastServiceCost);
		fsBO.setGstValue(gstValue);
		fsBO.setTotalAmt(totalAmt);
		return fsBO;
	}
	
	/**
	 * This method converting Entity bean to DTO bean
	 * @param forecastSubscription
	 * @return
	 */
	private ForecastSubscriptionBO convertEntityToForecastSubscriptionBO(ForecastSubscription forecastSubscription ) {
		ForecastSubscriptionBO fsBO = null;
		if (Objects.nonNull(forecastSubscription)) {
			fsBO = new ForecastSubscriptionBO();
			fsBO.setUID(forecastSubscription.getUID());
			fsBO.setForecastServiceCost(forecastSubscription.getForecastServiceCost());
			fsBO.setForecastServiceCostDay(forecastSubscription.getForecastServiceCostDay());
			fsBO.setGstValue(forecastSubscription.getGstValue());
			fsBO.setNoOfDays(forecastSubscription.getNoOfDays());
			fsBO.setPssUtgId(forecastSubscription.getUtilitiesTraderGencoPSS().getUID());
			fsBO.setQcaUtgId(Objects.nonNull(forecastSubscription.getUtilitiesTraderGencoQCA()) ? forecastSubscription.getUtilitiesTraderGencoQCA().getUID() : null);
			fsBO.setRegistrationNo(forecastSubscription.getRegistrationNo());
			fsBO.setRtgsNo(forecastSubscription.getRtgsNo());
			fsBO.setStatus(forecastSubscription.getStatus());
			fsBO.setSubscriptionDate(forecastSubscription.getSubscriptionDate());
			fsBO.setTotalAmt(forecastSubscription.getTotalAmt());
			fsBO.setRemainingDays(forecastSubscription.getRemainingDays());
			fsBO.setApprovedDate(forecastSubscription.getApprovedDate());
			fsBO.setApprovedBy(forecastSubscription.getApprovedBy());
		}
		
		return fsBO;
	}
	
	/**
	 * This method converting Entity bean to DTO bean
	 * @param forecastSubscriptionUsages
	 * @return
	 */
	private ForecastSubscriptionUsagesBO convertEntityToForecastSubscriptionUsagesBO(ForecastSubscriptionUsages forecastSubscriptionUsages ) {
		ForecastSubscriptionUsagesBO fsUsagesBO = null;
		if (Objects.nonNull(forecastSubscriptionUsages)) {
			fsUsagesBO = new ForecastSubscriptionUsagesBO();
			fsUsagesBO.setUID(forecastSubscriptionUsages.getUID());
			fsUsagesBO.setForecastSubscriptionUid(forecastSubscriptionUsages.getForecastSubscription().getUID());
			fsUsagesBO.setPssUtgid(forecastSubscriptionUsages.getUtilitiesTraderGencoPSS().getUID());
			fsUsagesBO.setForDate(forecastSubscriptionUsages.getForDate());
			fsUsagesBO.setViewerUtgId(forecastSubscriptionUsages.getUtilitiesTraderGencoViewer().getUID());
			fsUsagesBO.setBalance(forecastSubscriptionUsages.getBalance());
			fsUsagesBO.setDebitedAmt(forecastSubscriptionUsages.getDebitedAmt());
			fsUsagesBO.setViewedDate(forecastSubscriptionUsages.getViewedDate());
		}
		return fsUsagesBO;
	}
}
