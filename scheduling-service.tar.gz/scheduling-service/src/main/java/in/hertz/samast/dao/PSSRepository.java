/**
 * 
 */
package in.hertz.samast.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import in.hertz.samast.entity.Generation;
import in.hertz.samast.entity.PSS;

/**
 * @author Bibhuti Parida
 *
 */
public interface PSSRepository extends JpaRepository<PSS, Integer> {

	@Query("SELECT ps FROM PSS ps where ps.utilitiesTraderGencoQCA.UID = :qcaUtgId")
	public List<PSS> getPSSListByQCAId(@Param("qcaUtgId") int qcaUtgId) throws Exception;

	@Query("SELECT ps from PSS ps where ps.energySourceDetail.sourceName IN (:sourceName)")
	public List<PSS> getPSSListBySourceName(@Param("sourceName") List<String> sourceName) throws Exception;
	
	@Query("SELECT ps from PSS ps where ps.energySourceDetail.sourceName IN (:sourceName) AND ps.utilitiesTraderGenco.UID IN (:utgIds) AND ps.utilitiesTraderGencoQCA.UID IN (:qcaUtgIds)")
	public List<PSS> getPSSListBySourceNameAndQcaIdAndUtgId(@Param("sourceName") List<String> sourceName, @Param("utgIds") List<Integer> utgIds, @Param("qcaUtgIds") List<Integer> qcaUtgIds ) throws Exception;
	
	@Query("SELECT ps from PSS ps where ps.energySourceDetail.sourceName IN (:sourceName) AND ps.utilitiesTraderGenco.UID IN (:utgIds)")
	public List<PSS> getPSSListBySourceNameAndUtgId(@Param("sourceName") List<String> sourceName, @Param("utgIds") List<Integer> utgIds ) throws Exception;

	
}
