package in.hertz.samast.dao;

import java.math.BigInteger;
import java.util.Date;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import in.hertz.samast.entity.coalposition.CoalPosition;

@Repository
public interface CoalPositionDao  extends JpaRepository<CoalPosition,BigInteger>{
	
	@Query("select cp from CoalPosition cp where cp.date = :sdate and cp.utilitiesTraderGenco.UID = :utgId")
    public CoalPosition findCoalPositionByDate(@Param("sdate") Date sdate, @Param("utgId") int utgId);

}
