package in.hertz.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.databind.ObjectMapper;

import in.hertz.dao.EnergySourceRepository;
import in.hertz.dao.GenerationRepository;
import in.hertz.samast.domain.GeneratorDetailsDTO;
import in.hertz.samast.domain.GeneratorDetailsDTOType;
import in.hertz.samast.domain.REGeneratorDetailsDTO;
import in.hertz.samast.domain.exception.BusinessException;
import in.hertz.samast.entity.EnergySource;
import in.hertz.samast.entity.Generation;

@Service
@Transactional
public class GenerationService {

	@Autowired
	private GenerationRepository<GeneratorDetailsDTOType> generationRepository;

	@Autowired
	private EnergySourceRepository energySourceRepository;

	@Autowired
	ObjectMapper objectMapper = new ObjectMapper();

	@Value("${error.msg.fetch}")
	private String fetchErrMsg;

	private static final Logger LOGGER = LogManager.getLogger(GenerationService.class);

	public <T extends GeneratorDetailsDTOType> List<T> getGeneratorDetailsByPssId(Integer pssId)
			throws BusinessException {
		try {
			List<Generation<GeneratorDetailsDTOType>> generatorList = generationRepository.findByPssId(pssId);
			if (CollectionUtils.isNotEmpty(generatorList)) {
				List<GeneratorDetailsDTOType> listGenerationDtls = new ArrayList<>();
				for (Generation<GeneratorDetailsDTOType> generator : generatorList) {
					Integer energyTypeUid = generator.getEnergySourceDetail().getId();
					EnergySource findById = energySourceRepository.findById(energyTypeUid);
					if (findById != null) {
						String sourceName = findById.getSourceName();
						if (sourceName.equalsIgnoreCase("solar") || sourceName.equalsIgnoreCase("wind")) {
							REGeneratorDetailsDTO reGeneratorDetailsDTO = (REGeneratorDetailsDTO) objectMapper
									.convertValue(generator.getGeneratorDetails(), REGeneratorDetailsDTO.class);
							listGenerationDtls.add(reGeneratorDetailsDTO);
						} else {
							GeneratorDetailsDTO generatorDetailsDTO = objectMapper
									.convertValue(generator.getGeneratorDetails(), GeneratorDetailsDTO.class);
							listGenerationDtls.add(generatorDetailsDTO);
						}
					}
				}
				return (List<T>) listGenerationDtls;
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		return null;
	}
}
