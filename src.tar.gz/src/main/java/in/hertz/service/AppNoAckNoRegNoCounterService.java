package in.hertz.service;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import in.hertz.dao.AckNoCounterRepository;
import in.hertz.dao.AppNoRegNoCounterRepository;
import in.hertz.samast.entity.AckNoCounter;
import in.hertz.samast.entity.AppNoRegNoCounter;

@Service
@Transactional
public class AppNoAckNoRegNoCounterService {

	@Autowired
	private AppNoRegNoCounterRepository appNoRegNoCounterRepository;

	@Autowired
	private AckNoCounterRepository ackNoCounterRepository;

	@Autowired
	private Environment env;

	private final String separator = "_";

	private static final Logger LOGGER = LogManager.getLogger(AppNoAckNoRegNoCounterService.class);

	public synchronized String generateAppNoAndRegNo(String entityRegTypeUpperCase, String regType) {
		String counter = "";
		StringBuilder sb = null;
		try {
			AppNoRegNoCounter foundExistingCounter = appNoRegNoCounterRepository
					.findExistingCounter(entityRegTypeUpperCase, regType);
			if (foundExistingCounter != null) {
				sb = new StringBuilder();
				Long currentSeq = foundExistingCounter.getCurrentSeq();
				currentSeq++;
				String prefix = foundExistingCounter.getPrefix();
				if (StringUtils.isNotBlank(prefix)) {
					sb.append(prefix).append(separator);
				}
				sb.append(currentSeq.toString());
				foundExistingCounter.setCurrentSeq(currentSeq);
				appNoRegNoCounterRepository.save(foundExistingCounter);
				counter = sb.toString();
			} else {
				AppNoRegNoCounter appNoRegNoCounter = new AppNoRegNoCounter();
				appNoRegNoCounter.setEntityRegType(entityRegTypeUpperCase);
				appNoRegNoCounter.setRegType(regType);
				appNoRegNoCounter.setCurrentSeq(1L);
				String prefix = env
						.getProperty(regType.toLowerCase() + "." + entityRegTypeUpperCase.toLowerCase() + ".prefix");
				appNoRegNoCounter.setPrefix(StringUtils.isNotBlank(prefix) ? prefix : "");
				appNoRegNoCounterRepository.save(appNoRegNoCounter);
				counter = StringUtils.isNotBlank(prefix) ? prefix + separator + "1" : "1";
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		return counter;
	}

	public synchronized String generateAckNo(String appNo, String entityRegTypeUpperCase) {
		String counter = "";
		StringBuilder sb = null;
		try {
			AckNoCounter foundExistingCounterForAckNo = ackNoCounterRepository.findExistingCounterForAckNo(appNo);
			if (foundExistingCounterForAckNo != null) {
				sb = new StringBuilder();
				Long currentSeq = foundExistingCounterForAckNo.getCurrentSeq();
				currentSeq++;
				String prefix = foundExistingCounterForAckNo.getPrefix();
				if (StringUtils.isNotBlank(prefix)) {
					sb.append(prefix).append(separator);
				}
				sb.append(currentSeq.toString());
				foundExistingCounterForAckNo.setCurrentSeq(currentSeq);
				ackNoCounterRepository.save(foundExistingCounterForAckNo);
				counter = sb.toString();
			} else {
				AckNoCounter ackNoCounter = new AckNoCounter();
				ackNoCounter.setEntityRegType(entityRegTypeUpperCase);
				ackNoCounter.setCurrentSeq(1L);
				ackNoCounter.setAppNo(appNo);

				String appNoSplit[] = appNo.split(separator);
				String appNoDB = appNoSplit[appNoSplit.length - 1];
				String prefix = "ACK" + separator + entityRegTypeUpperCase + separator + appNoDB + "#R";
				ackNoCounter.setPrefix(StringUtils.isNotBlank(prefix) ? prefix : "");
				ackNoCounterRepository.save(ackNoCounter);
				counter = StringUtils.isNotBlank(prefix) ? prefix + separator + "1" : "1";
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		return counter;
	}
}
