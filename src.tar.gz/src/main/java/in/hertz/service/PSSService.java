package in.hertz.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.databind.ObjectMapper;

import in.hertz.dao.EnergySourceRepository;
import in.hertz.dao.GenerationRepository;
import in.hertz.dao.PSSRepository;
import in.hertz.dao.TypeOfUtilitiesRepository;
import in.hertz.dao.UtilitiesTraderGencoRepository;
import in.hertz.samast.domain.GeneratorDetailsDTOType;
import in.hertz.samast.domain.GeneratorDetailsResponseBO;
import in.hertz.samast.domain.PSSDetailsDTO;
import in.hertz.samast.domain.PSSDetailsResponseBO;
import in.hertz.samast.domain.REGeneratorDetailsDTO;
import in.hertz.samast.domain.exception.BusinessException;
import in.hertz.samast.entity.Draft;
import in.hertz.samast.entity.EnergySource;
import in.hertz.samast.entity.Generation;
import in.hertz.samast.entity.PSS;
import in.hertz.samast.entity.TypeOfUtilities;
import in.hertz.samast.entity.UtilitiesTraderGenco;
import in.hertz.samast.util.EntityRegistrationStatus;
import in.hertz.samast.util.FunctionalityArea;

@Service
@Transactional
public class PSSService {

	@Autowired
	private PSSRepository pssRepository;

	@Autowired
	private EnergySourceRepository energySourceRepository;

	@Autowired
	private TypeOfUtilitiesRepository typeOfUtilitiesRepository;

	@Autowired
	private UtilitiesTraderGencoRepository utilitiesTraderGencoRepository;

	@Autowired
	private GenerationRepository<GeneratorDetailsDTOType> generationRepository;

	@Autowired
	private EntityManager entityManager;

	@Autowired
	ObjectMapper objectMapper = new ObjectMapper();

	@Value("${error.msg.pss.save}")
	private String saveErrMsg;

	@Value("${error.msg.pss.edit}")
	private String editErrMsg;

	@Value("${error.msg.fetch}")
	private String fetchErrMsg;

	@Value("${status.data.pss.delete}")
	private String pssDeleteMsg;

	@Value("${error.msg.pss.delete}")
	private String pssDeleteErrMsg;

	private static final Logger LOGGER = LogManager.getLogger(PSSService.class);

	public PSS saveOrUpdatePssDetails(PSSDetailsDTO pssDetailsDTO) throws BusinessException {
		String pssName = pssDetailsDTO.getPssName().trim();
		String energyType = pssDetailsDTO.getEnergyType().toUpperCase();
		Integer pssId = pssDetailsDTO.getPssId();
		List<PSS> findByPssName = pssRepository.findByPssName(pssName);
		TypeOfUtilities findByType = typeOfUtilitiesRepository.findByType("PSS");
		try {
			if (pssId == null) {
				if (CollectionUtils.isEmpty(findByPssName)) {
					UtilitiesTraderGenco utilitiesTraderGenco = new UtilitiesTraderGenco();
					utilitiesTraderGenco.setName(pssDetailsDTO.getPssName());
					utilitiesTraderGenco.setTypeOfUtilities(findByType);
					utilitiesTraderGencoRepository.save(utilitiesTraderGenco);

					PSS pss = new PSS();
					pss.setPssName(pssName);
					pss.setPssAddress(pssDetailsDTO.getPssAddress());
					pss.setVoltageLevel(pssDetailsDTO.getVoltageLevel());
					pss.setTotalInstalledCapacity(pssDetailsDTO.getTotalInstalledCapacity());
					pss.setGridSubstation(pssDetailsDTO.getGridSubstation());
					pss.setUtilitiesTraderGenco(utilitiesTraderGenco);
					EnergySource findBySourceName = energySourceRepository.findBySourceName(energyType);
					pss.setEnergySourceDetail(findBySourceName);
					pssRepository.save(pss);

					return pss;
				} else {
					throw new BusinessException(saveErrMsg);
				}
			} else {
				PSS findByPssId = pssRepository.findByPssId(pssId);
				if (findByPssId != null) {
					if (findByPssId.getPssName().equalsIgnoreCase(pssDetailsDTO.getPssName())) {
						findByPssId.setPssName(pssDetailsDTO.getPssName());
						findByPssId.setPssAddress(pssDetailsDTO.getPssAddress());
						findByPssId.setVoltageLevel(pssDetailsDTO.getVoltageLevel());
						findByPssId.setTotalInstalledCapacity(pssDetailsDTO.getTotalInstalledCapacity());
						findByPssId.setGridSubstation(pssDetailsDTO.getGridSubstation());
						pssRepository.save(findByPssId);

						UtilitiesTraderGenco findByUtgId = findByPssId.getUtilitiesTraderGenco();
						findByUtgId.setName(pssDetailsDTO.getPssName());
						findByUtgId.setTypeOfUtilities(findByType);
						utilitiesTraderGencoRepository.save(findByUtgId);
					} else {
						if (CollectionUtils.isEmpty(findByPssName)) {
							findByPssId.setPssName(pssDetailsDTO.getPssName());
							findByPssId.setPssAddress(pssDetailsDTO.getPssAddress());
							findByPssId.setVoltageLevel(pssDetailsDTO.getVoltageLevel());
							findByPssId.setTotalInstalledCapacity(pssDetailsDTO.getTotalInstalledCapacity());
							findByPssId.setGridSubstation(pssDetailsDTO.getGridSubstation());
							pssRepository.save(findByPssId);

							UtilitiesTraderGenco findByUtgId = findByPssId.getUtilitiesTraderGenco();
							findByUtgId.setName(pssDetailsDTO.getPssName());
							findByUtgId.setTypeOfUtilities(findByType);
							utilitiesTraderGencoRepository.save(findByUtgId);
						} else {
							throw new BusinessException(saveErrMsg);
						}
					}
					return findByPssId;
				} else {
					throw new BusinessException(editErrMsg);
				}
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		return null;
	}

	public PSS fetchPssDetailsByPssId(Integer pssId) throws BusinessException {
		PSS findByPssId = pssRepository.findByPssId(pssId);
		if (findByPssId != null) {
			return findByPssId;
		} else {
			throw new BusinessException(fetchErrMsg);
		}
	}

	@SuppressWarnings("unchecked")
	public List<PSSDetailsResponseBO> fetchPssDetails(Map<String, Object> requestBody) {

		List<PSSDetailsResponseBO> pssDetailsResponseBOList = new ArrayList<>();
		List<Integer> generatorTypeList = (List<Integer>) requestBody.get("generatorTypeList");
		List<Integer> qcaList = (List<Integer>) requestBody.get("qcaList");
		List<Integer> voltageLevelList = (List<Integer>) requestBody.get("voltageLevelList");
		List<PSS> pssDetailsFromPSSMaster = queryForFetchingPSSDetails(generatorTypeList, qcaList, voltageLevelList);
		if (CollectionUtils.isNotEmpty(pssDetailsFromPSSMaster)) {
			for (PSS pssObj : pssDetailsFromPSSMaster) {
				PSSDetailsResponseBO pssDetailsResponseBO = new PSSDetailsResponseBO();
				String energyType = pssObj.getEnergySourceDetail().getSourceName();
				Integer pssId = pssObj.getPssId();
				String pssName = pssObj.getPssName();
				String pssAddress = pssObj.getPssAddress();
				Integer voltageLevel = pssObj.getVoltageLevel();
				String gridSubstation = pssObj.getGridSubstation();
				Double totalInstalledCapacity = pssObj.getTotalInstalledCapacity();
				UtilitiesTraderGenco utilitiesTraderGencoQCA = pssObj.getUtilitiesTraderGencoQCA();
				List<Generation<GeneratorDetailsDTOType>> generatorDetailsByPssId = generationRepository
						.findByPssId(pssId);
				if (CollectionUtils.isNotEmpty(generatorDetailsByPssId)) {
					List<GeneratorDetailsResponseBO> generatorDetailsResponseBOList = new ArrayList<>();
					for (Generation<GeneratorDetailsDTOType> generatorObj : generatorDetailsByPssId) {
						String plantName = generatorObj.getPlantName();
						String sourceName = generatorObj.getEnergySourceDetail().getSourceName();
						REGeneratorDetailsDTO reGeneratorDetailsDTO = (REGeneratorDetailsDTO) objectMapper
								.convertValue(generatorObj.getGeneratorDetails(), REGeneratorDetailsDTO.class);
						Double generatorIC = reGeneratorDetailsDTO.getTotalInstalledCapacity();

						GeneratorDetailsResponseBO generatorDetailsResponseBO = new GeneratorDetailsResponseBO();
						generatorDetailsResponseBO.setGeneratorLinked(plantName);
						generatorDetailsResponseBO.setGeneratorType(sourceName);
						generatorDetailsResponseBO.setGeneratorIC(generatorIC);
						generatorDetailsResponseBOList.add(generatorDetailsResponseBO);
					}
					if (CollectionUtils.isNotEmpty(generatorDetailsResponseBOList)) {
						Double calculatedIC = generatorDetailsResponseBOList.stream()
								.mapToDouble(bean -> bean.getGeneratorIC()).sum();
						pssDetailsResponseBO.setCalculatedIC(calculatedIC);
					} else {
						pssDetailsResponseBO.setCalculatedIC(null);
					}
					pssDetailsResponseBO.setGeneratorDetails(generatorDetailsResponseBOList);
				}
				pssDetailsResponseBO.setEnergyType(energyType);
				pssDetailsResponseBO.setPssId(pssId);
				pssDetailsResponseBO.setPssName(pssName);
				pssDetailsResponseBO.setPssAddress(pssAddress);
				pssDetailsResponseBO.setVoltageLevel(voltageLevel);
				pssDetailsResponseBO.setGridSubstation(gridSubstation);
				pssDetailsResponseBO.setTotalInstalledCapacity(totalInstalledCapacity);
				if (utilitiesTraderGencoQCA != null) {
					pssDetailsResponseBO.setQcaRegistered(utilitiesTraderGencoQCA.getName());
				}
				pssDetailsResponseBOList.add(pssDetailsResponseBO);
			}
			return pssDetailsResponseBOList;
		} else {
			return null;
		}
	}

	public List<PSS> queryForFetchingPSSDetails(List<Integer> generatorTypeList, List<Integer> qcaList,
			List<Integer> voltageLevelList) {
		List<Predicate> predicates = new ArrayList<>();
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<PSS> criteriaQuery = criteriaBuilder.createQuery(PSS.class);
		Root<PSS> root = criteriaQuery.from(PSS.class);
		criteriaQuery.select(root);
		Expression<Integer> energyTypeExpression = root.get("energySourceDetail");
		Expression<Integer> qcaExpression = root.get("utilitiesTraderGencoQCA");
		Expression<Integer> voltageLevelExpression = root.get("voltageLevel");
		if (CollectionUtils.isNotEmpty(generatorTypeList)) {
			Predicate energyTypePredicate = energyTypeExpression.in(generatorTypeList);
			predicates.add(energyTypePredicate);
		}
		if (CollectionUtils.isNotEmpty(qcaList)) {
			Predicate qcaPredicate = qcaExpression.in(qcaList);
			predicates.add(qcaPredicate);
		}
		if (CollectionUtils.isNotEmpty(voltageLevelList)) {
			Predicate voltageLevelPredicate = voltageLevelExpression.in(voltageLevelList);
			predicates.add(voltageLevelPredicate);
		}
		Predicate deleteTMPredicate = criteriaBuilder.isNull(root.get("deleteTime"));
		predicates.add(deleteTMPredicate);
		Predicate finalPredicate = criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		criteriaQuery.where(finalPredicate);
		List<PSS> pssDetails = entityManager.createQuery(criteriaQuery).getResultList();
		return pssDetails;
	}

	public List<PSS> fetchPssDetailsForDropDown() {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<PSS> criteriaQuery = criteriaBuilder.createQuery(PSS.class);
		Root<PSS> root = criteriaQuery.from(PSS.class);
		criteriaQuery.select(root);
		Predicate deleteTMPredicate = criteriaBuilder.isNull(root.get("deleteTime"));
		criteriaQuery.where(deleteTMPredicate);
		List<PSS> pssDetailsList = entityManager.createQuery(criteriaQuery).getResultList();
		return pssDetailsList;
	}

	public List<PSS> getNonQCALinkedPSSByEnergySrc(String energySrcName) throws Exception, BusinessException {
		EnergySource es = getEnergySourceBySrcName(energySrcName);
		if (es == null) {
			throw new BusinessException(energySrcName + " does not exist.");
		}
		return pssRepository.getNonLinkedPss(es.getId());
	}

	public EnergySource getEnergySourceBySrcName(String energySrcName) throws Exception {
		return pssRepository.getEnergySourceByName(energySrcName.toUpperCase());
	}

	public String deletePssDetails(Integer pssId) {
		PSS pssDetails = pssRepository.findByPssId(pssId);
		Integer qcaUtgId = pssDetails.getUtilitiesTraderGencoQCA().getUID();
		List<Generation<GeneratorDetailsDTOType>> genDetails = generationRepository.findByPssId(pssId);

		if (qcaUtgId == null && CollectionUtils.isEmpty(genDetails)) {
			pssDetails.setDeleteTime(new Date());
			pssRepository.save(pssDetails);

			Integer utgId = pssDetails.getUtilitiesTraderGenco().getUID();
			UtilitiesTraderGenco findByUtgId = utilitiesTraderGencoRepository.findByUtgId(utgId);
			findByUtgId.setDeleteTime(new Date());
			utilitiesTraderGencoRepository.save(findByUtgId);
			return pssDeleteMsg;
		} else {
			return pssDeleteErrMsg;
		}
	}
}
