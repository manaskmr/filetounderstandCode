package in.hertz.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import in.hertz.samast.entity.GenerationUnitType;

@Repository
public interface GenerationUnitTypeRepository extends JpaRepository<GenerationUnitType, Long> {

	@Query("SELECT a FROM GenerationUnitType a " + "WHERE generationTypeShortName = ?1")
	public GenerationUnitType findByShortName(String generationTypeName);
}
