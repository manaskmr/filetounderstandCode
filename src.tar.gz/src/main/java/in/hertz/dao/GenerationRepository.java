package in.hertz.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import in.hertz.samast.entity.AppNoRegNoCounter;
import in.hertz.samast.entity.Generation;

@Repository
public interface GenerationRepository<T> extends JpaRepository<Generation<T>, Long> {

	@Query("SELECT a FROM Generation a " + "WHERE pssId = ?1")
	public List<Generation<T>> findByPssId(Integer pssId);

	@Query("SELECT a FROM Generation a " + "WHERE regNo = ?1")
	public Generation<T> findByRegNo(String regNo);

	@Query("SELECT a FROM Generation a " + "WHERE regNo = ?1 and entityType = ?2")
	public Generation<T> findByRegNoAndEntityType(String regNo, String entityType);

}
