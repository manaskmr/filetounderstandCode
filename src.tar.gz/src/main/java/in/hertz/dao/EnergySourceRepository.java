package in.hertz.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import in.hertz.samast.entity.EnergySource;

@Repository
public interface EnergySourceRepository extends JpaRepository<EnergySource, Long> {

	@Query("SELECT a FROM EnergySource a " + "WHERE id = ?1")
	public EnergySource findById(Integer energyTypeUid);

	@Query("SELECT a FROM EnergySource a " + "WHERE sourceName = ?1")
	public EnergySource findBySourceName(String energyType);

}
