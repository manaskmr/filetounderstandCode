package in.hertz.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import in.hertz.samast.entity.QCA;
import in.hertz.samast.entity.QcaPss;
import in.hertz.samast.util.EntityRegistrationStatus;

@Repository
public interface QcaPssRepository extends JpaRepository<QcaPss, Long> {

	@Query("SELECT a FROM QcaPss a " + "WHERE regNo = ?1")
	public QcaPss findByRegNo(String regNo);

	@Query("SELECT a FROM QcaPss a " + "WHERE regNo = ?1 and entityType = ?2")
	public QcaPss findByRegNoAndEntityType(String regNo, String entityType);

	@Query("SELECT a FROM QcaPss a " + "WHERE qcaUid = ?1 and regStatus!='" + EntityRegistrationStatus.DE_REG + "'")
	public List<QcaPss> findByQcaUid(QCA qcaUid);
}
