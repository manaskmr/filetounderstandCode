package in.hertz.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import in.hertz.samast.entity.Draft;
import in.hertz.samast.util.EntityRegistrationStatus;
import in.hertz.samast.util.FunctionalityArea;

@Repository
public interface DraftRepository<T> extends JpaRepository<Draft<T>, Long> {

	@Query("SELECT a FROM Draft a " + "WHERE UID= ?1")
	public Draft<T> findDraftById(Integer draftId);

	@Query("SELECT a FROM Draft a " + "WHERE function('JSON_EXTRACT', a.data, '$.regNo') = ?1")
	public Draft<T> findDraftByRegNo(String regNo);

	@Query("SELECT a FROM Draft a " + "WHERE function('JSON_EXTRACT', a.data, '$.utgId') = ?1")
	public Draft<T> findDraftByQcaUtgId(Integer qcaUtgId);

	@Query("SELECT a FROM Draft a " + "WHERE function('JSON_EXTRACT', a.data, '$.qcaId') = ?1")
	public List<Draft<T>> findDraftByQcaId(Integer qcaId);

	@Query("SELECT a FROM Draft a " + "WHERE function('JSON_EXTRACT', a.data, '$.appNo') = ?1 and status= ?2")
	public Draft<T> findDraftByAppNoAndStatus(String appNo, String status);

	@Query("SELECT a FROM Draft a " + "WHERE function('JSON_EXTRACT', a.data, '$.regNo') = ?1 and status= ?2")
	public Draft<T> findDraftByRegNoAndStatus(String regNo, String status);

	@Query("SELECT a FROM Draft a " + "WHERE function('JSON_EXTRACT', a.data, '$.appNo') = ?1 and status= ?2")
	public List<Draft<T>> findDraftListByAppNoAndStatus(String appNo, String status);

	@Query("SELECT a FROM Draft a " + "WHERE function('JSON_EXTRACT', a.data, '$.ackNo') = ?1 and status= ?2")
	public List<Draft<T>> findDraftByAckNoAndStatus(String ackNo, String status);

	@Query("SELECT a FROM Draft a " + "WHERE function('JSON_EXTRACT', a.data, '$.regNo') = ?1 and status= ?2")
	public List<Draft<T>> findDraftListByRegNoAndStatus(String regNo, String status);

	@Query("SELECT a FROM Draft a "
			+ "WHERE function('JSON_EXTRACT', a.data, '$.entityType') = ?1 and function('JSON_EXTRACT', a.data, '$.entityName')= ?2")
	public List<Draft<T>> findDraftByEntityTypeAndEntityName(String entityType, String entityName);

	@Query("SELECT a FROM Draft a " + "WHERE function('JSON_EXTRACT', a.data, '$.entityName') = ?1")
	public List<Draft<T>> findDraftByEntityName(String entityName);

	@Query("SELECT a FROM Draft a "
			+ "WHERE function('JSON_EXTRACT', a.data, '$.entityName') = ?1 or function('JSON_EXTRACT', a.data, '$.businessAddress.email')= ?2")
	public List<Draft<T>> findDraftByEntityNameAndPrimaryEmail(String entityName, String primaryEmail);

	@Query("SELECT a FROM Draft a "
			+ "WHERE (function('JSON_EXTRACT', a.data, '$.entityName') = ?1 or function('JSON_EXTRACT', a.data, '$.businessAddress.email')= ?2) and UID!= ?3")
	public List<Draft<T>> findDraftByEntityNameAndPrimaryEmailAndDraftId(String entityName, String primaryEmail,
			Integer draftId);

	@Query("SELECT a FROM Draft a "
			+ "WHERE function('JSON_EXTRACT', a.data, '$.entityType') = ?1 and function('JSON_EXTRACT', a.data, '$.entityName')= ?2 and status= ?3")
	public List<Draft<T>> findDraftByEntityTypeAndEntityNameAndStatus(String entityType, String entityName,
			String status);

	@Query("SELECT a FROM Draft a where a.functionalityArea = '" + FunctionalityArea.ENT_REG
			+ "' and function('JSON_EXTRACT', a.data, '$.ackNo')= ?1 and function('JSON_EXTRACT', a.data, '$.regNo')= null and a.status!='"
			+ EntityRegistrationStatus.DRAFT + "'")
	public Draft<T> findDraftByAckNoStatus(String ackNo);

	@Query("SELECT a FROM Draft a where a.functionalityArea = '" + FunctionalityArea.ENT_REG
			+ "' and function('JSON_EXTRACT', a.data, '$.ackNo')= ?1  and a.status='" + EntityRegistrationStatus.NEW_REG
			+ "'")
	public Draft<T> findDraftByAckNoStatusCancel(String ackNo);
}