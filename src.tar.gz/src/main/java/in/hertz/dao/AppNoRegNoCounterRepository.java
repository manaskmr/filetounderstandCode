package in.hertz.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import in.hertz.samast.entity.AppNoRegNoCounter;

@Repository
public interface AppNoRegNoCounterRepository extends JpaRepository<AppNoRegNoCounter, Long> {

	@Query("SELECT a FROM AppNoRegNoCounter a " + "WHERE entityRegType = ?1 and regType = ?2")
	public AppNoRegNoCounter findExistingCounter(String entityRegType, String regType);
}
