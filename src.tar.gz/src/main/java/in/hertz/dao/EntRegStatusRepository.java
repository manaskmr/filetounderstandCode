package in.hertz.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import in.hertz.samast.entity.EntRegStatus;

@Repository
public interface EntRegStatusRepository extends JpaRepository<EntRegStatus, Long> {

}
