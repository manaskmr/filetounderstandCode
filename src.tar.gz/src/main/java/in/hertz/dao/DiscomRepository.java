package in.hertz.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import in.hertz.samast.entity.Discom;
import in.hertz.samast.entity.Generation;

@Repository
public interface DiscomRepository extends JpaRepository<Discom, Long> {

	@Query("SELECT a FROM Discom a " + "WHERE discomShortName = ?1")
	public Discom findByShortName(String discomShortName);

	@Query("SELECT a FROM Discom a " + "WHERE regNo = ?1")
	public Discom findByRegNo(String regNo);

	@Query("SELECT a FROM Discom a " + "WHERE regNo = ?1 and entityType = ?2")
	public Discom findByRegNoAndEntityType(String regNo, String entityType);

}
