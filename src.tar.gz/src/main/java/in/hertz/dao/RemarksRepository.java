package in.hertz.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import in.hertz.samast.entity.Remark;

@Repository
public interface RemarksRepository extends JpaRepository<Remark, Long> {

	@Query("SELECT a FROM Remark a " + "WHERE ackNo= ?1")
	public List<Remark> findRemarkByAckNo(String ackNo);
}
