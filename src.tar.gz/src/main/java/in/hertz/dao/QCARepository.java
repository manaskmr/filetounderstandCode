package in.hertz.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import in.hertz.samast.entity.Generation;
import in.hertz.samast.entity.OAConsumer;
import in.hertz.samast.entity.QCA;
import in.hertz.samast.entity.UtilitiesTraderGenco;

@Repository
public interface QCARepository extends JpaRepository<QCA, Long> {

	@Query("SELECT a FROM QCA a " + "WHERE qcaUid = ?1")
	public QCA findByQcaId(Integer qcaId);

	@Query("SELECT a FROM QCA a " + "WHERE regNo = ?1")
	public QCA findByRegNo(String regNo);

	@Query("SELECT a FROM QCA a " + "WHERE utilitiesTraderGenco = ?1")
	public QCA findByUtgId(UtilitiesTraderGenco utgId);

	@Query("SELECT a FROM QCA a " + "WHERE regNo = ?1 and entityType = ?2")
	public QCA findByRegNoAndEntityType(String regNo, String entityType);

}
