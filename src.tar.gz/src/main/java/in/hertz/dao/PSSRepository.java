package in.hertz.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import in.hertz.samast.entity.EnergySource;
import in.hertz.samast.entity.PSS;

@Repository
public interface PSSRepository extends JpaRepository<PSS, Long> {

	@Query("SELECT a FROM PSS a " + "WHERE pssId = ?1")
	public PSS findByPssId(Integer pssId);

	@Query("SELECT a FROM PSS a " + "WHERE pssName = ?1")
	public List<PSS> findByPssName(String pssName);
	
	@Query("SELECT ps FROM PSS ps where ps.utilitiesTraderGencoQCA.UID is NULL and ps.energySourceDetail.id=?1")
    public List<PSS> getNonLinkedPss(Integer energySrcID) throws Exception;
	
	@Query("SELECT es FROM EnergySource es where es.sourceName=?1")
	public EnergySource getEnergySourceByName(String energySrc) throws Exception;


}
