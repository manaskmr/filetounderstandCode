package in.hertz.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import in.hertz.samast.entity.AckNoCounter;

@Repository
public interface AckNoCounterRepository extends JpaRepository<AckNoCounter, Long> {

	@Query("SELECT a FROM AckNoCounter a " + "WHERE appNo = ?1")
	public AckNoCounter findExistingCounterForAckNo(String appNo);
}
