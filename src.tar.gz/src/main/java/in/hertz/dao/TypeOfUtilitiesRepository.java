package in.hertz.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import in.hertz.samast.entity.TypeOfUtilities;

@Repository
public interface TypeOfUtilitiesRepository extends JpaRepository<TypeOfUtilities, Long> {

	@Query("SELECT a FROM TypeOfUtilities a " + "WHERE type = ?1")
	public TypeOfUtilities findByType(String type);
}
