package in.hertz.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import in.hertz.samast.entity.Workflow;

@Repository
public interface WorkflowRepository extends JpaRepository<Workflow, Long> {

	@Query("SELECT a FROM Workflow a " + "WHERE sectionId= ?1")
	public Workflow findDepartmentBySectionId(String sectionId);

	@Query("SELECT a FROM Workflow a " + "WHERE functionalityArea= ?1")
	public List<Workflow> findSectionByFuncArea(String functionalityArea);
}
