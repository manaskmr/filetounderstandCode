package in.hertz.ctrl;

import java.text.ParseException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.hertz.samast.domain.GeneratorDetailsDTOType;
import in.hertz.samast.domain.WSResp;
import in.hertz.samast.domain.exception.BusinessException;
import in.hertz.service.GenerationService;

@RestController
@RequestMapping("/generator")
public class GenerationController {

	@Autowired
	private GenerationService generationService;

	@GetMapping("/{pssId}")
	public WSResp<List<GeneratorDetailsDTOType>> getGeneratorDetailsByPssId(@PathVariable Integer pssId)
			throws ParseException, BusinessException {
		List<GeneratorDetailsDTOType> fetchedGeneratorDetails = generationService.getGeneratorDetailsByPssId(pssId);
		if (fetchedGeneratorDetails != null) {
			return new WSResp<>(fetchedGeneratorDetails, true, null);
		} else {
			return new WSResp<>(fetchedGeneratorDetails, false, "Error In Saving The Data!");
		}
	}
}
