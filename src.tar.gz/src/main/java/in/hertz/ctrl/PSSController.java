package in.hertz.ctrl;

import java.text.ParseException;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.hertz.samast.domain.PSSDetailsDTO;
import in.hertz.samast.domain.PSSDetailsResponseBO;
import in.hertz.samast.domain.WSResp;
import in.hertz.samast.domain.exception.BusinessException;
import in.hertz.samast.entity.PSS;
import in.hertz.service.PSSService;

@RestController
@RequestMapping("/pss")
public class PSSController {

	@Autowired
	private PSSService pssService;

	@PostMapping
	public WSResp<PSS> saveOrUpdatePssDetails(@RequestBody PSSDetailsDTO pssDetailsDTO)
			throws ParseException, BusinessException {
		PSS savedPssDetails = pssService.saveOrUpdatePssDetails(pssDetailsDTO);
		if (savedPssDetails != null) {
			return new WSResp<>(savedPssDetails, true, "Data Saved Successfully!");
		} else {
			return new WSResp<>(savedPssDetails, false, "Error In Saving The Data!");
		}
	}

	@GetMapping("/{pssId}")
	public WSResp<PSS> fetchPssDetailsByPssId(@PathVariable Integer pssId) throws ParseException, BusinessException {
		PSS fetchedPssDetails = pssService.fetchPssDetailsByPssId(pssId);
		if (fetchedPssDetails != null) {
			return new WSResp<>(fetchedPssDetails, true, "Data Fetched Successfully!");
		} else {
			return new WSResp<>(fetchedPssDetails, false, "Error In Fetching The Data!");
		}
	}

	@PostMapping("/pss-list")
	public WSResp<List<PSSDetailsResponseBO>> fetchPssDetails(@RequestBody Map<String, Object> requestBody)
			throws ParseException {
		List<PSSDetailsResponseBO> fetchedPssDetailsList = pssService.fetchPssDetails(requestBody);
		if (fetchedPssDetailsList != null) {
			return new WSResp<>(fetchedPssDetailsList, true, "Data Fetched Successfully!");
		} else {
			return new WSResp<>(fetchedPssDetailsList, false, "Error In Fetching The Data!");
		}
	}

	@GetMapping("/pss-names")
	public WSResp<List<PSS>> fetchPssDetailsForDropDown() throws ParseException {
		List<PSS> fetchedPssDetailsList = pssService.fetchPssDetailsForDropDown();
		if (fetchedPssDetailsList != null) {
			return new WSResp<>(fetchedPssDetailsList, true, "Data Fetched Successfully!");
		} else {
			return new WSResp<>(fetchedPssDetailsList, false, "Error In Fetching The Data!");
		}
	}

	@GetMapping("/qca-non-linked-pss-by-energy/{energySrc}")
	public List<PSS> getNonQCALinkedPSSByEnergySrc(@PathVariable String energySrc) throws Exception, BusinessException {
		return pssService.getNonQCALinkedPSSByEnergySrc(energySrc);
	}

	@DeleteMapping("/{pssId}")
	public ResponseEntity<WSResp<String>> deletePssDetails(@PathVariable Integer pssId) {
		return ResponseEntity.ok(new WSResp<>(pssService.deletePssDetails(pssId), true, ""));
	}

}
