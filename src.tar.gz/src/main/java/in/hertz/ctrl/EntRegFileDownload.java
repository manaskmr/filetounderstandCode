package in.hertz.ctrl;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.hertz.samast.util.EntityRegistrationType;

@RestController
@RequestMapping("/download-mand-doclist")
public class EntRegFileDownload {
	
	@Value("${ent.reg.template.path}")
	private String  templatePath;
	
	@GetMapping("/{entityType}")
	public void downloadExcelFile(HttpServletResponse response, @PathVariable("entityType") String entityType)
			throws IOException {
		String fileName = null;
		String path = System.getenv("SAMAST_HOME");
		if (entityType.equalsIgnoreCase("QCA")) {
			fileName = "QCA_Doc_List.xlsx";
		} else if (entityType.equalsIgnoreCase("RE")) {
			fileName = "RE_Doc_List.xlsx";
		} else if (entityType.equalsIgnoreCase("SEN")) {
			fileName = "State_Entity_Doc_List.xlsx";
		}
		if (StringUtils.isNotBlank(fileName)&& StringUtils.isNotBlank(path)) {
			
			path=path.concat(File.separator).concat(templatePath).concat(File.separator);
			response.setContentType("application/octet-stream");
			response.setHeader("Content-Disposition", "attachment; filename=" + fileName);
			FileInputStream file = new FileInputStream(new File(path + fileName));
			IOUtils.copy(file, response.getOutputStream());
		}
	}
	
	@GetMapping("/download-re-sample-doclist/{entityType}")
	public void downloadExcelFile1(HttpServletResponse response, @PathVariable("entityType") String entityType)
			throws IOException {
		String fileName = null;
		String path = System.getenv("SAMAST_HOME");
		if (entityType.equalsIgnoreCase(EntityRegistrationType.REG)) {
			fileName = "Master_Solar_Wind.xlsx";
		}
		if (StringUtils.isNotBlank(fileName)&& StringUtils.isNotBlank(path)) {
			path=path.concat(File.separator).concat(templatePath).concat(File.separator);
			response.setContentType("application/octet-stream");
			response.setHeader("Content-Disposition", "attachment; filename=" + fileName);
			FileInputStream file = new FileInputStream(new File(path + fileName));
			IOUtils.copy(file, response.getOutputStream());
		}
	}
}
