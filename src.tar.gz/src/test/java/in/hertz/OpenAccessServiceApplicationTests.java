package in.hertz;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes=OpenAccessServiceApplicationTests.class)
public class OpenAccessServiceApplicationTests {

	@Test
	public void contextLoads() {
	}

}
